import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:project/screens/otp_screen.dart';

class ProfileUploadService {
  static final FirebaseAuth _auth = FirebaseAuth.instance;
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  static String? _verificationId; // Stores the latest verification ID
  static int? resendToken; // Stores the resend token for Firebase OTP

  /// ✅ **Upload Profile Data to Firestore & Send OTP**
  static Future<void> uploadProfile({
    required String name,
    required String gender,
    required DateTime birthday,
    required String phoneNumber,
    required String address,
    required String profession,
    required BuildContext context,
  }) async {
    try {
      User? user = _auth.currentUser;
      if (user == null) {
        print("❌ No authenticated user found.");
        return;
      }

      String uid = user.uid;
      String? email = user.email;
      phoneNumber = _formatPhoneNumber(phoneNumber);

      // 🔍 Check if the email already exists in Firestore
      QuerySnapshot emailCheck = await _firestore
          .collection('users')
          .where("email", isEqualTo: email)
          .get();

      // 🔍 Check if the UID exists (covers Google & Email sign-in cases)
      DocumentSnapshot userDoc = await _firestore.collection('users').doc(uid).get();
      bool isExistingUser = userDoc.exists;

      // ✅ Upload Profile Data to Firestore
      await _firestore.collection('users').doc(uid).set({
        "uid": uid,
        "name": name,
        "gender": gender,
        "birthday": birthday,
        "phoneNumber": phoneNumber,
        "address": address,
        "profession": profession,
        "isPhoneVerified": false, // Will be updated after OTP verification
        "isProfileComplete": isExistingUser ? userDoc["isProfileComplete"] : false, // Keep previous data if exists
        "photoURL": user.photoURL ?? "",
        "email": user.email,
        "createdAt": FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      print("✅ Profile uploaded successfully!");

      // ✅ Send OTP after successful profile upload
      await sendOTP(phoneNumber: phoneNumber, uid: uid, context: context);
    } catch (e) {
      print("❌ Error uploading profile: $e");
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Profile upload failed: $e")),
        );
      }
    }
  }

  /// ✅ **Send OTP & Handle Verification**
  static Future<void> sendOTP({
    required String phoneNumber,
    required String uid,
    required BuildContext context,
  }) async {
    try {
      phoneNumber = _formatPhoneNumber(phoneNumber);
      print("📩 Sending OTP to: $phoneNumber");

      await _auth.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        timeout: const Duration(seconds: 60),
        verificationCompleted: (PhoneAuthCredential credential) async {
          try {
            await _auth.currentUser?.linkWithCredential(credential);
            await _firestore.collection('users').doc(uid).update({
              "isPhoneVerified": true,
              "isProfileComplete": true,
            });
            print("✅ Phone number verified automatically.");
          } catch (e) {
            print("❌ Auto-verification failed: $e");
          }
        },
        verificationFailed: (FirebaseAuthException e) {
          print("❌ Phone verification failed: ${e.message}");

          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text("Phone verification failed: ${e.message}")),
            );
          }
        },
        codeSent: (String verificationId, int? resendToken) {
          print("📩 OTP Sent to $phoneNumber (Verification ID: $verificationId)");

          _verificationId = verificationId;
          resendToken = resendToken;

          if (context.mounted) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => OTPVerificationPage(
                  phoneNumber: phoneNumber,
                  uid: uid,
                  verificationId: verificationId,
                ),
              ),
            );
          }
        },
        forceResendingToken: resendToken,
        codeAutoRetrievalTimeout: (String verificationId) {
          print("⏳ Auto-retrieval timeout. Manual OTP entry required.");
          _verificationId = verificationId;
        },
      );
    } catch (e) {
      print("❌ OTP Sending Failed: $e");
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("OTP Sending Failed: $e")),
        );
      }
    }
  }

  /// ✅ **Resend OTP Function**
  static Future<void> resendOTP({
    required String phoneNumber,
    required String uid,
    required BuildContext context,
  }) async {
    if (_verificationId == null) {
      print("❌ Cannot resend OTP. No previous verification ID found.");
      return;
    }

    try {
      phoneNumber = _formatPhoneNumber(phoneNumber);
      print("🔄 Resending OTP to: $phoneNumber");

      await _auth.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        timeout: const Duration(seconds: 60),
        forceResendingToken: resendToken,
        verificationCompleted: (PhoneAuthCredential credential) async {
          try {
            await _auth.currentUser?.linkWithCredential(credential);
            await _firestore.collection('users').doc(uid).update({
              "isPhoneVerified": true,
              "isProfileComplete": true,
            });
            print("✅ Phone number verified automatically.");
          } catch (e) {
            print("❌ Auto-verification failed: $e");
          }
        },
        verificationFailed: (FirebaseAuthException e) {
          print("❌ Resend OTP failed: ${e.message}");

          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text("Resend OTP failed: ${e.message}")),
            );
          }
        },
        codeSent: (String verificationId, int? resendToken) {
          print("📩 OTP Resent to $phoneNumber (New Verification ID: $verificationId)");

          _verificationId = verificationId;
          resendToken = resendToken;
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          print("⏳ Auto-retrieval timeout.");
          _verificationId = verificationId;
        },
      );
    } catch (e) {
      print("❌ Resend OTP Failed: $e");
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Resend OTP Failed: $e")),
        );
      }
    }
  }

  /// ✅ **Formats phone number to E.164 standard (+91XXXXXXXXXX)**
  static String _formatPhoneNumber(String phone) {
    phone = phone.replaceAll(RegExp(r'\s+'), ''); // Remove spaces
    phone = phone.replaceAll(RegExp(r'[^\d+]'), ''); // Remove non-numeric characters except +

    if (phone.startsWith("+91")) {
      return phone;
    }
    if (phone.length == 10) {
      return "+91$phone";
    }

    throw "Invalid phone number format";
  }
}
