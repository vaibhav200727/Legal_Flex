import 'package:firebase_auth/firebase_auth.dart';

class EmailAuth {
  /// **Login with Email & Password (Only if Registered)**
  static Future<UserCredential?> signInWithEmailAndPassword(
      String email, String password) async {
    try {
      // **Check if email exists in Firebase**
      final List<String> signInMethods =
          await FirebaseAuth.instance.fetchSignInMethodsForEmail(email.trim());

      if (signInMethods.isEmpty) {
        print("Email is not registered in Firebase.");
        throw FirebaseAuthException(
          code: 'email-not-registered',
          message: 'This email is not registered. Please sign up first.',
        );
      }

      // **Proceed with Login**
      final UserCredential userCredential =
          await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email.trim(),
        password: password.trim(),
      );

      print("Email Sign-In successful: ${userCredential.user?.email}");
      return userCredential;
    } catch (e) {
      print("Email Sign-In failed: $e");
      rethrow;
    }
  }

  /// **Register New User with Email & Password**
  static Future<UserCredential?> registerWithEmailAndPassword(
      String email, String password) async {
    try {
      // **Check if email is already registered**
      final List<String> signInMethods =
          await FirebaseAuth.instance.fetchSignInMethodsForEmail(email.trim());

      if (signInMethods.isNotEmpty) {
        print("Email is already registered. Try logging in instead.");
        throw FirebaseAuthException(
          code: 'email-already-registered',
          message: 'This email is already registered. Please log in instead.',
        );
      }

      // **Proceed with Registration**
      final UserCredential userCredential =
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password.trim(),
      );

      print("Email Registration successful: ${userCredential.user?.email}");
      return userCredential;
    } catch (e) {
      print("Email Registration failed: $e");
      rethrow;
    }
  }

  /// **Send Password Reset Email**
  static Future<void> sendPasswordResetEmail(String email) async {
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email.trim());
      print("Password reset email sent to $email");
    } catch (e) {
      print("Failed to send password reset email: $e");
      rethrow;
    }
  }
}
