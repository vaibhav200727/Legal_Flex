import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:shared_preferences/shared_preferences.dart';

class GoogleAuth {
  static Future<User?> signInWithGoogle({required bool rememberMe}) async {
    try {
      final FirebaseAuth auth = FirebaseAuth.instance;
      final GoogleSignIn googleSignIn = GoogleSignIn();

      // **If Remember Me is NOT selected, force logout to allow account selection**
      if (!rememberMe) {
        await googleSignIn.signOut();
      }

      // **Start Google Sign-In**
      final GoogleSignInAccount? googleUser = await googleSignIn.signIn();
      if (googleUser == null) {
        print("Google Sign-In canceled by user.");
        return null;
      }

      // **Authenticate with Firebase**
      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      // **Sign in to Firebase**
      final UserCredential userCredential = await auth.signInWithCredential(credential);
      final User? user = userCredential.user;
      print("Google Sign-In Successful: ${user?.email}");

      // **If Remember Me is selected, save preference**
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('rememberMe', rememberMe);

      // **Empty implementation for what to do when login is successful**
      _onLoginSuccess(user);

      return user;
    } on FirebaseAuthException catch (e) {
      print("Google login failed: ${e.message}");
      return null;
    } catch (e) {
      print("Unexpected error during Google Sign-In: $e");
      return null;
    }
  }

  /// **Function to be implemented when login is successful**
  static void _onLoginSuccess(User? user) {
    // ✅ TODO: Implement what happens when login is successful
    // Example: Redirect to home screen, fetch user data, etc.
    print("Login successful! Implement next steps here.");
  }

  /// **Logout function**
  static Future<void> logout() async {
    final GoogleSignIn googleSignIn = GoogleSignIn();
    await googleSignIn.signOut();
    await FirebaseAuth.instance.signOut();
    
    // **Clear "Remember Me" preference**
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('rememberMe', false);
    
    print("User logged out.");
  }
}
