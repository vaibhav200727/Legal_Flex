import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'google_auth.dart';
import 'email_auth.dart';

class AuthService {
  static final FirebaseAuth _auth = FirebaseAuth.instance;
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// ✅ **Google Login with Firestore Verification (Query by UID Field)**
  static Future<User?> loginWithGoogle({required bool rememberMe}) async {
    try {
      // 1) Sign in with Google (returns Firebase User)
      User? user = await GoogleAuth.signInWithGoogle(rememberMe: rememberMe);
      if (user == null) {
        print("❌ Google login failed (no user).");
        return null;
      }

      // 2) Query Firestore for the doc that has "uid" == user.uid
      final querySnap = await _firestore
          .collection('users')
          .where('uid', isEqualTo: user.uid)
          .limit(1)
          .get();

      if (querySnap.docs.isEmpty) {
        print("❌ User not found in Firestore (no doc has uid == ${user.uid}).");
        throw FirebaseAuthException(
          code: "user-not-registered",
          message: "This email/UID is not registered. Please sign up first.",
        );
      }

      // We have at least one matching doc
      final userDoc = querySnap.docs.first;
      bool isPhoneVerified = userDoc.get("isPhoneVerified") ?? false;
      bool isProfileComplete = userDoc.get("isProfileComplete") ?? false;

      if (!isPhoneVerified || !isProfileComplete) {
        throw FirebaseAuthException(
          code: "login-blocked",
          message: !isPhoneVerified
              ? "Your phone number is not verified. Please verify it to continue."
              : "Your profile is incomplete. Please complete it before logging in.",
        );
      }

      // Retrieve additional fields from Firestore doc
      String profession = userDoc.get("profession") ?? "";
      String name = userDoc.get("name") ?? "";
      String photoURL = userDoc.get("photoURL") ?? "";
      // 3) Store UID, Profession, Name, and "Remember Me" in SharedPreferences
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString('uid', user.uid);           // the real Firebase UID
      await prefs.setString('profession', profession);    // from Firestore doc
      await prefs.setString('name', name);                // user's name from Firestore
      await prefs.setString('photoURL', photoURL);
      await prefs.setBool('rememberMe', rememberMe);

      print("✅ Google login successful: ${user.email}");
      return user;
    } catch (e) {
      print("❌ Google login error: $e");
      rethrow;
    }
  }

  /// ✅ **Email & Password Login with Firestore Verification (Query by UID Field)**
  static Future<User?> loginWithEmail(String email, String password, {required bool rememberMe}) async {
    try {
      // 1) Sign in with Email/Password
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password.trim(),
      );
      User? user = userCredential.user;
      if (user == null) {
        throw FirebaseAuthException(
          code: "login-failed",
          message: "Login failed. Please try again.",
        );
      }

      // 2) Query Firestore for the doc that has "uid" == user.uid
      final querySnap = await _firestore
          .collection('users')
          .where('uid', isEqualTo: user.uid)
          .limit(1)
          .get();

      if (querySnap.docs.isEmpty) {
        print("❌ User not found in Firestore (no doc has uid == ${user.uid}).");
        throw FirebaseAuthException(
          code: "user-not-registered",
          message: "This email/UID is not registered. Please sign up first.",
        );
      }

      // We have at least one matching doc
      final userDoc = querySnap.docs.first;
      bool isPhoneVerified = userDoc.get("isPhoneVerified") ?? false;
      bool isProfileComplete = userDoc.get("isProfileComplete") ?? false;

      if (!isPhoneVerified || !isProfileComplete) {
        throw FirebaseAuthException(
          code: "login-blocked",
          message: !isPhoneVerified
              ? "Your phone number is not verified. Please verify it to continue."
              : "Your profile is incomplete. Please complete it before logging in.",
        );
      }

      // Retrieve additional fields from Firestore doc
      String profession = userDoc.get("profession") ?? "";
      String name = userDoc.get("name") ?? "";
      String photoURL = userDoc.get("photoURL") ?? "";

      // 3) Store UID, Profession, Name, and "Remember Me" in SharedPreferences
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString('uid', user.uid);           // the real Firebase UID
      await prefs.setString('profession', profession);    // from Firestore doc
      await prefs.setString('name', name);                // user's name from Firestore
      await prefs.setString('photoURL', photoURL);
      await prefs.setBool('rememberMe', rememberMe);

      print("✅ Email login successful: ${user.email}");
      return user;
    } on FirebaseAuthException catch (e) {
      print("❌ Email login failed: ${e.message}");

      if (e.code == 'user-not-found') {
        throw FirebaseAuthException(
          code: 'user-not-registered',
          message: 'This email is not registered. Please sign up first.',
        );
      } else if (e.code == 'wrong-password') {
        throw FirebaseAuthException(
          code: 'wrong-password',
          message: 'Incorrect password. Please try again.',
        );
      } else {
        rethrow; // Propagate other errors
      }
    } catch (e) {
      print("❌ Unexpected login error: $e");
      rethrow;
    }
  }

  /// ✅ **Logout User & Clear "Remember Me"**
  static Future<void> logout() async {
    try {
      await _auth.signOut();

      // Clear "Remember Me" and any stored data in SharedPreferences if desired
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('rememberMe', false);

      print("✅ User logged out.");
    } catch (e) {
      print("❌ Logout failed: $e");
      rethrow;
    }
  }
}
