import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'google_auth.dart';
import 'email_auth.dart';

class SignupService {
  static final FirebaseAuth _auth = FirebaseAuth.instance;
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// ✅ **Sign Up with Email & Password (Firebase Auth + Firestore)**
  static Future<User?> signUpWithEmail(String email, String password) async {
    try {
      // Create user in Firebase Auth
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password.trim(),
      );

      final User? user = userCredential.user;
      if (user != null) {
        // ✅ Add user details to Firestore and store UID, Profession, Name & photoURL in SharedPreferences
        await _storeUserData(user);
        print("✅ Email Sign-Up Successful: ${user.email}");
        return user;
      }
      return null;
    } on FirebaseAuthException catch (e) {
      print("❌ Email Sign-Up Failed: ${e.message}");
      return null;
    }
  }

  /// ✅ **Sign Up with Google (Firebase Auth + Firestore)**
  static Future<User?> signUpWithGoogle() async {
    try {
      final GoogleSignIn googleSignIn = GoogleSignIn();
      await googleSignIn.signOut(); // ✅ Forces account selection
      final GoogleSignInAccount? googleUser = await googleSignIn.signIn();

      if (googleUser == null) {
        print("❌ Google Sign-Up Cancelled.");
        return null;
      }

      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      UserCredential userCredential = await _auth.signInWithCredential(credential);
      final User? user = userCredential.user;

      if (user != null) {
        // ✅ Add user details to Firestore and store UID, Profession, Name & photoURL in SharedPreferences
        await _storeUserData(user);
        print("✅ Google Sign-Up Successful: ${user.email}");
        return user;
      }
      return null;
    } catch (e) {
      print("❌ Google Sign-Up Error: $e");
      return null;
    }
  }

  /// ✅ **Helper Function: Store/Update User Data in Firestore and SharedPreferences**
  static Future<void> _storeUserData(User user) async {
    try {
      final userDocRef = _firestore.collection('users').doc(user.uid);
      DocumentSnapshot doc = await userDocRef.get();

      String profession = ''; // Default empty profession
      String name = user.displayName ?? '';
      String photoUrl = user.photoURL ?? '';

      if (!doc.exists) {
        // ✅ New User - Create fresh user document
        await userDocRef.set({
          'uid': user.uid,
          'email': user.email,
          'name': name,
          'gender': '',
          'birthday': null,
          'phoneNumber': '',
          'address': '',
          'profession': profession,
          'photoURL': photoUrl,
          'isPhoneVerified': user.phoneNumber != null,
          'isProfileComplete': false, // ✅ Profile is incomplete at start
          'createdAt': FieldValue.serverTimestamp(),
        });
        print("✅ New user added to Firestore: ${user.email}");
      } else {
        // ✅ Existing User - Ensure missing fields are updated, but don't overwrite
        Map<String, dynamic> existingData = doc.data() as Map<String, dynamic>;

        profession = existingData['profession'] ?? '';
        name = existingData['name'] ?? name;

        Map<String, dynamic> updates = {};

        if (!existingData.containsKey('isProfileComplete')) {
          updates['isProfileComplete'] = false;
        }

        if (!existingData.containsKey('photoURL') || existingData['photoURL'] == '') {
          updates['photoURL'] = photoUrl;
        }

        if (updates.isNotEmpty) {
          await userDocRef.update(updates);
          print("✅ Existing user updated: ${user.email}");
        } else {
          print("ℹ️ No updates needed for ${user.email}");
        }
      }

      // ✅ Store UID, Profession, Name & photoURL in SharedPreferences
      await _storeUserInPreferences(user.uid, profession, name, photoUrl);
    } catch (e) {
      print("❌ Error storing/updating user data in Firestore: $e");
    }
  }

  /// ✅ **Helper Function: Store UID, Profession, Name & photoURL in SharedPreferences**
  static Future<void> _storeUserInPreferences(
      String uid, String profession, String name, String photoURL) async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString('uid', uid);
      await prefs.setString('profession', profession);
      await prefs.setString('name', name);
      await prefs.setString('photoURL', photoURL);
      print("✅ User data saved in SharedPreferences: UID=$uid, Profession=$profession, Name=$name");
    } catch (e) {
      print("❌ Error storing data in SharedPreferences: $e");
    }
  }

  /// ✅ **Logout User & Clear "Remember Me"**
  static Future<void> logout() async {
    try {
      await _auth.signOut();

      // Clear "Remember Me" and any stored data in SharedPreferences if desired
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('rememberMe', false);

      print("✅ User logged out.");
    } catch (e) {
      print("❌ Logout failed: $e");
      rethrow;
    }
  }
}
