import 'package:cloud_firestore/cloud_firestore.dart';

class Comment {
  final String id;
  final String uid;
  final String name;
  final String photoUrl; // User's profile image URL.
  final String commentText;
  final DateTime timestamp;
  final int likes;
  final int dislikes;
  final Map<String, String>? reactions; // Dynamic reaction map: uid -> reaction ("like"/"dislike")
  // Replies are stored in a subcollection; you can query them separately.
  
  Comment({
    required this.id,
    required this.uid,
    required this.name,
    required this.photoUrl,
    required this.commentText,
    required this.timestamp,
    required this.likes,
    required this.dislikes,
    this.reactions,
  });

  factory Comment.fromDoc(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    // Convert the dynamic reaction field to Map<String, String> if it exists.
    Map<String, String>? reactionMap;
    if (data['reactions'] != null) {
      reactionMap = Map<String, String>.from(data['reactions']);
    }
    return Comment(
      id: doc.id,
      uid: data['uid'] ?? '',
      name: data['name'] ?? '',
      photoUrl: data['photoURL'] ?? '',
      commentText: data['commentText'] ?? '',
      timestamp: (data['timestamp'] as Timestamp?)?.toDate() ?? DateTime.now(),
      likes: data['likes'] ?? 0,
      dislikes: data['dislikes'] ?? 0,
      reactions: reactionMap,
    );
  }
}

class Reply {
  final String id;
  final String uid;
  final String name;
  final String photoUrl;
  final String replyText;
  final DateTime timestamp;
  final int likes;
  final int dislikes;
  final Map<String, String>? reactions; // Dynamic reaction map: uid -> reaction
  
  Reply({
    required this.id,
    required this.uid,
    required this.name,
    required this.photoUrl,
    required this.replyText,
    required this.timestamp,
    required this.likes,
    required this.dislikes,
    this.reactions,
  });

  factory Reply.fromDoc(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    Map<String, String>? reactionMap;
    if (data['reactions'] != null) {
      reactionMap = Map<String, String>.from(data['reactions']);
    }
    return Reply(
      id: doc.id,
      uid: data['uid'] ?? '',
      name: data['name'] ?? '',
      photoUrl: data['photoURL'] ?? '',
      replyText: data['replyText'] ?? '',
      timestamp: (data['timestamp'] as Timestamp?)?.toDate() ?? DateTime.now(),
      likes: data['likes'] ?? 0,
      dislikes: data['dislikes'] ?? 0,
      reactions: reactionMap,
    );
  }
}
