import 'package:cloud_firestore/cloud_firestore.dart';

class Post {
  final String id;
  final String uid;
  final String name;
  final String profession;
  final String photoUrl; // Field to store profile photo URL
  final String postTitle;
  final String postBody;
  final String imageUrl;  // Field for the post image
  final String category;
  final DateTime timestamp;
  final int likes;
  final int dislikes;
  final int comments;

  Post({
    required this.id,
    required this.uid,
    required this.name,
    required this.profession,
    required this.photoUrl,
    required this.postTitle,
    required this.postBody,
    required this.imageUrl,
    required this.category,
    required this.timestamp,
    required this.likes,
    required this.dislikes,
    required this.comments,
  });

  factory Post.fromDoc(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Post(
      id: doc.id,
      uid: data['uid'] ?? '',
      name: data['name'] ?? '',
      profession: data['profession'] ?? '',
      photoUrl: data['photoURL'] ?? '', // Updated key from "photoUrl" to "photoURL"
      postTitle: data['postTitle'] ?? '',
      postBody: data['postBody'] ?? '',
      imageUrl: data['imageUrl'] ?? '',
      category: data['category'] ?? '',
      timestamp: (data['timestamp'] as Timestamp?)?.toDate() ?? DateTime.now(),
      likes: data['likes'] ?? 0,
      dislikes: data['dislikes'] ?? 0,
      comments: data['comments'] ?? 0,
    );
  }
}
