final List<Map<String, dynamic>> chooseYourFateDataset = [
  {
    'scenario':
        'You are a lawyer representing a client accused of a minor offense. The prosecution offers a plea bargain with reduced charges if your client pleads guilty. What should you advise?',
    'options': [
      '1. Accept the plea bargain immediately.',
      '2. Reject the plea bargain and demand a trial without further investigation.',
      '3. Evaluate the evidence thoroughly and advise based on the strength of the case.',
      '4. Encourage a guilty plea to avoid media attention.'
    ],
    'correctOption': 2,
    'explanation':
        'It is best to review all evidence and assess the merits of the case before making any decision regarding a plea bargain.'
  },
  {
    'scenario':
        'A company is planning to lay off many employees and wants to bypass proper legal procedures regarding severance pay and notice. What should the company do?',
    'options': [
      '1. Proceed with the layoffs immediately.',
      '2. Consult legal counsel to ensure compliance with labor laws.',
      '3. Ignore labor laws since it is a private matter.',
      '4. Delay layoffs indefinitely to avoid any legal risks.'
    ],
    'correctOption': 1,
    'explanation':
        'It is critical to follow legal procedures. Consulting legal counsel will help the company adhere to labor laws and avoid future litigation.'
  },
  {
    'scenario':
        'Your client faces a breach of contract lawsuit. However, the contract lacks some essential details. What should be your course of action?',
    'options': [
      '1. Argue that the contract is invalid due to the missing details.',
      '2. Suggest renegotiating the contract terms before proceeding with litigation.',
      '3. Ignore the lawsuit because the contract is unclear.',
      '4. Advise your client to settle immediately to avoid court proceedings.'
    ],
    'correctOption': 0,
    'explanation':
        'A contract missing crucial details may be challenged on grounds of invalidity. Evaluating its legal strength is an important first step.'
  },
  {
    'scenario':
        'You receive a tip about potential corruption in a government contract. What is the most appropriate action?',
    'options': [
      '1. Leak the information to the media immediately.',
      '2. Investigate the tip and report it to the appropriate authorities.',
      '3. Ignore the tip to avoid causing a scandal.',
      '4. Confront the involved officials without any evidence.'
    ],
    'correctOption': 1,
    'explanation':
        'Proper protocol involves verifying the information and reporting it to the relevant authorities to ensure a lawful investigation.'
  },
  {
    'scenario':
        'A citizen approaches you about a long-standing boundary dispute with a neighbor. What is your recommended first step?',
    'options': [
      '1. Advise them to take direct legal action immediately.',
      '2. Encourage mediation or arbitration before filing a lawsuit.',
      '3. File a lawsuit without attempting any alternative resolution.',
      '4. Suggest ignoring the issue because it has persisted for decades.'
    ],
    'correctOption': 1,
    'explanation':
        'Mediation or arbitration is often a less confrontational, more cost-effective first step in resolving longstanding disputes.'
  },
  {
    'scenario':
        'A small business owner is being sued by a former employee for wrongful termination. What should be your initial recommendation?',
    'options': [
      '1. Settle the case out of court without investigation.',
      '2. Review employment policies and gather all relevant documentation.',
      '3. Advise the business owner to fire the former employee immediately.',
      '4. Ignore the lawsuit in hopes it will resolve itself.'
    ],
    'correctOption': 1,
    'explanation':
        'Gathering all evidence and understanding company policies is crucial for building a strong defense before any settlement decisions are made.'
  },
  {
    'scenario':
        'A contract dispute arises between two business partners. One insists the agreement was verbal while the other claims it was written. What is your legal advice?',
    'options': [
      '1. Settle the dispute without seeking evidence.',
      '2. Encourage both parties to produce any written documentation or records.',
      '3. Advise that verbal agreements are always binding.',
      '4. Immediately file a lawsuit against the opposing partner.'
    ],
    'correctOption': 1,
    'explanation':
        'Collecting any documentation or records is the best way to determine the actual terms of the agreement and resolve the dispute fairly.'
  },
  {
    'scenario':
        'A first-time entrepreneur is considering signing a franchise agreement. What should they do before signing?',
    'options': [
      '1. Sign immediately to secure the opportunity.',
      '2. Consult with a legal advisor and review the contract in detail.',
      '3. Assume all franchise agreements are similar and standard.',
      '4. Negotiate without professional advice to speed up the process.'
    ],
    'correctOption': 1,
    'explanation':
        'A thorough review by a legal professional is essential to understand the terms and protect against unfavorable conditions.'
  },
  {
    'scenario':
        'In a criminal case, a suspect alleges that their constitutional rights were violated during arrest. What is the best course of action?',
    'options': [
      '1. Dismiss the claim without investigation.',
      '2. Investigate the circumstances thoroughly to ascertain any rights violation.',
      '3. Accept the claim without verifying the facts.',
      '4. Advise the suspect to drop the claim to avoid further complications.'
    ],
    'correctOption': 1,
    'explanation':
        'A careful investigation is necessary to determine if the suspect’s rights were indeed violated and to take appropriate legal action if so.'
  },
  {
    'scenario':
        'Your client is facing allegations of defamation on social media. What is the best initial legal strategy?',
    'options': [
      '1. Advise a public apology immediately.',
      '2. Review the content in question and consider legal action based on defamation law.',
      '3. Ignore the allegations in hopes they will dissipate.',
      '4. Counter-attack on social media without seeking legal counsel.'
    ],
    'correctOption': 1,
    'explanation':
        'Reviewing the evidence and understanding the defamation laws is essential before moving forward with any legal action.'
  },
  {
    'scenario':
        'Your client receives a settlement offer in a personal injury case that is lower than expected. What should you advise?',
    'options': [
      '1. Accept the offer to avoid further litigation.',
      '2. Evaluate the case thoroughly and negotiate for a better settlement.',
      '3. Reject the offer and proceed directly to trial.',
      '4. Ignore the offer and wait for a better one.'
    ],
    'correctOption': 1,
    'explanation':
        'It is advisable to evaluate the merits of the case and negotiate to secure a fair settlement before deciding on litigation.'
  },
  {
    'scenario':
        'Your client, an artist, claims that their work has been used without authorization. What is your recommended first step?',
    'options': [
      '1. Advise an immediate public accusation without evidence.',
      '2. Review the copyright details and send a cease and desist letter.',
      '3. Ignore the infringement and hope it stops on its own.',
      '4. Suggest sharing the work publicly to generate support.'
    ],
    'correctOption': 1,
    'explanation':
        'Reviewing copyright details and issuing a cease and desist letter is standard to protect intellectual property.'
  },
  {
    'scenario':
        'A dispute arises over the allocation of profits in a joint business venture. What is your legal advice?',
    'options': [
      '1. Recommend a detailed review of the profit-sharing agreement and renegotiation of terms.',
      '2. Advise immediate litigation without reviewing the agreement.',
      '3. Suggest ignoring the dispute and continuing as usual.',
      '4. Propose an equal split without analyzing the contract.'
    ],
    'correctOption': 0,
    'explanation':
        'A thorough review and negotiation is effective to resolve disputes amicably.'
  }
];
