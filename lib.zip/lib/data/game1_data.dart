final List<Map<String, dynamic>> factOrFauxDatasetIndian = [
  {
    'statement': 'The Indian Constitution is the longest written constitution in the world.',
    'isFact': true,
    'explanation': 'India\'s Constitution is renowned for its extensive length and comprehensive provisions.'
  },
  {
    'statement': 'The Indian Constitution guarantees absolute freedom of speech with no restrictions.',
    'isFact': false,
    'explanation': 'Freedom of speech in India is subject to reasonable restrictions for security, public order, and defamation.'
  },
  {
    'statement': 'The Directive Principles of State Policy in India are enforceable by the courts.',
    'isFact': false,
    'explanation': 'Directive Principles serve as guidelines for governance and are not legally enforceable.'
  },
  {
    'statement': 'Fundamental Rights in the Indian Constitution can be restricted under reasonable conditions.',
    'isFact': true,
    'explanation': 'While Fundamental Rights are guaranteed, they come with reasonable restrictions to maintain public order and security.'
  },
  {
    'statement': 'India is a federal country with a parliamentary form of government.',
    'isFact': true,
    'explanation': 'India follows a federal structure where powers are divided between the central and state governments, with a parliamentary system at its core.'
  },
  {
    'statement': 'The Indian Constitution declares India a secular nation.',
    'isFact': true,
    'explanation': 'The Constitution ensures that the state remains neutral in matters of religion, establishing India as a secular republic.'
  },
  {
    'statement': 'The Indian Constitution allows the application of religious personal laws for its citizens.',
    'isFact': true,
    'explanation': 'Despite being a secular document, the Constitution permits religious personal laws to govern matters such as marriage and inheritance.'
  },
  {
    'statement': 'The President of India is directly elected by the people.',
    'isFact': false,
    'explanation': 'The President is elected indirectly by an Electoral College comprising the elected members of both Houses of Parliament and the state legislatures.'
  },
  {
    'statement': 'The Indian Constitution has been amended more than 100 times.',
    'isFact': true,
    'explanation': 'Since its adoption, the Constitution has undergone over 100 amendments reflecting social, political, and legal changes.'
  },
  {
    'statement': 'The Indian Constitution was adopted on 26 January 1950.',
    'isFact': true,
    'explanation': 'India celebrates Republic Day on January 26th, marking the day the Constitution came into effect.'
  },
  {
    'statement': 'The Preamble of the Indian Constitution declares India as a "Sovereign, Socialist, Secular, Democratic, Republic".',
    'isFact': true,
    'explanation': 'The Preamble outlines the guiding principles of the Indian state and was later amended to include "Socialist" and "Secular".'
  },
  {
    'statement': 'The Fundamental Duties of citizens are enforceable in Indian courts.',
    'isFact': false,
    'explanation': 'While Fundamental Duties are important, they are not legally enforceable by the judiciary.'
  },
  {
    'statement': 'The Supreme Court of India is the highest judicial authority in the country.',
    'isFact': true,
    'explanation': 'The Supreme Court is the apex court in India and has the power of judicial review over legislative and executive actions.'
  },
  {
    'statement': 'The Right to Education is a Fundamental Right in India.',
    'isFact': true,
    'explanation': 'The Right to Education was enshrined as a Fundamental Right through the 86th Amendment of the Constitution.'
  },
  {
    'statement': 'The Indian Constitution mandates the immediate implementation of a Uniform Civil Code.',
    'isFact': false,
    'explanation': 'The Uniform Civil Code is mentioned as a Directive Principle, meaning it is an aspiration rather than a binding mandate.'
  },
  {
    'statement': 'The Indian Constitution allows the declaration of a national emergency by the President.',
    'isFact': true,
    'explanation': 'The Constitution provides for emergency provisions that can be invoked during times of national crisis.'
  },
  {
    'statement': 'The Indian Parliament is bicameral as per the Indian Constitution.',
    'isFact': true,
    'explanation': 'India has a bicameral legislature consisting of the Lok Sabha (House of the People) and the Rajya Sabha (Council of States).'
  },
  {
    'statement': 'The Indian Constitution was drafted solely by Dr. B. R. Ambedkar.',
    'isFact': false,
    'explanation': 'Although Dr. B. R. Ambedkar was a key figure, the drafting was a collaborative effort by the Constituent Assembly.'
  },
  {
    'statement': 'Amendments to the Indian Constitution require a special majority in Parliament and ratification by some states.',
    'isFact': true,
    'explanation': 'Certain amendments require not only a two-thirds majority in Parliament but also ratification by at least half of the state legislatures.'
  },
  {
    'statement': 'The Indian Constitution guarantees freedom of religion to all its citizens.',
    'isFact': true,
    'explanation': 'Every citizen is free to practice, profess, and propagate any religion as guaranteed by the Constitution.'
  },
  {
    'statement': 'The Directive Principles of State Policy are justiciable in Indian courts.',
    'isFact': false,
    'explanation': 'Directive Principles are non-justiciable and serve as guidelines for the state rather than enforceable rights.'
  },
  {
    'statement': 'The Indian Constitution ensures equal protection under the law for all citizens.',
    'isFact': true,
    'explanation': 'The Constitution mandates that every citizen is entitled to equal protection from the law regardless of background.'
  },
  {
    'statement': 'The right to life and personal liberty is guaranteed by the Indian Constitution.',
    'isFact': true,
    'explanation': 'Article 21 of the Constitution ensures that no person is deprived of life or personal liberty except according to the procedure established by law.'
  },
  {
    'statement': 'The Indian Constitution allows reservations in education and employment for certain marginalized groups.',
    'isFact': true,
    'explanation': 'Reservations are provided as affirmative action to uplift historically disadvantaged communities, as outlined in the Constitution.'
  },
  {
    'statement': 'The Indian Constitution explicitly prohibits discrimination on the basis of caste, religion, or gender.',
    'isFact': true,
    'explanation': 'The Constitution guarantees equality and prohibits any discrimination against citizens on various grounds.'
  },
  {
    'statement': 'The Indian Constitution declares India to be a Hindu nation.',
    'isFact': false,
    'explanation': 'The Constitution establishes India as a secular nation, ensuring neutrality towards all religions.'
  },
  {
    'statement': 'Judicial review of legislation is provided for in the Indian Constitution.',
    'isFact': true,
    'explanation': 'The judiciary has the authority to review laws and strike down any that conflict with the Constitution.'
  },
  {
    'statement': 'The Indian Constitution was influenced by the British parliamentary system.',
    'isFact': true,
    'explanation': 'Many features of the Indian Constitution, including its parliamentary system, draw inspiration from the British model.'
  },
  {
    'statement': 'Freedom of speech and expression in India is subject to reasonable restrictions.',
    'isFact': true,
    'explanation': 'Although guaranteed as a Fundamental Right, freedom of speech can be limited in the interest of public order, security, and reputation of others.'
  },
  {
    'statement': 'The Comptroller and Auditor General of India is established by the Indian Constitution.',
    'isFact': true,
    'explanation': 'The CAG is a constitutional authority tasked with auditing the accounts of the government to ensure accountability.'
  },
  {
    'statement': 'The right to property remains a Fundamental Right under the current Indian Constitution.',
    'isFact': false,
    'explanation': 'The right to property was removed as a Fundamental Right by the 44th Amendment in 1978 and is now a constitutional legal right.'
  },
  {
    'statement': 'During a national emergency, certain Fundamental Rights in the Indian Constitution can be suspended.',
    'isFact': true,
    'explanation': 'The Constitution allows for the suspension of certain Fundamental Rights when a national emergency is declared.'
  },
  {
    'statement': 'India uses a first-past-the-post system for its general elections as provided in the Constitution.',
    'isFact': true,
    'explanation': 'The electoral system in India is based on the first-past-the-post method, where the candidate with the most votes wins.'
  },
  {
    'statement': 'The Indian Constitution was enacted by the Constituent Assembly of India.',
    'isFact': true,
    'explanation': 'The Constituent Assembly, elected to draft the Constitution, played a pivotal role in its enactment.'
  },
  {
    'statement': 'The Indian Constitution is the shortest written constitution in the world.',
    'isFact': false,
    'explanation': 'Contrary to this claim, the Indian Constitution is one of the longest due to its detailed and comprehensive nature.'
  },
  {
    'statement': 'The Right to Information is explicitly mentioned as a Fundamental Right in the Indian Constitution.',
    'isFact': false,
    'explanation': 'The Right to Information is granted through statutory law rather than being an explicit Fundamental Right in the Constitution.'
  },
  {
    'statement': 'The Indian Constitution includes provisions for reservations based on social categories like Scheduled Castes and Scheduled Tribes.',
    'isFact': true,
    'explanation': 'Reservations for Scheduled Castes, Scheduled Tribes, and other backward classes are enshrined in the Constitution to promote social justice.'
  },
  {
    'statement': 'The Indian Constitution recognizes the states\' rights within its federal structure.',
    'isFact': true,
    'explanation': 'The Constitution clearly delineates the distribution of powers between the central and state governments.'
  },
  {
    'statement': 'The Indian Constitution allows for the creation of new states within the country.',
    'isFact': true,
    'explanation': 'The process for forming new states is provided for in the Constitution, subject to parliamentary approval and state consent.'
  },
  {
    'statement': 'The minimum voting age in India, as mandated by the Constitution, is 18 years.',
    'isFact': true,
    'explanation': 'Citizens who are 18 years and older have the right to vote as guaranteed by the constitutional provisions.'
  },
  {
    'statement': 'The minimum age for membership in the Lok Sabha is 25 years as per the Indian Constitution.',
    'isFact': true,
    'explanation': 'The Constitution sets the minimum age for Lok Sabha candidates at 25 years.'
  },
  {
    'statement': 'The Governor of an Indian state has the power to dissolve the state legislature on the President\'s advice.',
    'isFact': true,
    'explanation': 'Under certain circumstances, the Governor can dissolve the state legislative assembly as per constitutional guidelines.'
  },
  {
    'statement': 'The Indian Constitution provides for both union and state lists in the Seventh Schedule.',
    'isFact': true,
    'explanation': 'The Seventh Schedule divides subjects into Union, State, and Concurrent lists, outlining the legislative powers at different levels.'
  },
  {
    'statement': 'The official language of India is only Hindi according to the Indian Constitution.',
    'isFact': false,
    'explanation': 'Although Hindi is the official language, English is also used for official purposes, and several regional languages are recognized.'
  },
  {
    'statement': 'The Indian Constitution guarantees free and compulsory education for children between 6 and 14 years of age.',
    'isFact': true,
    'explanation': 'The Right to Education, as provided under the Constitution and subsequent legislation, mandates free and compulsory education for children in this age bracket.'
  },
  {
    'statement': 'The right to peaceful assembly in the Indian Constitution is subject to reasonable restrictions.',
    'isFact': true,
    'explanation': 'Citizens have the right to assemble peacefully, although this right can be regulated in the interest of public order and safety.'
  },
  {
    'statement': 'The Indian Constitution includes explicit provisions for environmental protection.',
    'isFact': true,
    'explanation': 'While not always explicit, environmental protection is supported through various constitutional interpretations and directives related to the right to life.'
  },
  {
    'statement': 'The President of India does not have the power to dissolve the Lok Sabha.',
    'isFact': false,
    'explanation': 'The President dissolves the Lok Sabha on the advice of the Council of Ministers, as per constitutional provisions.'
  },
  {
    'statement': 'An independent Election Commission is established under the Indian Constitution.',
    'isFact': true,
    'explanation': 'The Election Commission is a constitutional body responsible for conducting free and fair elections in India.'
  },
  {
    'statement': 'The Indian judiciary has the power to strike down laws that violate the Constitution.',
    'isFact': true,
    'explanation': 'Judicial review is a key feature of the Indian legal system, allowing courts to invalidate laws that conflict with constitutional mandates.'
  }
];
