final List<Map<String, dynamic>> lawWelfareSchemes = [
  {
    "title": "Dr. Ambedkar Interest Subsidy Scheme",
    "imageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/5/56/Bharat_Ratna_Babasaheb_Dr._Bhimrao_Ambedkar.jpg/800px-Bharat_Ratna_Babasaheb_Dr._Bhimrao_Ambedkar.jpg",
    "description":
        "Provides interest subsidy on educational loans for OBC/EBC law students pursuing overseas education.",
    "foundedYear": "2014",
    "eligibility":
        "OBC/EBC students with annual family income below ₹6 lakh who have taken loans for overseas law education.",
    "documents":
        "Loan sanction letter, income certificate, caste certificate, admission proof.",
    "authority":
        "Ministry of Social Justice and Empowerment, Govt. of India",
    "applicationLink": "https://canarabankcsis.in/ACSIS/"
  },
  {
    "title": "Stipend for Law Graduates (Karnataka)",
    "imageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/98/High_Court_of_Karnataka%2C_Bangalore.jpg/640px-High_Court_of_Karnataka%2C_Bangalore.jpg",
    "description":
        "Provides ₹5000/month stipend to SC/ST law graduates in Karnataka for 4 years to support court practice.",
    "foundedYear": "2017",
    "eligibility": "SC/ST law graduates registered with Karnataka Bar Council.",
    "documents":
        "Caste certificate, enrollment certificate, bank details.",
    "authority": "Social Welfare Department, Govt. of Karnataka",
    "applicationLink":
        "https://swdservices.karnataka.gov.in/swincentive/LAW/LAWHome.aspx"
  },
  {
    "title": "Assistance to Lawyers (Tamil Nadu)",
    "imageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/6/60/Madras_High_Court_2.jpg/640px-Madras_High_Court_2.jpg",
    "description":
        "One-time financial assistance of ₹50,000 for SC/ST law graduates to start legal practice.",
    "foundedYear": "2019",
    "eligibility":
        "Unemployed SC/ST law graduates registered within the last 5 years in Tamil Nadu.",
    "documents":
        "Community certificate, enrollment proof, bar council ID.",
    "authority": "Adi Dravidar & Tribal Welfare Dept., Tamil Nadu",
    "applicationLink": "https://www.myscheme.gov.in/schemes/atlfstp"
  },
  {
    "title": "CM Advocates’ Welfare Scheme (Delhi)",
    "imageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/5/58/Delhi_High_Court.jpg/640px-Delhi_High_Court.jpg",
    "description":
        "Offers life insurance, group medi-claim & financial assistance to registered advocates in Delhi.",
    "foundedYear": "2020",
    "eligibility": "Registered with Delhi Bar Council & voter in Delhi.",
    "documents":
        "Bar ID, voter ID, Aadhar card, bank account proof.",
    "authority": "Law Department, Govt. of NCT Delhi",
    "applicationLink": "https://cmaws.delhi.gov.in/"
  },
  {
    "title": "Bar Council of Maharashtra & Goa Welfare Fund",
    "imageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Mumbai_High_Court_Building.jpg/640px-Mumbai_High_Court_Building.jpg",
    "description":
        "Offers welfare assistance like medical aid, death benefits, and emergency financial help.",
    "foundedYear": "2004",
    "eligibility": "Advocates registered with BCMG & actively practicing.",
    "documents": "Bar ID, medical/financial bills, family details.",
    "authority": "Bar Council of Maharashtra & Goa",
    "applicationLink":
        "https://mail.barcouncilmahgoa.org/v2/welfareschemes/"
  },
  {
    "title": "Internship Programme by Ministry of Law & Justice",
    "imageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5a/Department_of_Legal_Affairs%2C_India_logo.png/480px-Department_of_Legal_Affairs%2C_India_logo.png",
    "description":
        "Gives law students exposure to legislative drafting and legal processes at the national level.",
    "foundedYear": "2016",
    "eligibility": "2nd+ year law students from recognized institutions.",
    "documents": "CV, recommendation letter, college ID proof.",
    "authority": "Ministry of Law & Justice, India",
    "applicationLink": "https://www.myscheme.gov.in/schemes/llbip"
  },
  {
    "title": "NALSA Legal Aid Services",
    "imageUrl": "https://upload.wikimedia.org/wikipedia/en/thumb/7/7b/National_Legal_Services_Authority_Logo.png/480px-National_Legal_Services_Authority_Logo.png",
    "description":
        "Provides free legal services to eligible citizens and law students can volunteer under it.",
    "foundedYear": "1995",
    "eligibility":
        "Law students (for volunteering), underprivileged citizens (for aid).",
    "documents": "For volunteering: College ID, resume.",
    "authority": "National Legal Services Authority (NALSA)",
    "applicationLink":
        "https://nalsa.gov.in/services/legal-aid/claiming-free-legal-aid-application-procedure"
  },
  {
    "title": "Bar Council of Delhi Welfare Schemes",
    "imageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Bar_Council_of_Delhi_logo.png/480px-Bar_Council_of_Delhi_logo.png",
    "description":
        "Provides benefits to needy advocates in Delhi like emergency medical help, financial grants, etc.",
    "foundedYear": "2002",
    "eligibility": "Must be registered with Bar Council of Delhi.",
    "documents": "Membership ID, reason for support, medical/legal bills.",
    "authority": "Bar Council of Delhi",
    "applicationLink":
        "https://delhibarcouncil.com/download-forms.php"
  },
  {
    "title": "Supreme Court Legal Services Committee Internship",
    "imageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Supreme_Court_of_India_3.jpg/640px-Supreme_Court_of_India_3.jpg",
    "description":
        "Internship opportunity for law students to assist the Supreme Court Legal Services Committee.",
    "foundedYear": "2013",
    "eligibility": "Final/penultimate year law students.",
    "documents": "Application form, resume, recommendation letter.",
    "authority": "Supreme Court Legal Services Committee",
    "applicationLink":
        "https://sclsc.gov.in/uploads/Scheme%20for%20Internship%20programme-12122022115124.pdf"
  },
  {
    "title": "National Scholarship Portal (Law Students)",
    "imageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/National_Emblem_of_India.svg/1200px-National_Emblem_of_India.svg.png",
    "description":
        "Centralized platform for scholarships, including Pre & Post-Matric and Top Class Education for law students.",
    "foundedYear": "2015",
    "eligibility": "Varies per scholarship: SC/ST/OBC/Minority categories.",
    "documents": "Income, caste, domicile certificates, mark sheets.",
    "authority": "Ministry of Social Justice / Tribal Affairs / Minority Affairs",
    "applicationLink": "https://scholarships.gov.in/"
  },
];
