final Map<String, Map<String, String>> faqData = {
   "Common Questions": {
    "How do I file an FIR?": "Visit any police station and provide details about the crime. If the police refuse to register it, escalate to senior officers or magistrate court.",
    "What rights do I have when arrested?": "You have the right to know the reason, contact a lawyer, and remain silent during interrogation.",
    "How can I legally save income tax?": "Invest in tax-saving instruments like PPF, ELSS, or insurance policies, and claim deductions under Section 80C.",
    "What documents must I carry while driving?": "Carry your driving license, vehicle registration certificate (RC), insurance papers, and pollution under control (PUC) certificate.",
    "What should I do if sold a defective product?": "You can request a repair, replacement, or refund under the Consumer Protection Act, 2019.",
    "Can police arrest me without a warrant?": "Yes, if the offense is cognizable (serious), police can arrest you without a warrant.",
    "How can I file an RTI application?": "Submit your RTI request online or offline to the Public Information Officer of the concerned department with the prescribed fee.",
    "What are my fundamental rights?": "They include the Right to Equality, Freedom, Protection from Exploitation, Freedom of Religion, and Right to Constitutional Remedies.",
    "What to do in case of online harassment?": "Collect evidence and file a complaint at the local Cyber Crime Cell or through the national cybercrime reporting portal.",
    "How do I legally register a marriage?": "Submit required documents like age proof, identity proofs, affidavits, and photos at the Marriage Registrar's office.",
    "What actions can be taken against domestic violence?": "File a complaint under the Protection of Women from Domestic Violence Act, seeking protection orders, maintenance, or shelter.",
    "Can I challenge a property sale suspected of fraud?": "Yes, file a civil lawsuit alleging fraud, providing necessary evidence to support your claim.",
    "What are my rights if fired without notice?": "You may seek legal remedy, including compensation or reinstatement, if termination violates labor laws or your contract terms.",
    "Can I legally record a police officer during arrest?": "Yes, recording in public without hindering police work is generally allowed, but be mindful of local regulations.",
    "What should I do after receiving an income tax notice?": "Respond promptly by submitting the requested documents or clarifications to avoid further penalties or legal actions."
  },

  "Constitutional & Fundamental Rights": {
    // Original questions
    "What are my fundamental rights as an Indian citizen?":
        "They include the Right to Equality, Freedom, Protection from Exploitation, Freedom of Religion, Cultural & Educational Rights, and the Right to Constitutional Remedies. These rights protect individuals from government overreach and ensure a fair, just society.",
    "Can the government restrict my rights?":
        "Yes, reasonable restrictions can be placed in the interests of national security, public order, decency, or morality. However, such restrictions must be legally justified and proportionate.",
    "What is the difference between Fundamental Rights and Directive Principles?":
        "Fundamental Rights are enforceable in court, ensuring individual liberties. Directive Principles guide the state to establish social and economic justice, but they are not directly enforceable.",
    "What are the legal remedies available if my rights are violated?":
        "You may file a writ petition in the Supreme Court (Article 32) or High Court (Article 226). Courts can issue writs like Habeas Corpus, Mandamus, Prohibition, Certiorari, and Quo Warranto for immediate relief.",
    "Can I challenge a law in court if I feel it violates my rights?":
        "Yes. You can file a petition or Public Interest Litigation (PIL) challenging any law infringing upon your Fundamental Rights. The court may strike down or modify the law if it’s unconstitutional.",
    "How do Directive Principles influence legislation?":
        "Though not enforceable, they guide policymakers to create laws that further social welfare, eradicate inequalities, and promote a just social order.",
    "What are Fundamental Duties and why are they important?":
        "Fundamental Duties (Article 51A) remind citizens to respect the Constitution, the national flag, and foster harmony. While not legally enforceable, they encourage responsible civic behavior.",
    // 10 Additional Questions
    "How are Fundamental Rights enforced by the judiciary?":
        "The judiciary enforces Fundamental Rights primarily through writ petitions and Public Interest Litigations, ensuring prompt judicial review and protection.",
    "What is the significance of Article 32 in the Indian Constitution?":
        "Article 32 empowers citizens to directly approach the Supreme Court for enforcement of their Fundamental Rights, making it a cornerstone of judicial protection.",
    "Can Fundamental Rights be suspended and under what circumstances?":
        "Yes, during a state of emergency, many Fundamental Rights can be suspended except for the rights to life and personal liberty as per constitutional provisions.",
    "What role do state governments play in protecting Fundamental Rights?":
        "State governments implement and uphold these rights locally, though their actions are subject to judicial oversight to ensure constitutional compliance.",
    "How does the Right to Equality protect marginalized groups?":
        "It prohibits discrimination on grounds such as religion, caste, gender, and ethnicity, ensuring equal treatment and opportunities for all citizens.",
    "Is freedom of speech an absolute right in India?":
        "No, it is subject to reasonable restrictions such as those for public order, decency, and security, balancing individual liberty with societal interests.",
    "What legal actions can be taken if a Fundamental Right is infringed?":
        "Affected individuals can file writ petitions in the High Court or Supreme Court, or seek intervention from human rights commissions.",
    "What is the role of the National Human Rights Commission in protecting rights?":
        "It investigates human rights violations, monitors state actions, and recommends corrective measures to protect citizens' rights.",
    "How has judicial activism impacted the enforcement of Fundamental Rights?":
        "Judicial activism has broadened the interpretation of rights, often leading to progressive rulings that enhance citizen protection.",
    "What is the importance of the Right to Life and Personal Liberty?":
        "Enshrined in Article 21, it guarantees every individual the right to live with dignity and protects against arbitrary deprivation of life or freedom."
  },
  "Criminal Law & Police Matters": {
    // Original questions
    "What should I do if I get arrested?":
        "Stay calm, ask for the reason for arrest, and request to contact a lawyer or family. Do not resist physically. You have the right to remain silent and should cooperate calmly with lawful procedures.",
    "Do I have the right to call a lawyer immediately?":
        "Yes. Under Article 22 of the Constitution and Section 41D of the CrPC, you have the right to consult a lawyer even during questioning.",
    "How do I file an FIR?":
        "Visit any police station with details of the cognizable offense. If the police refuse, you can approach senior officers or file a complaint before a Magistrate under Section 156(3) CrPC.",
    "Can the police arrest me without a warrant?":
        "For cognizable offenses, police may arrest without a warrant; for non-cognizable offenses, a warrant is generally required.",
    "What should I do if the police refuse to register my complaint?":
        "Escalate the matter by approaching senior police officials, filing a complaint before a Magistrate, or contacting the State Human Rights Commission.",
    "What is the role of bail and how do I apply for it?":
        "Bail allows temporary release from custody pending trial. Applications are made before the court considering the nature of the offense and risk of flight.",
    "What is the difference between cognizable and non-cognizable offenses?":
        "Cognizable offenses are serious crimes where police can arrest without a warrant; non-cognizable offenses require a warrant and court approval for investigation.",
    "How do I deal with a wrongful arrest or police harassment?":
        "Document the incident, file a complaint with higher authorities or human rights commissions, and seek legal representation to challenge the action.",
    // 10 Additional Questions
    "What rights do I have during police interrogation?":
        "During interrogation, you have the right to remain silent, to have a lawyer present, and to be informed of the charges against you.",
    "Can I record the police during an arrest?":
        "Yes, as long as it does not interfere with police duties; however, be aware of local laws regarding recording in public places.",
    "What is the procedure for obtaining anticipatory bail?":
        "Anticipatory bail can be sought under Section 438 of the CrPC, allowing a person to avoid arrest by obtaining court protection in advance.",
    "How does the police conduct a preliminary investigation?":
        "They collect evidence, record statements, and secure the crime scene to determine the nature of the offense before formal charges are filed.",
    "What should I do if I witness police misconduct?":
        "Safely record the incident if possible, file a complaint with the Internal Affairs or higher police authorities, and consider contacting legal support.",
    "Can I file a complaint against the police for inaction?":
        "Yes, you can file a complaint with the relevant police oversight body or human rights commission if you experience or witness inaction.",
    "What is the process of police verification during FIR registration?":
        "Police verification involves cross-checking the details provided in the complaint through visits and interviews to validate the information.",
    "How can a lawyer help during an arrest?":
        "A lawyer can advise you on your rights, help ensure you are not coerced into self-incrimination, and represent you during police questioning.",
    "What is the role of the CrPC in police procedures?":
        "The Code of Criminal Procedure (CrPC) sets out the procedures for arrest, investigation, and trial, ensuring legal safeguards are maintained.",
    "How are cases of police brutality handled legally?":
        "Such cases can be challenged in court through writ petitions, and complaints can be lodged with human rights commissions and internal police oversight bodies."
  },
  "Civil Law & Property Disputes": {
    // Original questions
    "How can I resolve a property dispute legally?":
        "You can file a civil suit, opt for mediation, or approach Lok Adalats. Proper documentation and evidence such as sale deeds and wills are critical.",
    "What is the legal process for property inheritance?":
        "Inheritance is governed by personal laws. Legal heirs must obtain a legal heir certificate and update property records through a formal process.",
    "What is the difference between lease and rental agreements?":
        "A lease typically lasts for a longer term (often 12 months or more) and may require registration, while rental agreements are usually for shorter durations.",
    "How can I take legal action against illegal construction?":
        "File a complaint with the municipal authorities and seek an injunction from the civil court. Environmental or zoning laws may also be applicable.",
    "What are my rights as a tenant or landlord?":
        "Tenants have rights to habitable living conditions and privacy, while landlords can expect timely payment of rent and adherence to the lease terms.",
    "What is an Encumbrance Certificate and why is it important?":
        "It certifies that a property is free from legal liabilities or mortgages, ensuring a clear title for potential buyers or heirs.",
    // 10 Additional Questions
    "What are the steps involved in buying a property legally?":
        "Steps include verifying the title deed, conducting due diligence, negotiating terms, and registering the sale at the local sub-registrar's office.",
    "How do I verify the authenticity of property documents?":
        "Consult a property lawyer, check with the local registrar’s office, and review the document’s history for any irregularities.",
    "What is the process for registering a property?":
        "Registration involves submission of sale deeds, payment of stamp duty, and completion of formalities at the local sub-registrar's office.",
    "How can I resolve disputes related to shared property ownership?":
        "Disputes can be resolved through mediation, family settlements, or filing a partition suit in the civil court.",
    "What legal recourse do I have if my neighbour encroaches on my property?":
        "You can file a suit for trespass, seek an injunction to stop further encroachment, and claim damages if applicable.",
    "How does the law address property disputes in joint families?":
        "Joint family disputes are addressed under personal laws and may require partition proceedings or mediation among family members.",
    "Can I challenge a property sale if I suspect fraud?":
        "Yes, you can file a legal suit alleging fraud, and if proven, the sale may be annulled or compensated.",
    "What is the role of a property lawyer in real estate transactions?":
        "A property lawyer verifies documents, checks titles, drafts agreements, and ensures that all legal requirements are met.",
    "How are disputes over rental deposits resolved?":
        "Such disputes are generally settled through negotiation, but if unresolved, can be taken to consumer court or small claims court.",
    "What should be included in a legally sound lease agreement?":
        "A comprehensive lease should include the duration, rent amount, security deposit details, maintenance obligations, and termination clauses."
  },
  "Consumer Rights & Protection": {
    // Original questions
    "What can I do if I am sold a defective product?":
        "You can seek repair, replacement, or refund under the Consumer Protection Act, 2019. If denied, you may file a complaint with the Consumer Disputes Redressal Commission.",
    "How do I file a consumer complaint?":
        "You may approach the District, State, or National Consumer Disputes Redressal Commission depending on the claim amount and file your complaint either online or offline.",
    "What are my rights if a company refuses to provide a warranty or refund?":
        "You have the right to a remedy under consumer law. You can send a legal notice and, if unresolved, file a consumer case for deficiency in service.",
    "Can I take legal action against misleading advertisements?":
        "Yes. Misleading advertisements can be challenged by filing complaints with the Advertising Standards Council of India or consumer forums.",
    "What is the punishment for online fraud or scams?":
        "Online fraud is punishable under the IT Act and the Consumer Protection Act, with penalties ranging from fines to imprisonment depending on the severity.",
    // 10 Additional Questions
    "How does the Consumer Protection Act safeguard my rights?":
        "The Act provides for redressal mechanisms for defective goods, deficient services, and unfair trade practices, ensuring speedy justice.",
    "What steps should I take if my service is substandard?":
        "First, contact the service provider for a resolution. If unsatisfied, file a complaint with the appropriate Consumer Disputes Redressal Commission.",
    "How can I verify if a product meets safety standards?":
        "Check for certification marks, compliance labels, and regulatory approvals on the product packaging or official websites.",
    "Can I get compensation for financial loss due to a defective product?":
        "Yes, the consumer law allows for compensation for both direct financial loss and additional damages like inconvenience.",
    "What are the responsibilities of a seller under consumer law?":
        "Sellers must provide products that meet quality and safety standards, honor warranties, and address customer grievances promptly.",
    "How do I return a product bought online?":
        "Review the seller’s return policy, document the defect or issue, and follow the prescribed procedure to initiate a return or refund.",
    "What legal actions can be taken against false advertising?":
        "False advertising can be challenged by filing complaints with regulatory bodies like the Advertising Standards Council of India or consumer courts.",
    "How is compensation determined in consumer disputes?":
        "Compensation is determined based on the extent of loss, inconvenience, and may include punitive damages in cases of gross negligence.",
    "What role does the Consumer Forum play in dispute resolution?":
        "Consumer Forums provide an accessible and cost-effective avenue for resolving disputes without lengthy litigation processes.",
    "How can consumers educate themselves about their rights?":
        "Consumers can refer to government websites, consumer organizations, and legal advisories to stay informed about their rights and remedies."
  },
  "Family Law & Marriage": {
    // Original questions
    "What are the legal rights of a married woman in India?":
        "A married woman is entitled to maintenance, shared residence, and protection under various laws such as the Domestic Violence Act. She may also have rights to co-ownership in joint family property.",
    "What is the process for legal divorce in India?":
        "Divorce proceedings vary by personal law; for Hindus, mutual consent divorce is available, whereas contested divorces require proof of grounds like cruelty or desertion.",
    "What are the laws related to child custody in case of divorce?":
        "Custody is decided based on the child's best interests, with courts considering factors like parental capability, stability, and the child's wishes.",
    "What is the legal age for marriage in India?":
        "The legal minimum age is 21 for men and 18 for women, and marriages below these ages are considered child marriages with legal consequences.",
    "How can I get maintenance or alimony?":
        "Maintenance can be sought under Section 125 CrPC or relevant personal laws, depending on the circumstances and the applicable jurisdiction.",
    "What is the procedure to register a marriage under the Special Marriage Act?":
        "Couples must submit a notice to the Marriage Registrar, wait for an objection period, and then solemnize the marriage in the presence of witnesses.",
    // 10 Additional Questions
    "What legal documents are required for marriage registration?":
        "Generally, proof of age, address, identity documents, photographs, and a marriage affidavit are required to register a marriage.",
    "How does the law address dowry harassment?":
        "The Dowry Prohibition Act criminalizes dowry demands and provides legal remedies for victims, including protection orders and criminal prosecution.",
    "What are the grounds for annulment of a marriage?":
        "Grounds may include fraud, coercion, impotence, or a marriage that is void due to legal impediments such as close blood relations.",
    "How is child custody decided in contested divorces?":
        "The court evaluates the child's welfare, stability, and the ability of each parent to provide a nurturing environment, often preferring joint custody or the primary caregiver arrangement.",
    "Can a marriage be legally dissolved on mutual consent?":
        "Yes, mutual consent divorce is a simplified process available under the law where both parties agree on separation and related issues.",
    "What is the role of mediation in family disputes?":
        "Mediation offers an amicable and less adversarial method of resolving disputes, often recommended by courts before litigation.",
    "How does the law protect against domestic violence in a marriage?":
        "The Protection of Women from Domestic Violence Act provides measures such as restraining orders, monetary relief, and shelter to protect victims.",
    "What legal steps can be taken to secure custody of a child?":
        "Parents can file a custody suit, provide evidence of a stable environment, and request interim orders to safeguard the child's welfare during proceedings.",
    "Are same-sex marriages legally recognized in India?":
        "As of now, same-sex marriages are not legally recognized in India, though there are ongoing legal debates and activism on the issue.",
    "What are the legal implications of living together without marriage?":
        "Cohabitation may have implications for property rights and maintenance; however, it is not legally equivalent to marriage and is governed by different legal standards."
  },
  "Employment & Labour Laws": {
    // Original questions
    "What are my rights if I am fired without notice?":
        "You may be entitled to compensation or reinstatement if the termination violates statutory notice periods or contract terms. Filing a complaint with the Labour Commissioner is advisable.",
    "What can I do if my employer doesn’t pay my salary?":
        "You can file a complaint under the Payment of Wages Act or approach the Labour Commissioner. Legal recourse is available if contractual terms are breached.",
    "What are the working hour limits under Indian labour laws?":
        "Typically, the limit is 8 hours a day and 48 hours a week, with provisions for overtime pay if these limits are exceeded.",
    "Do I have the right to maternity or paternity leave?":
        "Women are entitled to 26 weeks of paid maternity leave under the Maternity Benefit Act. Paternity leave policies vary by employer and are not mandated by law.",
    "Can my employer refuse to give me my provident fund (PF)?":
        "No, PF contributions are mandatory under the Employees’ Provident Funds & Miscellaneous Provisions Act. Non-compliance can be legally challenged.",
    "What is the procedure for claiming compensation for a workplace injury?":
        "Report the injury to your employer immediately, obtain medical records, and file a claim under the Employees’ Compensation Act or through the Employee State Insurance scheme.",
    // 10 Additional Questions
    "What is considered unfair dismissal under Indian labour laws?":
        "Unfair dismissal involves termination without proper notice or due process, or in violation of statutory or contractual obligations.",
    "How do I file a complaint against wage theft?":
        "File a complaint with the Labour Commissioner or the Industrial Tribunal, providing evidence of unpaid wages and contract details.",
    "What is the process for claiming gratuity?":
        "Gratuity claims require proof of continuous service and are processed under the Payment of Gratuity Act after resignation, retirement, or termination.",
    "Can an employer change my employment terms unilaterally?":
        "No, employment terms generally cannot be altered without your consent or without following due process as per the employment contract or labour laws.",
    "What are my rights regarding overtime pay?":
        "Overtime work must be compensated at a higher rate as stipulated by law and as per the terms of your employment contract.",
    "How does the law protect contract workers?":
        "Contract workers are covered under the Contract Labour (Regulation and Abolition) Act, which ensures they receive basic wages and work conditions.",
    "What should I do if I face workplace harassment?":
        "Report the incident to your employer’s HR department, file a formal complaint, and if necessary, approach labour authorities or legal counsel.",
    "Is there legal protection for whistleblowers in the workplace?":
        "Yes, certain laws provide protection for employees who expose malpractice or illegal activities within organizations.",
    "What is the procedure for applying for statutory benefits?":
        "You must submit the requisite forms and documentation to the relevant government authority or your employer as prescribed by law.",
    "How can I challenge an employer's decision legally?":
        "You may file a grievance through internal dispute resolution mechanisms, seek mediation, or pursue legal action through the labour courts."
  },
  "Taxation & Financial Matters": {
    // Original questions
    "What happens if I don’t file my income tax return?":
        "Failure to file your income tax return can result in penalties, interest on unpaid taxes, and in severe cases, prosecution.",
    "How can I legally save on income tax?":
        "Invest in tax-saving instruments like PPF, ELSS, and insurance policies. Claim deductions under relevant sections such as 80C and declare allowable exemptions.",
    "What should I do if I get a notice from the Income Tax Department?":
        "Respond within the stipulated time by submitting the requested documents or clarifications. Non-response may lead to further scrutiny or penalties.",
    "Can I challenge a tax penalty imposed on me?":
        "Yes, you can file an appeal with the Commissioner of Income Tax (Appeals) and, if necessary, approach the Income Tax Appellate Tribunal.",
    "What are the different types of taxes in India?":
        "Major taxes include Income Tax, Goods and Services Tax (GST), Corporate Tax, and various state-level taxes such as Stamp Duty.",
    // 10 Additional Questions
    "What is the process for filing an income tax return in India?":
        "You can file your ITR online via the Income Tax Department's e-filing portal by submitting the required forms, supporting documents, and verifying your return.",
    "How does the Income Tax Department verify tax returns?":
        "Verification is done through data matching, scrutiny of high-value transactions, and, in some cases, physical audits.",
    "What deductions are available under Section 80C?":
        "Investments in PPF, ELSS, NSC, and payment of life insurance premiums can be deducted up to a prescribed limit under Section 80C.",
    "How is tax liability calculated for salaried individuals?":
        "It is based on the taxable income after deductions, applicable tax slabs, and allowances provided under the Income Tax Act.",
    "Can I file for a tax refund if excess tax has been deducted?":
        "Yes, if excess tax is deducted, you can claim a refund when you file your income tax return and reconcile the differences.",
    "What is the importance of maintaining proper financial records?":
        "Accurate records are essential for filing returns, supporting claims for deductions, and providing evidence in case of an audit.",
    "How do capital gains tax rules apply to property sales?":
        "Capital gains tax depends on the holding period of the asset, with different rates for short-term and long-term gains.",
    "What are the penalties for tax evasion?":
        "Penalties for tax evasion include fines, interest on unpaid taxes, and, in severe cases, prosecution and imprisonment.",
    "How does the tax department address discrepancies in filed returns?":
        "Discrepancies can trigger scrutiny or audits, and you may be asked to furnish supporting documentation to verify your claims.",
    "What are the benefits of filing taxes on time?":
        "Timely filing avoids penalties, ensures timely refunds, and demonstrates compliance with legal and financial obligations."
  },
  "Traffic & Motor Vehicle Laws": {
    // Original questions
    "What are the penalties for breaking traffic rules?":
        "Penalties can range from fines and license suspension to imprisonment in severe cases, as per the Motor Vehicles Act.",
    "What should I do if I receive a wrong traffic challan?":
        "Collect evidence such as photographs or GPS data, and contest the challan in traffic court or through an online appeal if available.",
    "Can I legally drive without a physical copy of my driving license?":
        "Yes, digital copies on government-authorized apps like DigiLocker or mParivahan are acceptable if they are valid.",
    "What are my rights if my vehicle is towed without proper reason?":
        "You can request official documentation justifying the tow, and if found improper, file a complaint with the relevant transport authority.",
    "What should I do in case of a hit-and-run accident?":
        "Immediately notify emergency services and the police, collect any available evidence, and cooperate with the investigation.",
    // 10 Additional Questions
    "What documents should I always carry while driving?":
        "Always carry a valid driving license, vehicle registration certificate, insurance documents, and a pollution control certificate.",
    "How do I contest a traffic challan?":
        "You can contest it by filing an appeal in the designated traffic court or through the online portal provided by the transport authority.",
    "What is the process for renewing a driving license?":
        "Renewal involves submitting an application, providing necessary documents and photographs, and paying the prescribed fee at the RTO.",
    "Are there different rules for commercial vehicles?":
        "Yes, commercial vehicles are subject to stricter regulations including specific permits, safety requirements, and hours of service.",
    "What is the importance of road safety audits?":
        "Road safety audits help identify potential hazards and recommend improvements to reduce accidents and improve traffic flow.",
    "How does the Motor Vehicles Act protect drivers?":
        "It outlines driver responsibilities, prescribes penalties for violations, and provides mechanisms for compensation in case of accidents.",
    "Can I be fined for using mobile phones while driving?":
        "Yes, using a mobile phone without a hands-free system while driving is illegal and can result in fines or other penalties.",
    "What happens if I drive under the influence of alcohol?":
        "Driving under the influence can result in heavy fines, license suspension, or imprisonment, depending on the severity and prior offenses.",
    "How are traffic violations recorded and monitored?":
        "Violations are monitored through traffic cameras, police patrols, and automated systems like speed detectors.",
    "What steps should I take if involved in a road accident?":
        "Ensure safety first, call emergency services, exchange details with other parties, and report the incident to your insurance company promptly."
  },
  "Digital & Cyber Laws": {
    // Original questions
    "How can I take legal action for online harassment?":
        "Collect evidence such as screenshots and chat logs, then file a complaint with your local Cyber Crime Cell under the IT Act provisions.",
    "Can someone go to jail for posting fake news or defamation on social media?":
        "Yes, online defamation or spreading fake news that incites violence can lead to criminal charges and potential imprisonment under applicable laws.",
    "What is the punishment for hacking someone’s social media account?":
        "Hacking is a serious offense under the IT Act and may result in imprisonment along with heavy fines depending on the extent of the breach.",
    "How can I report a cyber fraud or scam?":
        "File a complaint with the local Cyber Crime Cell or through the national cybercrime portal, providing all relevant evidence and transaction details.",
    "Is it legal to record phone calls or WhatsApp chats without consent?":
        "Recording private conversations without consent may be illegal under privacy laws; always obtain consent before recording.",
    // 10 Additional Questions
    "What constitutes cyber harassment under Indian law?":
        "Cyber harassment involves persistent online actions such as threats, stalking, or defamation that cause mental distress, and is punishable under the IT Act.",
    "How does the IT Act address identity theft?":
        "The IT Act penalizes unauthorized use of someone’s personal data or identity, with strict penalties including fines and imprisonment.",
    "Can I sue for defamation online?":
        "Yes, victims of online defamation can file civil suits for damages under defamation laws if their reputation is harmed.",
    "What is the legal process for filing a cybercrime complaint?":
        "You should approach your local cyber cell or file a complaint on the national cybercrime portal, ensuring you provide detailed evidence of the incident.",
    "How does digital evidence get validated in court?":
        "Digital evidence is subjected to forensic analysis and must follow a strict chain of custody to be accepted as valid in court.",
    "What are my rights regarding online privacy?":
        "Your online privacy is protected under Indian law, and any breach can be challenged legally; however, this right is subject to reasonable restrictions.",
    "How do cyber laws protect against unauthorized data breaches?":
        "Companies are mandated to secure user data and notify affected individuals in case of a breach, with penalties imposed for non-compliance.",
    "Can minors be held accountable under cyber laws?":
        "While minors may be subject to certain provisions, the focus is usually on rehabilitation rather than strict punitive measures.",
    "What role do cyber cells play in enforcing digital laws?":
        "Cyber cells investigate online offenses, gather digital evidence, and assist in the prosecution of cybercriminals.",
    "Are there any legal measures to counter online piracy?":
        "Online piracy is addressed under copyright laws and the IT Act, with legal measures including fines and imprisonment for offenders."
  },
  "RTI (Right to Information) & Public Rights": {
    // Original questions
    "How can I file an RTI application?":
        "Submit a written or online RTI application to the Public Information Officer of the relevant department, along with the required fee.",
    "What type of information can I request under RTI?":
        "You can request records, documents, data, and samples from public authorities, except for information exempted for reasons like national security or personal privacy.",
    "Can a government department refuse to give me information?":
        "Yes, if the information falls under exempt categories such as national security, commercial confidence, or internal deliberations.",
    "What is the process for filing a complaint if my RTI is rejected?":
        "You can file a first appeal with the designated Public Information Officer and, if unsatisfied, a second appeal with the Information Commission.",
    "How long does a public authority have to respond to an RTI request?":
        "Public authorities are generally required to respond within 30 days, although sensitive cases may have shorter timelines.",
    // 10 Additional Questions
    "What is the eligibility criteria to file an RTI application?":
        "Any citizen of India can file an RTI application. In certain cases, foreign nationals residing in India may also be eligible.",
    "How do I locate the appropriate public authority for my RTI request?":
        "Check the official website of the concerned department or the central RTI portal which lists jurisdiction-specific information.",
    "Can I file an RTI application online?":
        "Yes, many government departments have online portals for submitting RTI applications, making the process quicker and more transparent.",
    "What fees are involved in filing an RTI application?":
        "A nominal fee is generally required, which varies by state. Payment methods include postal orders or online transactions, as specified by the authority.",
    "How can I appeal if my RTI request is denied?":
        "You can file a first appeal with the Public Information Officer and, if necessary, a second appeal with the Information Commission.",
    "What are the common reasons for denial of RTI requests?":
        "Requests may be denied if they involve sensitive information related to national security, personal data, or internal policy deliberations.",
    "How is sensitive information handled under RTI?":
        "Sensitive information is either redacted or withheld to protect privacy, security, or commercial interests, as mandated by law.",
    "What is the role of the Information Commission in RTI matters?":
        "The Information Commission adjudicates appeals, ensuring public authorities comply with the RTI Act and promoting transparency.",
    "Can I request information on government expenditure under RTI?":
        "Yes, RTI can be used to request detailed information on government spending, procurement, and financial transactions.",
    "What is the timeline for receiving a response to an RTI application?":
        "Typically, the responding authority must provide the requested information within 30 days from the date of application submission."
  },
  "Women’s Rights & Protection": {
    // Original questions
    "What should I do if I face workplace harassment?":
        "Report the issue to your employer’s Internal Complaints Committee (ICC) or HR department. If unresolved, approach local authorities or file a police complaint.",
    "Can a husband legally force his wife to stay with him?":
        "No, forced cohabitation is considered a form of cruelty. A wife may seek legal remedies such as protection orders or separation.",
    "What is the punishment for domestic violence in India?":
        "Under the Protection of Women from Domestic Violence Act and the IPC, perpetrators can face imprisonment, fines, and restraining orders.",
    "What are the legal provisions for abortion in India?":
        "The Medical Termination of Pregnancy (MTP) Act permits abortions under specific conditions and gestational limits to protect the health of the woman.",
    "How can a woman file a complaint against dowry harassment?":
        "A complaint can be filed under Section 498A of the IPC or the Dowry Prohibition Act at the nearest police station or through legal aid services.",
    "What is the procedure for getting a restraining order against an abuser?":
        "File an application in the local Magistrate’s Court under domestic violence laws, which may issue an order barring the abuser from contact.",
    // 10 Additional Questions
    "What legal protections exist against sexual harassment at the workplace?":
        "The Sexual Harassment of Women at Workplace Act, 2013 provides guidelines for redressal, prevention mechanisms, and protection for affected employees.",
    "How does the law address marital rape in India?":
        "Marital rape is not explicitly criminalized in India, though there are ongoing debates and legal interpretations regarding consent within marriage.",
    "What are the legal rights of women regarding property inheritance?":
        "Women have equal rights to inherit property, subject to personal laws. Recent amendments like the Hindu Succession (Amendment) Act have strengthened these rights.",
    "Can women approach the court directly for protection orders?":
        "Yes, women can directly file for protection orders under domestic violence laws without needing prior mediation.",
    "What steps should a woman take if her safety is at risk?":
        "She should immediately contact the police, seek shelter, and reach out to support groups or helplines dedicated to women's safety.",
    "How effective are the laws in preventing dowry-related harassment?":
        "While strong laws exist, their effectiveness largely depends on enforcement and social awareness; many cases require both legal and societal intervention.",
    "What support systems are available for survivors of domestic abuse?":
        "Support includes NGOs, women’s shelters, counseling services, and legal aid centers that provide rehabilitation and assistance.",
    "Can women file a case if they are discriminated against at work?":
        "Yes, discrimination at work can be challenged under various laws including the Equal Remuneration Act and relevant labour regulations.",
    "How do courts determine the compensation in cases of sexual harassment?":
        "Compensation is determined based on factors such as mental and physical trauma, loss of income, and the overall impact on the victim's life.",
    "What role do women’s commissions play in safeguarding rights?":
        "National and state women’s commissions monitor the enforcement of women’s rights, investigate complaints, and recommend measures to improve safety and equality."
  },
  "Citizenship, Visa & Immigration": {
    // Original questions
    "What are the legal ways to acquire Indian citizenship?":
        "Citizenship can be acquired by birth, descent, registration, or naturalization, each with its own set of eligibility criteria as outlined in the Citizenship Act.",
    "Can a foreigner become an Indian citizen?":
        "Yes, foreigners can acquire Indian citizenship through naturalization if they meet the required residency and other criteria, though dual citizenship is not permitted.",
    "What should I do if my visa expires while in India?":
        "Immediately contact the FRRO (Foreigners Regional Registration Office) to apply for an extension or exit visa to avoid penalties or deportation.",
    "What is the penalty for overstaying a visa in India?":
        "Overstaying a visa can result in fines, detention, blacklisting, or deportation, depending on the duration and circumstances.",
    "How can I file a complaint against passport fraud?":
        "Report passport fraud to the local police, Cyber Crime Cell, or the Regional Passport Office for administrative and legal action.",
    "How can Overseas Citizens of India (OCI) obtain legal benefits in India?":
        "OCIs enjoy multiple-entry visas and other benefits, though they do not have full citizenship rights like voting or holding public office.",
    // 10 Additional Questions
    "What are the criteria for naturalization as an Indian citizen?":
        "Criteria include a prescribed period of residency, proficiency in a local language, renunciation of previous citizenship, and adherence to legal requirements.",
    "How long do I need to reside in India before applying for citizenship?":
        "Typically, a continuous residence of 12 years is required, though there are exceptions for spouses of Indian citizens and other categories.",
    "What is the process for obtaining an OCI card?":
        "Applicants must submit proof of Indian origin, identity documents, and a completed application form as per the guidelines of the Ministry of Home Affairs.",
    "Can dual citizenship be held in India?":
        "India does not allow dual citizenship; however, the OCI card provides many benefits similar to those of full citizens without granting political rights.",
    "How do I renew my visa or extend my stay legally?":
        "Contact the FRRO with the required documents before your visa expires to apply for an extension or renewal according to the prescribed process.",
    "What are the common reasons for visa rejection?":
        "Visa applications may be rejected due to incomplete documentation, failure to meet eligibility criteria, or security concerns.",
    "How does the Indian government verify visa applications?":
        "Through background checks, document verification, and in some cases, personal interviews to ensure authenticity and eligibility.",
    "What rights do foreign students have in India?":
        "Foreign students are allowed to study and, under certain conditions, work part-time. They also have access to educational and healthcare services.",
    "How can I appeal against a visa rejection decision?":
        "You can file an appeal with the visa department or consult an immigration lawyer to review and challenge the decision.",
    "What are the penalties for providing false information on a visa application?":
        "Providing false information may lead to visa cancellation, fines, or legal prosecution under the relevant immigration laws."
  },
  "Education & Student Rights": {
    // Original questions
    "What legal action can I take if my college refuses to return fees?":
        "You can file a complaint with the consumer forum or approach education regulatory bodies, particularly if the institution is governed by the relevant state or central regulations.",
    "What should I do if I face discrimination in an educational institution?":
        "File a grievance with the institution’s administration, and if unresolved, approach the education board or file a legal complaint for discrimination.",
    "Can a student be expelled without valid reason?":
        "No, expulsions must follow due process, including a hearing or an opportunity to present a defense, and any arbitrary expulsion can be legally challenged.",
    "What are my rights if a school refuses to issue a transfer certificate?":
        "You have the right to request a transfer certificate; if denied, file a complaint with the education authority or consumer forum.",
    "Is corporal punishment legal in schools, and how do I report it?":
        "Corporal punishment is banned in most states under the Right to Education Act; report any such instances to the school authorities or child rights commissions.",
    // 10 Additional Questions
    "What are the rights of students regarding academic freedom?":
        "Students have the right to express their opinions, access information, and participate in academic discourse, subject to institutional guidelines.",
    "How can a student challenge unfair disciplinary action?":
        "Students can file a grievance with the institution’s disciplinary committee or approach the education board to review the decision.",
    "What legal protections exist for students with disabilities?":
        "Under the Rights of Persons with Disabilities Act, institutions are required to provide reasonable accommodations and accessible facilities.",
    "Can parents file a complaint if a school violates student rights?":
        "Yes, parents can approach the education authority or file a legal complaint if they believe their child’s rights are being violated.",
    "How do educational institutions ensure transparency in fee structure?":
        "Institutions are mandated to publish detailed fee structures, refund policies, and provide receipts to ensure transparency.",
    "What recourse do students have for harassment on campus?":
        "Students can report harassment to campus authorities, file a complaint under the Sexual Harassment of Women at Workplace guidelines, or approach the police.",
    "Are there specific laws governing student unions and elections?":
        "Yes, many states have regulations and guidelines to ensure fair and transparent functioning of student unions and related elections.",
    "How can students access legal aid if they face academic disputes?":
        "Many institutions have legal aid cells or can refer students to external organizations that provide legal support for academic disputes.",
    "What measures are in place to protect the privacy of student records?":
        "Data protection regulations require institutions to safeguard student records and limit access only to authorized personnel.",
    "How do universities handle complaints of plagiarism or academic dishonesty?":
        "Universities typically have internal committees to investigate allegations and impose disciplinary actions as per academic policies."
  },
  "Environmental & Public Nuisance Laws": {
    // Original questions
    "How can I report illegal dumping of waste?":
        "You should report illegal dumping to the local municipality or pollution control board with evidence such as photographs and location details.",
    "What legal action can I take against noise pollution?":
        "File a complaint with the local civic body or police. If the issue persists, you may seek an injunction or approach the State Pollution Control Board.",
    "What are the laws on tree cutting and deforestation in India?":
        "The Forest Conservation Act and local regulations govern tree cutting. Unauthorized felling may lead to fines and imprisonment.",
    "How can I report industrial pollution?":
        "File a complaint with the State Pollution Control Board. If necessary, escalate the matter by approaching the National Green Tribunal.",
    "Can I file a Public Interest Litigation (PIL) for environmental concerns?":
        "Yes, PILs can be filed in the High Court or Supreme Court by affected citizens or organizations for issues impacting public health or the environment.",
    // 10 Additional Questions
    "What steps should I take if I notice water pollution in my area?":
        "Report the pollution to the local pollution control board or municipal authority, and provide evidence such as water samples or photographs.",
    "How does the Environment Protection Act regulate industrial emissions?":
        "The Act sets permissible limits for emissions and mandates regular monitoring by environmental agencies, with penalties for violations.",
    "What are the penalties for violating environmental regulations?":
        "Penalties can include heavy fines, imprisonment, and even closure of the establishment depending on the severity of the violation.",
    "How do public nuisance laws protect citizens from environmental hazards?":
        "These laws allow citizens to take legal action against activities that endanger public health or cause environmental damage.",
    "Can communities collectively file a lawsuit for environmental damage?":
        "Yes, affected communities can file class-action suits or PILs to address widespread environmental issues.",
    "What role do environmental impact assessments (EIA) play in new projects?":
        "EIAs assess the potential environmental impacts of proposed projects and recommend mitigation measures to minimize harm.",
    "How can I ensure my local government complies with environmental laws?":
        "Engage with local representatives, attend public hearings, and file RTI applications to obtain compliance data.",
    "What measures are in place to control urban pollution?":
        "Urban pollution is managed through policies such as vehicle emission standards, proper waste management, and industrial regulations.",
    "How can citizens participate in environmental conservation efforts?":
        "Citizens can join local NGOs, volunteer for tree plantation drives, participate in clean-up campaigns, and promote sustainable practices.",
    "What legal remedies are available if environmental clearances are violated?":
        "Affected parties can file a PIL or approach environmental courts to challenge the violation and seek remedial action."
  }
};
