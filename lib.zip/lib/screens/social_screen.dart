import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:provider/provider.dart';
import '../widgets/custom_appbar.dart';
import '../providers/language_provider.dart';
import '../providers/save_provider.dart';
import '../services/translation_service.dart';

class SocialRightsScreen extends StatefulWidget {
  const SocialRightsScreen({super.key});

  @override
  _SocialRightsScreenState createState() => _SocialRightsScreenState();
}

class _SocialRightsScreenState extends State<SocialRightsScreen> {
  final FlutterTts flutterTts = FlutterTts();

  String headerText = "Know Your Rights";
  List<String> translatedTitles = socialRights.map((e) => e['title'] as String).toList();
  List<String> translatedDescriptions = socialRights.map((e) => e['description'] as String).toList();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLanguage = languageProvider.selectedLanguage;

    try {
      String newHeader = await TranslationService.translate("Know Your Rights", selectedLanguage);
      if (mounted) {
        setState(() {
          headerText = newHeader;
        });
      }
    } catch (e) {
      print("❌ Translation error for header: $e");
    }

    List<String> newTitles = [];
    List<String> newDescriptions = [];
    for (var item in socialRights) {
      try {
        String tTitle = await TranslationService.translate(item['title'], selectedLanguage);
        String tDesc = await TranslationService.translate(item['description'], selectedLanguage);
        newTitles.add(tTitle);
        newDescriptions.add(tDesc);
      } catch (e) {
        print("❌ Translation error for ${item['title']}: $e");
        newTitles.add(item['title']);
        newDescriptions.add(item['description']);
      }
    }
    if (mounted) {
      setState(() {
        translatedTitles = newTitles;
        translatedDescriptions = newDescriptions;
      });
    }
  }

  void _speak(String text) async {
    await flutterTts.speak(text);
  }

  // Toggle saved status using SaveProvider.
  void toggleSaveItem(BuildContext context, String item) {
    final saveProvider = Provider.of<SaveProvider>(context, listen: false);
    if (saveProvider.savedItems.contains(item)) {
      saveProvider.removeItem(item);
    } else {
      saveProvider.addItem(item);
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isSmallScreen = screenWidth < 600;
    final saveProvider = Provider.of<SaveProvider>(context);

    return CustomAppBar(
      title: "Know Your Rights",
      icon: Icons.groups,
      body: Padding(
        padding: EdgeInsets.all(isSmallScreen ? 8.0 : 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            Text(
              headerText,
              style: TextStyle(
                fontSize: isSmallScreen ? 16 : 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: socialRights.length,
                itemBuilder: (context, index) {
                  final title = translatedTitles[index];
                  final description = translatedDescriptions[index];
                  final isSaved = saveProvider.savedItems.contains(title);
                  return Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    margin: EdgeInsets.symmetric(vertical: isSmallScreen ? 4 : 6),
                    child: Padding(
                      padding: EdgeInsets.all(isSmallScreen ? 8 : 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                socialRights[index]['icon'],
                                color: socialRights[index]['color'],
                                size: isSmallScreen ? 28 : 32,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  title,
                                  style: TextStyle(
                                    fontSize: isSmallScreen ? 14 : 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: Icon(
                                  Icons.volume_up,
                                  color: Colors.blue,
                                  size: isSmallScreen ? 22 : 26,
                                ),
                                onPressed: () => _speak(description),
                              ),
                              IconButton(
                                icon: Icon(
                                  isSaved ? Icons.bookmark : Icons.bookmark_border,
                                  color: isSaved ? Colors.blue : Colors.grey,
                                  size: isSmallScreen ? 22 : 26,
                                ),
                                onPressed: () {
                                  toggleSaveItem(context, title);
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text(
                            description,
                            style: TextStyle(
                              fontSize: isSmallScreen ? 15 : 20,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

final List<Map<String, dynamic>> socialRights = [
  {"title": "Right to Social Security", "icon": Icons.security, "color": Colors.blue, "description": "Everyone has the right to social protection and benefits."},
  {"title": "Right to Equal Opportunity", "icon": Icons.equalizer, "color": Colors.green, "description": "Everyone should have equal access to education and jobs."},
  {"title": "Right to Adequate Living Standards", "icon": Icons.home, "color": Colors.orange, "description": "People should have access to food, shelter, and clothing."},
  {"title": "Right to Assistance for the Elderly", "icon": Icons.elderly, "color": Colors.red, "description": "Older adults should receive adequate social and financial support."},
  {"title": "Right to Child Protection", "icon": Icons.child_care, "color": Colors.purple, "description": "Children should be protected from abuse and exploitation."},
  {"title": "Right to Support for Disabled Persons", "icon": Icons.accessible, "color": Colors.teal, "description": "People with disabilities should have equal opportunities."},
  {"title": "Right to Community Development", "icon": Icons.people, "color": Colors.cyan, "description": "Local communities should have the right to grow and develop."},
  {"title": "Right to Non-Discrimination", "icon": Icons.no_accounts, "color": Colors.amber, "description": "No one should be treated unfairly based on gender, race, or religion."},
  {"title": "Right to Freedom from Poverty", "icon": Icons.money_off, "color": Colors.brown, "description": "Efforts should be made to eliminate poverty globally."},
  {"title": "Right to Public Participation", "icon": Icons.poll, "color": Colors.indigo, "description": "Everyone should have a voice in social and governmental decisions."}
];
