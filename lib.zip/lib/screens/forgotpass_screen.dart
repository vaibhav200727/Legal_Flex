import 'dart:async'; // ✅ Needed for Timer
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:project/screens/register_screen.dart';
import 'package:project/screens/login_screen.dart'; // ✅ Import LoginPage

class ForgotPassword extends StatefulWidget {
  const ForgotPassword({super.key});

  @override
  State<ForgotPassword> createState() => _ForgotPasswordState();
}

class _ForgotPasswordState extends State<ForgotPassword> {
  final TextEditingController _emailController = TextEditingController();
  final List<String> _errorMessages = [];
  bool _emailSent = false;

  void _validateEmail() async {
    setState(() {
      _errorMessages.clear();
      _emailSent = false;
    });

    final email = _emailController.text.trim();

    if (email.isEmpty) {
      setState(() => _errorMessages.add('Email cannot be empty'));
      return;
    }

    if (!RegExp(r'^\S+@\S+\.\S+$').hasMatch(email)) {
      setState(() => _errorMessages.add('Enter a valid email address'));
      return;
    }

    try {
      // ✅ **Send Password Reset Email**
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
      print("✅ Password reset email sent to $email");

      setState(() {
        _emailSent = true;
      });

      // ✅ **Redirect to LoginPage after 5 seconds**
      Future.delayed(const Duration(seconds: 5), () {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const LoginPage()),
        );
      });

    } on FirebaseAuthException catch (e) {
      print("❌ Forgot Password Error: ${e.message}");
      setState(() => _errorMessages.add(e.message ?? 'An error occurred. Please try again.'));
    }
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.08),
          child: Column(
            children: [
              // ✅ Heading
              const Text(
                'Forgot Password',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),

              const Text(
                'Please enter your email and we will send\nan OTP to your account',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
              const SizedBox(height: 20),

              Image.asset(
                'assets/images/lock.jpg',
                height: screenHeight * 0.22,
                width: screenWidth * 0.55,
                fit: BoxFit.cover,
              ),
              const SizedBox(height: 20),

              // ✅ Email Input
              TextField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  labelStyle: const TextStyle(color: Colors.grey, fontSize: 16),
                  suffixIcon: const Icon(Icons.email, color: Colors.grey),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(25)),
                ),
              ),
              const SizedBox(height: 15),

              // ✅ Show Error Messages (If Any)
              if (_errorMessages.isNotEmpty)
                Column(
                  children: _errorMessages.map(
                    (error) => Row(
                      children: [
                        const Icon(Icons.close, color: Colors.red, size: 16),
                        const SizedBox(width: 5),
                        Expanded(
                          child: Text(
                            error,
                            style: const TextStyle(color: Colors.red, fontSize: 14),
                          ),
                        ),
                      ],
                    ),
                  ).toList(),
                ),
              const SizedBox(height: 15),

              // ✅ Show Success Message When Email Sent
              if (_emailSent)
                Column(
                  children: [
                    const Text(
                      "✅ Password reset email sent! Redirecting to login...",
                      style: TextStyle(color: Colors.green, fontSize: 16),
                    ),
                    const SizedBox(height: 10),
                    const CircularProgressIndicator(),
                  ],
                ),

              const SizedBox(height: 15),

              // ✅ Continue Button
              SizedBox(
                width: screenWidth * 0.9,
                height: 50,
                child: ElevatedButton(
                  onPressed: _validateEmail,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 44, 101, 224),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                  ),
                  child: const Text(
                    'Continue',
                    style: TextStyle(fontSize: 18, color: Colors.white),
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // ✅ Redirect to Register Page
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text("Don't have an account? ", style: TextStyle(fontSize: 16)),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => const RegisterPage()));
                    },
                    child: const Text(
                      'Sign Up',
                      style: TextStyle(color: Colors.blue, decoration: TextDecoration.underline, fontSize: 16),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
