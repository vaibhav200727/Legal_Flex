import 'package:flutter/material.dart';
import 'package:project/screens/confetti_screen.dart';
import 'package:project/screens/profile_screen.dart';
import 'package:project/screens/reset_pass_screen.dart';

class OTPVerificationPage2 extends StatefulWidget {
  const OTPVerificationPage2({required this.email, super.key});

  final String email;

  @override
  _OTPVerificationPageState2 createState() => _OTPVerificationPageState2();
}

class _OTPVerificationPageState2 extends State<OTPVerificationPage2> {
  bool _isResendEnabled = false;
  final List<TextEditingController> _otpControllers =
      List.generate(6, (_) => TextEditingController());

  String _timerText = "30";

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  void _startTimer() {
    int timeRemaining = 30;
    setState(() {
      _isResendEnabled = false;
    });

    Future.delayed(const Duration(seconds: 1), () async {
      while (timeRemaining > 0) {
        await Future.delayed(const Duration(seconds: 1));
        if (mounted) {
          setState(() {
            timeRemaining--;
            _timerText = timeRemaining.toString();
          });
        }
      }

      if (mounted) {
        setState(() {
          _isResendEnabled = true;
        });
      }
    });
  }

  void _verifyOTP() {
    String otp = _otpControllers.map((controller) => controller.text).join();

    if (otp.length != 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Invalid OTP. Please enter a 6-digit code.'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('OTP Verified Successfully!'),
        backgroundColor: Colors.green,
      ),
    );

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ResetPasswordPage(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final bool isSmallScreen = size.width < 400;
    final double fieldWidth = size.width * (isSmallScreen ? 0.9 : 0.8);
    final double otpBoxWidth = size.width * 0.12;
    final double buttonHeight = isSmallScreen ? 50 : 60;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: size.width * 0.05),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: IconButton(
                      icon: const Icon(Icons.arrow_back, color: Colors.grey),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  ),
                  const SizedBox(height: 30),
                  Text(
                    'OTP Verification',
                    style: TextStyle(
                      fontSize: isSmallScreen ? 26 : 32,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 15),
                  Text(
                    'We have sent a code to ${widget.email}',
                    style: TextStyle(
                      fontSize: isSmallScreen ? 16 : 18,
                      color: Colors.grey,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 5),
                  Text(
                    'Expires in: $_timerText seconds',
                    style: TextStyle(
                      fontSize: isSmallScreen ? 16 : 18,
                      color: Colors.orange,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 40),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: List.generate(
                      6,
                      (index) => SizedBox(
                        width: otpBoxWidth,
                        child: TextField(
                          controller: _otpControllers[index],
                          keyboardType: TextInputType.number,
                          textAlign: TextAlign.center,
                          maxLength: 1,
                          style: TextStyle(
                            fontSize: isSmallScreen ? 20 : 24,
                            fontWeight: FontWeight.bold,
                          ),
                          decoration: InputDecoration(
                            counterText: '',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          onChanged: (value) {
                            if (value.isNotEmpty && index < 5) {
                              FocusScope.of(context).nextFocus();
                            } else if (value.isEmpty && index > 0) {
                              FocusScope.of(context).previousFocus();
                            }
                          },
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 40),
                  SizedBox(
                    width: fieldWidth,
                    child: ElevatedButton(
                      onPressed: _verifyOTP,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange,
                        padding: EdgeInsets.symmetric(vertical: buttonHeight * 0.2),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                        minimumSize: Size.fromHeight(buttonHeight),
                      ),
                      child: Text(
                        'Verify OTP',
                        style: TextStyle(fontSize: isSmallScreen ? 18 : 20, color: Colors.white),
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),
                  TextButton(
                    onPressed: _isResendEnabled
                        ? () {
                            _startTimer();
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('OTP Resent Successfully!'),
                                backgroundColor: Colors.orange,
                              ),
                            );
                          }
                        : null,
                    child: Text(
                      _isResendEnabled ? 'Resend OTP' : 'Resend OTP',
                      style: TextStyle(
                        fontSize: isSmallScreen ? 16 : 18,
                        color: _isResendEnabled ? Colors.blue : Colors.grey,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
