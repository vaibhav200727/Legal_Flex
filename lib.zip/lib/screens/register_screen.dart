import 'package:flutter/material.dart';
import 'package:project/screens/login_screen.dart';
import 'package:project/screens/profile_screen.dart';
import 'package:project/auth/signup_service.dart'; // ✅ Import SignupService
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();
  bool _rememberMe = false;
  String? _emailError;
  String? _passwordError;
  String? _confirmPasswordError;

  bool _passwordVisible = false;
  bool _confirmPasswordVisible = false;

  void _validateInputs() async {
    setState(() {
      _emailError = null;
      _passwordError = null;
      _confirmPasswordError = null;
    });

    final email = _emailController.text.trim();
    final password = _passwordController.text;
    final confirmPassword = _confirmPasswordController.text;

    if (email.isEmpty) {
      _emailError = 'Email cannot be empty';
    } else if (!RegExp(r'^\S+@\S+\.\S+$').hasMatch(email)) {
      _emailError = 'Please enter a valid email address';
    }

    if (password.isEmpty) {
      _passwordError = 'Password cannot be empty';
    } else if (!RegExp(r'^(?=.*[A-Za-z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>]).{8,}$')
        .hasMatch(password)) {
      _passwordError =
          'Password must be at least 8 characters long, include a letter, a number, and a special character.';
    }

    if (confirmPassword.isEmpty) {
      _confirmPasswordError = 'Confirm Password cannot be empty';
    } else if (confirmPassword != password) {
      _confirmPasswordError = 'Passwords do not match';
    }

    setState(() {}); // Update UI with validation errors

    // Only proceed if there are no inline errors
    if (_emailError == null && _passwordError == null && _confirmPasswordError == null) {
      try {
        // 🔍 Check if email already exists in Firestore
        final emailCheck = await FirebaseFirestore.instance
            .collection('users')
            .where("email", isEqualTo: email)
            .get();

        if (emailCheck.docs.isNotEmpty) {
          print("🚫 Email already registered. Redirecting to login...");
          if (context.mounted) {
            setState(() {
              _emailError = "This email is already registered. Please log in.";
            });
          }
          return; // Stop further execution
        }

        // ✅ If email is new, proceed with registration
        User? user = await SignupService.signUpWithEmail(email, password);
        if (user != null) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Registration Successful!'),
              backgroundColor: Colors.green,
            ),
          );

          // ✅ Navigate only if user creation is successful
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const CompleteProfilePage()),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Registration failed. Please try again.'),
              backgroundColor: Colors.red,
            ),
          );
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  void _registerWithGoogle() async {
    try {
      // 🔍 Check if user already exists in Firestore before signing in
      final GoogleSignIn googleSignIn = GoogleSignIn();
      await googleSignIn.signOut(); // ✅ Forces account selection
      final GoogleSignInAccount? googleUser = await googleSignIn.signIn();

      if (googleUser == null) {
        print("❌ Google Sign-Up Cancelled.");
        return;
      }

      final userCheck = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: googleUser.email)
          .get();

      if (userCheck.docs.isNotEmpty) {
        print("🚫 Google Account already registered. Redirecting to login...");
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text("Google Account already registered. Please log in."),
              backgroundColor: Colors.red,
            ),
          );

          // ✅ Redirect to Login Page
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const LoginPage()),
          );
        }
        return;
      }

      // ✅ Proceed with Firebase Authentication (Google Sign-In)
      User? user = await SignupService.signUpWithGoogle();

      if (user != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Google Sign-Up Successful!'),
            backgroundColor: Colors.green,
          ),
        );

        // ✅ Proceed to profile completion
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const CompleteProfilePage()),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Google Sign-Up failed. Please try again.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Google Sign-Up failed: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final bool isSmallScreen = size.width < 400;
    final double fieldWidth = size.width * (isSmallScreen ? 0.95 : 0.8); // Adjusting width based on screen size
    final double padding = size.width * 0.05; // Adaptive padding

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView( // Prevents bottom overflow
            physics: const NeverScrollableScrollPhysics(), // Disables scrolling
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: padding),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 60), // Adjusted space at the top

                  Text(
                    'Register Account',
                    style: TextStyle(
                      fontSize: isSmallScreen ? 26 : 30,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 10),

                  Text(
                    'Complete your details or continue\nwith Google',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: isSmallScreen ? 16 : 18,
                      color: Colors.grey,
                    ),
                  ),
                  const SizedBox(height: 30),

                  // Email Field (Responsive)
                  SizedBox(
                    width: fieldWidth,
                    child: TextField(
                      controller: _emailController,
                      decoration: InputDecoration(
                        labelText: 'Email',
                        errorText: _emailError,
                        suffixIcon: const Icon(Icons.email, color: Colors.grey),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Password Field (Responsive)
                  SizedBox(
                    width: fieldWidth,
                    child: TextField(
                      controller: _passwordController,
                      obscureText: !_passwordVisible,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        errorText: _passwordError,
                        suffixIcon: GestureDetector(
                          onTap: () {
                            setState(() {
                              _passwordVisible = !_passwordVisible;
                            });
                          },
                          child: Icon(
                            _passwordVisible ? Icons.visibility : Icons.visibility_off,
                            color: Colors.grey,
                          ),
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Confirm Password Field (Responsive)
                  SizedBox(
                    width: fieldWidth,
                    child: TextField(
                      controller: _confirmPasswordController,
                      obscureText: !_confirmPasswordVisible,
                      decoration: InputDecoration(
                        labelText: 'Confirm Password',
                        errorText: _confirmPasswordError,
                        suffixIcon: GestureDetector(
                          onTap: () {
                            setState(() {
                              _confirmPasswordVisible = !_confirmPasswordVisible;
                            });
                          },
                          child: Icon(
                            _confirmPasswordVisible ? Icons.visibility : Icons.visibility_off,
                            color: Colors.grey,
                          ),
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Remember Me Checkbox (Fixed to the Left)
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Row(
                      children: [
                        Checkbox(
                          value: _rememberMe,
                          onChanged: (value) {
                            setState(() {
                              _rememberMe = value!;
                            });
                          },
                        ),
                        const Text('Remember me'),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Continue Button (Responsive)
                  SizedBox(
                    width: fieldWidth,
                    child: ElevatedButton(
                      onPressed: () {
                        _validateInputs();
                        if (_emailError == null &&
                            _passwordError == null &&
                            _confirmPasswordError == null) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Registration Successful!'),
                              backgroundColor: Colors.green,
                            ),
                          );
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const CompleteProfilePage(),
                            ),
                          );
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color.fromARGB(255, 44, 101, 224),
                        padding: const EdgeInsets.symmetric(vertical: 13),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                      ),
                      child: const Text(
                        'Continue',
                        style: TextStyle(fontSize: 18, color: Colors.white),
                      ),
                    ),
                  ),
                  const SizedBox(height: 15),

                  // Google Sign-Up Button (✅ Only Google Logo)
                  Center(
                    child: IconButton(
                      icon: Image.asset('assets/icons/google.png'),
                      iconSize: isSmallScreen ? 50 : 60,
                      onPressed: _registerWithGoogle, // ✅ Calls Google Sign-Up function
                    ),
                  ),
                  const SizedBox(height: 20), // Space before Sign-In text

                  // Already have an account? Sign In
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text('Already have an account? '),
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => LoginPage(),
                            ),
                          );
                        },
                        child: const Text(
                          'Sign In',
                          style: TextStyle(
                            color: Colors.blue,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 30), // Adjusted to remove overflow issue
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
