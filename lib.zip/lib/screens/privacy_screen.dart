import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:provider/provider.dart';
import '../widgets/custom_appbar.dart';
import '../providers/language_provider.dart';
import '../providers/save_provider.dart';
import '../services/translation_service.dart';

class PrivacyRightsScreen extends StatefulWidget {
  const PrivacyRightsScreen({super.key});

  @override
  _PrivacyRightsScreenState createState() => _PrivacyRightsScreenState();
}

class _PrivacyRightsScreenState extends State<PrivacyRightsScreen> {
  final FlutterTts flutterTts = FlutterTts();

  String headerText = "Know Your Rights";
  List<String> translatedTitles = privacyRights.map((e) => e['title'] as String).toList();
  List<String> translatedDescriptions =
      privacyRights.map((e) => e['description'] as String).toList();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLanguage = languageProvider.selectedLanguage;

    try {
      String newHeader =
          await TranslationService.translate("Know Your Rights", selectedLanguage);
      if (mounted) {
        setState(() {
          headerText = newHeader;
        });
      }
    } catch (e) {
      print("❌ Translation error for header: $e");
    }

    List<String> newTitles = [];
    List<String> newDescriptions = [];
    for (var item in privacyRights) {
      try {
        String tTitle =
            await TranslationService.translate(item['title'], selectedLanguage);
        String tDesc =
            await TranslationService.translate(item['description'], selectedLanguage);
        newTitles.add(tTitle);
        newDescriptions.add(tDesc);
      } catch (e) {
        print("❌ Translation error for ${item['title']}: $e");
        newTitles.add(item['title']);
        newDescriptions.add(item['description']);
      }
    }
    if (mounted) {
      setState(() {
        translatedTitles = newTitles;
        translatedDescriptions = newDescriptions;
      });
    }
  }

  void _speak(String text) async {
    await flutterTts.speak(text);
  }

  // Toggle saved status using SaveProvider.
  void toggleSaveItem(BuildContext context, String item) {
    final saveProvider = Provider.of<SaveProvider>(context, listen: false);
    if (saveProvider.savedItems.contains(item)) {
      saveProvider.removeItem(item);
    } else {
      saveProvider.addItem(item);
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isSmallScreen = screenWidth < 600;
    final saveProvider = Provider.of<SaveProvider>(context);

    return CustomAppBar(
      title: "Know Your Rights",
      icon: Icons.privacy_tip,
      body: Padding(
        padding: EdgeInsets.all(isSmallScreen ? 8.0 : 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            Text(
              headerText,
              style: TextStyle(
                fontSize: isSmallScreen ? 16 : 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: privacyRights.length,
                itemBuilder: (context, index) {
                  final title = translatedTitles[index];
                  final description = translatedDescriptions[index];
                  final isSaved = saveProvider.savedItems.contains(title);
                  return Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    margin: EdgeInsets.symmetric(vertical: isSmallScreen ? 4 : 6),
                    child: Padding(
                      padding: EdgeInsets.all(isSmallScreen ? 8 : 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                privacyRights[index]['icon'],
                                color: privacyRights[index]['color'],
                                size: isSmallScreen ? 28 : 32,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  title,
                                  style: TextStyle(
                                    fontSize: isSmallScreen ? 14 : 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: Icon(
                                  Icons.volume_up,
                                  color: Colors.blue,
                                  size: isSmallScreen ? 22 : 26,
                                ),
                                onPressed: () => _speak(description),
                              ),
                              IconButton(
                                icon: Icon(
                                  isSaved ? Icons.bookmark : Icons.bookmark_border,
                                  color: isSaved ? Colors.blue : Colors.grey,
                                  size: isSmallScreen ? 22 : 26,
                                ),
                                onPressed: () {
                                  toggleSaveItem(context, title);
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text(
                            description,
                            style: TextStyle(
                              fontSize: isSmallScreen ? 15 : 20,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

final List<Map<String, dynamic>> privacyRights = [
  {"title": "Right to Digital Privacy", "icon": Icons.lock, "color": Colors.blue, "description": "Your personal data must be protected online."},
  {"title": "Right Against Unauthorized Surveillance", "icon": Icons.visibility_off, "color": Colors.green, "description": "No one should be watched without consent."},
  {"title": "Right to Be Forgotten", "icon": Icons.delete_forever, "color": Colors.red, "description": "Request removal of personal data from the web."},
  {"title": "Right to Data Protection", "icon": Icons.shield, "color": Colors.orange, "description": "Laws must safeguard citizens' data privacy."},
  {"title": "Right to Identity Protection", "icon": Icons.badge, "color": Colors.purple, "description": "No one should steal or misuse your identity."},
  {"title": "Right to Secure Communication", "icon": Icons.chat, "color": Colors.teal, "description": "Your messages should remain private and encrypted."},
  {"title": "Right to Private Online Activity", "icon": Icons.security, "color": Colors.cyan, "description": "Your browsing history must not be misused."},
  {"title": "Right to Protection from Digital Fraud", "icon": Icons.warning, "color": Colors.amber, "description": "Your financial data should be protected."},
  {"title": "Right to Avoid Targeted Ads", "icon": Icons.ad_units, "color": Colors.brown, "description": "No one should collect your data for ads without consent."},
  {"title": "Right to Government Transparency on Data Usage", "icon": Icons.policy, "color": Colors.indigo, "description": "Government must disclose data collection policies."}
];
