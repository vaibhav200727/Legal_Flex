import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../providers/language_provider.dart';
import '../services/translation_service.dart';
import '../widgets/custom_appbar.dart';
// Replace with your actual home screen import
import 'package:project/screens/home_screen.dart';

class PaymentSuccessfulScreen extends StatefulWidget {
  final double amountPaid;
  final String transactionId;
  final String paymentMethod;
  final String lawyerName;
  final String lawyerSpecialty;
  final String lawyerImageUrl; // New parameter for the lawyer image.
  final String bookingDate; // e.g. "2024-03-15"
  final String bookingTime; // e.g. "10:00 AM"
  final String bookingDuration; // e.g. "60 minutes"

  const PaymentSuccessfulScreen({
    super.key,
    required this.amountPaid,
    required this.transactionId,
    required this.paymentMethod,
    required this.lawyerName,
    required this.lawyerSpecialty,
    required this.lawyerImageUrl,
    required this.bookingDate,
    required this.bookingTime,
    required this.bookingDuration,
  });

  @override
  State<PaymentSuccessfulScreen> createState() => _PaymentSuccessfulScreenState();
}

class _PaymentSuccessfulScreenState extends State<PaymentSuccessfulScreen> {
  // Translation variables.
  String translatedTitle = "Payment Successful";
  String translatedSuccessMsg = "Your lawyer has been booked successfully";
  String translatedAmountPaid = "Amount Paid";
  String translatedTransactionID = "Transaction ID";
  String translatedPaymentMethod = "Payment Method";
  String translatedBackHome = "Back to Home";
  String translatedDate = "Date";
  String translatedTime = "Time";
  String translatedDuration = "Duration";

  String selectedLanguage = "en";

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    selectedLanguage = languageProvider.selectedLanguage;

    try {
      translatedTitle = await TranslationService.translate("Payment Successful", selectedLanguage);
      translatedSuccessMsg = await TranslationService.translate("Your lawyer has been booked successfully", selectedLanguage);
      translatedAmountPaid = await TranslationService.translate("Amount Paid", selectedLanguage);
      translatedTransactionID = await TranslationService.translate("Transaction ID", selectedLanguage);
      translatedPaymentMethod = await TranslationService.translate("Payment Method", selectedLanguage);
      translatedBackHome = await TranslationService.translate("Back to Home", selectedLanguage);
      translatedDate = await TranslationService.translate("Date", selectedLanguage);
      translatedTime = await TranslationService.translate("Time", selectedLanguage);
      translatedDuration = await TranslationService.translate("Duration", selectedLanguage);

      if (mounted) setState(() {});
    } catch (e) {
      print("Translation error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    // Convert bookingDate if needed (e.g., from "yyyy-MM-dd" → "March 15, 2024")
    String friendlyDate = widget.bookingDate;
    try {
      DateTime parsed = DateFormat('yyyy-MM-dd').parse(widget.bookingDate);
      friendlyDate = DateFormat('MMMM d, yyyy').format(parsed);
    } catch (_) {
      // fallback if parse fails
    }

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            // Optional header if needed (can be removed if using CustomAppBar)
            _buildHeader(),

            // Expanded scrollable content
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Top success icon
                    Container(
                      width: 80,
                      height: 80,
                      decoration: const BoxDecoration(
                        color: Colors.green,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.check,
                        color: Colors.white,
                        size: 48,
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Title
                    Text(
                      translatedTitle,
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 10),

                    // Subtitle
                    Text(
                      translatedSuccessMsg,
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey[600],
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 30),

                    // Payment Details Card
                    _buildPaymentDetailsCard(),

                    const SizedBox(height: 30),

                    // Lawyer Details Card (using the same lawyer image)
                    _buildLawyerDetailsCard(friendlyDate),
                  ],
                ),
              ),
            ),

            // Back to Home button pinned at the bottom.
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => const HomeScreen()),
                      (route) => false,
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    textStyle: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  child: Text(translatedBackHome),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Optional custom header (remove if not needed)
  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      height: 50,
      color: Colors.white,
      child: const Center(
        child: Text(
          "Payment Successful",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  Widget _buildPaymentDetailsCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      margin: const EdgeInsets.symmetric(horizontal: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade300),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade200,
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Amount Paid
          Text(
            translatedAmountPaid,
            style: TextStyle(fontSize: 16, color: Colors.grey[600]),
          ),
          const SizedBox(height: 6),
          Text(
            "₹${widget.amountPaid.toStringAsFixed(2)}",
            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),

          // Transaction ID
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                translatedTransactionID,
                style: TextStyle(fontSize: 16, color: Colors.grey[600]),
              ),
              Text(
                widget.transactionId.isEmpty ? "N/A" : widget.transactionId,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
            ],
          ),
          const SizedBox(height: 10),

          // Payment Method
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                translatedPaymentMethod,
                style: TextStyle(fontSize: 16, color: Colors.grey[600]),
              ),
              Text(
                widget.paymentMethod.isEmpty ? "N/A" : widget.paymentMethod,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLawyerDetailsCard(String friendlyDate) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      margin: const EdgeInsets.symmetric(horizontal: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade300),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade200,
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Lawyer info row
          Row(
            children: [
              // Lawyer avatar (use the same image passed from the lawyer details)
              CircleAvatar(
                radius: 30,
                backgroundColor: Colors.grey[300],
                backgroundImage: widget.lawyerImageUrl.isNotEmpty
                    ? NetworkImage(widget.lawyerImageUrl)
                    : null,
                child: widget.lawyerImageUrl.isEmpty
                    ? const Icon(Icons.person, size: 30, color: Colors.grey)
                    : null,
              ),
              const SizedBox(width: 16),
              // Name & specialty
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.lawyerName,
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    widget.lawyerSpecialty,
                    style: TextStyle(fontSize: 16, color: Colors.grey[600]),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 20),

          // Date
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "$translatedDate:",
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
              Text(
                friendlyDate,
                style: TextStyle(fontSize: 16, color: Colors.grey[600]),
              ),
            ],
          ),
          const SizedBox(height: 10),

          // Time
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "$translatedTime:",
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
              Text(
                widget.bookingTime,
                style: TextStyle(fontSize: 16, color: Colors.grey[600]),
              ),
            ],
          ),
          const SizedBox(height: 10),

          // Duration
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "$translatedDuration:",
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
              Text(
                widget.bookingDuration,
                style: TextStyle(fontSize: 16, color: Colors.grey[600]),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
