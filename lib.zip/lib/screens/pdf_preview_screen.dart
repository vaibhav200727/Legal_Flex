import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:open_file/open_file.dart';

class PdfPreviewScreen extends StatelessWidget {
  final String pdfPath; // Full local file path

  const PdfPreviewScreen({super.key, required this.pdfPath});

  /// Opens the local PDF file using an external app.
  Future<void> _openPdf(BuildContext context) async {
    final result = await OpenFile.open(pdfPath);
    if (result.type != ResultType.done) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Could not open file")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("PDF Preview"),
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            tooltip: "Download/Open PDF",
            onPressed: () => _openPdf(context),
          ),
        ],
      ),
      body: PDFView(
        filePath: pdfPath,
        enableSwipe: true,
        swipeHorizontal: false,
        autoSpacing: false,
        pageFling: false,
      ),
    );
  }
}
