import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:provider/provider.dart';
import '../widgets/custom_appbar.dart';
import '../providers/language_provider.dart';
import '../providers/save_provider.dart';
import '../services/translation_service.dart';

class EmploymentRightsScreen extends StatefulWidget {
  const EmploymentRightsScreen({super.key});

  @override
  _EmploymentRightsScreenState createState() => _EmploymentRightsScreenState();
}

class _EmploymentRightsScreenState extends State<EmploymentRightsScreen> {
  final FlutterTts flutterTts = FlutterTts();

  String headerText = "Know Your Rights";
  List<String> translatedTitles =
      employmentRights.map((e) => e['title'] as String).toList();
  List<String> translatedDescriptions =
      employmentRights.map((e) => e['description'] as String).toList();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  Future<void> _updateTranslations() async {
    final languageProvider =
        Provider.of<LanguageProvider>(context, listen: false);
    final selectedLanguage = languageProvider.selectedLanguage;

    try {
      String newHeader =
          await TranslationService.translate("Know Your Rights", selectedLanguage);
      if (mounted) {
        setState(() {
          headerText = newHeader;
        });
      }
    } catch (e) {
      print("❌ Translation error for header: $e");
    }

    List<String> newTitles = [];
    List<String> newDescriptions = [];
    for (var item in employmentRights) {
      try {
        String tTitle = await TranslationService.translate(item['title'], selectedLanguage);
        String tDesc = await TranslationService.translate(item['description'], selectedLanguage);
        newTitles.add(tTitle);
        newDescriptions.add(tDesc);
      } catch (e) {
        print("❌ Translation error for ${item['title']}: $e");
        newTitles.add(item['title']);
        newDescriptions.add(item['description']);
      }
    }
    if (mounted) {
      setState(() {
        translatedTitles = newTitles;
        translatedDescriptions = newDescriptions;
      });
    }
  }

  void _speak(String text) async {
    await flutterTts.speak(text);
  }

  // Toggle saved state using SaveProvider
  void toggleSaveItem(BuildContext context, String item) {
    final saveProvider = Provider.of<SaveProvider>(context, listen: false);
    if (saveProvider.savedItems.contains(item)) {
      saveProvider.removeItem(item);
    } else {
      saveProvider.addItem(item);
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isSmallScreen = screenWidth < 600;
    final saveProvider = Provider.of<SaveProvider>(context);

    return CustomAppBar(
      title: "Know Your Rights",
      icon: Icons.work,
      body: Padding(
        padding: EdgeInsets.all(isSmallScreen ? 8.0 : 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            Text(
              headerText,
              style: TextStyle(
                fontSize: isSmallScreen ? 16 : 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: employmentRights.length,
                itemBuilder: (context, index) {
                  final title = translatedTitles[index];
                  final description = translatedDescriptions[index];
                  final isSaved = saveProvider.savedItems.contains(title);
                  return Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    margin: EdgeInsets.symmetric(vertical: isSmallScreen ? 4 : 6),
                    child: Padding(
                      padding: EdgeInsets.all(isSmallScreen ? 8 : 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                employmentRights[index]['icon'],
                                color: employmentRights[index]['color'],
                                size: isSmallScreen ? 20 : 24,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  title,
                                  style: TextStyle(
                                    fontSize: isSmallScreen ? 14 : 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: Icon(
                                  Icons.volume_up,
                                  color: Colors.blue,
                                  size: isSmallScreen ? 22 : 26,
                                ),
                                onPressed: () => _speak(description),
                              ),
                              IconButton(
                                icon: Icon(
                                  isSaved ? Icons.bookmark : Icons.bookmark_border,
                                  color: isSaved ? Colors.blue : Colors.grey,
                                  size: isSmallScreen ? 22 : 26,
                                ),
                                onPressed: () {
                                  toggleSaveItem(context, title);
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text(
                            description,
                            style: TextStyle(
                              fontSize: isSmallScreen ? 15 : 20,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

final List<Map<String, dynamic>> employmentRights = [
  {"title": "Right to Fair Wages", "icon": Icons.attach_money, "color": Colors.blue, "description": "Every worker has the right to receive fair compensation."},
  {"title": "Right to Safe Working Conditions", "icon": Icons.security, "color": Colors.green, "description": "Workplaces must ensure health and safety for employees."},
  {"title": "Right to Equal Pay", "icon": Icons.balance, "color": Colors.orange, "description": "Men and women should receive equal pay for equal work."},
  {"title": "Right to Unionize", "icon": Icons.groups, "color": Colors.red, "description": "Workers can form and join unions to protect their rights."},
  {"title": "Right to Job Security", "icon": Icons.lock, "color": Colors.purple, "description": "Employees should have legal protections against unfair dismissal."},
  {"title": "Right to Work-Life Balance", "icon": Icons.schedule, "color": Colors.teal, "description": "Workers should have a reasonable balance between work and personal life."},
  {"title": "Right to Protection Against Discrimination", "icon": Icons.gavel, "color": Colors.cyan, "description": "No worker should be discriminated against in the workplace."},
  {"title": "Right to Reasonable Working Hours", "icon": Icons.access_time, "color": Colors.amber, "description": "Employees should not be forced to work beyond reasonable limits."},
  {"title": "Right to Maternity & Paternity Leave", "icon": Icons.family_restroom, "color": Colors.brown, "description": "Parents should have the right to take leave for child care."},
  {"title": "Right to Workplace Privacy", "icon": Icons.privacy_tip, "color": Colors.indigo, "description": "Employees' personal data and privacy should be respected at work."}
];
