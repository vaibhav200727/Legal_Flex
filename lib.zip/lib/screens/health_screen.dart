import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:provider/provider.dart';
import '../widgets/custom_appbar.dart';
import '../providers/language_provider.dart';
import '../providers/save_provider.dart';
import '../services/translation_service.dart';

class HealthcareRightsScreen extends StatefulWidget {
  const HealthcareRightsScreen({super.key});

  @override
  _HealthcareRightsScreenState createState() => _HealthcareRightsScreenState();
}

class _HealthcareRightsScreenState extends State<HealthcareRightsScreen> {
  final FlutterTts flutterTts = FlutterTts();

  String headerText = "Know Your Rights";
  List<String> translatedTitles =
      healthcareRights.map((e) => e['title'] as String).toList();
  List<String> translatedDescriptions =
      healthcareRights.map((e) => e['description'] as String).toList();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLanguage = languageProvider.selectedLanguage;

    try {
      String newHeader = await TranslationService.translate("Know Your Rights", selectedLanguage);
      if (mounted) {
        setState(() {
          headerText = newHeader;
        });
      }
    } catch (e) {
      print("❌ Translation error for header: $e");
    }

    List<String> newTitles = [];
    List<String> newDescriptions = [];
    for (var item in healthcareRights) {
      try {
        String tTitle = await TranslationService.translate(item['title'], selectedLanguage);
        String tDesc = await TranslationService.translate(item['description'], selectedLanguage);
        newTitles.add(tTitle);
        newDescriptions.add(tDesc);
      } catch (e) {
        print("❌ Translation error for ${item['title']}: $e");
        newTitles.add(item['title']);
        newDescriptions.add(item['description']);
      }
    }
    if (mounted) {
      setState(() {
        translatedTitles = newTitles;
        translatedDescriptions = newDescriptions;
      });
    }
  }

  void _speak(String text) async {
    await flutterTts.speak(text);
  }

  // Toggle saved status using SaveProvider.
  void toggleSaveItem(BuildContext context, String item) {
    final saveProvider = Provider.of<SaveProvider>(context, listen: false);
    if (saveProvider.savedItems.contains(item)) {
      saveProvider.removeItem(item);
    } else {
      saveProvider.addItem(item);
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isSmallScreen = screenWidth < 600;
    final saveProvider = Provider.of<SaveProvider>(context);

    return CustomAppBar(
      title: "Know Your Rights",
      icon: Icons.local_hospital,
      body: Padding(
        padding: EdgeInsets.all(isSmallScreen ? 8.0 : 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            Text(
              headerText,
              style: TextStyle(
                fontSize: isSmallScreen ? 16 : 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: healthcareRights.length,
                itemBuilder: (context, index) {
                  final title = translatedTitles[index];
                  final description = translatedDescriptions[index];
                  final isSaved = saveProvider.savedItems.contains(title);
                  return Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    margin: EdgeInsets.symmetric(vertical: isSmallScreen ? 4 : 6),
                    child: Padding(
                      padding: EdgeInsets.all(isSmallScreen ? 8 : 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                healthcareRights[index]['icon'],
                                color: healthcareRights[index]['color'],
                                size: isSmallScreen ? 28 : 32,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  title,
                                  style: TextStyle(
                                    fontSize: isSmallScreen ? 14 : 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: Icon(
                                  Icons.volume_up,
                                  color: Colors.blue,
                                  size: isSmallScreen ? 22 : 26,
                                ),
                                onPressed: () => _speak(description),
                              ),
                              IconButton(
                                icon: Icon(
                                  isSaved ? Icons.bookmark : Icons.bookmark_border,
                                  color: isSaved ? Colors.blue : Colors.grey,
                                  size: isSmallScreen ? 22 : 26,
                                ),
                                onPressed: () {
                                  toggleSaveItem(context, title);
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text(
                            description,
                            style: TextStyle(
                              fontSize: isSmallScreen ? 15 : 20,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

final List<Map<String, dynamic>> healthcareRights = [
  {"title": "Right to Health", "icon": Icons.favorite, "color": Colors.red, "description": "Everyone has the right to access medical care."},
  {"title": "Right to Affordable Medicines", "icon": Icons.medical_services, "color": Colors.blue, "description": "Essential medicines should be available at fair prices."},
  {"title": "Right to Maternal and Child Healthcare", "icon": Icons.child_friendly, "color": Colors.green, "description": "Mothers and children should receive proper medical care."},
  {"title": "Right to Emergency Medical Services", "icon": Icons.local_hospital, "color": Colors.orange, "description": "Emergency medical care should be available to all."},
  {"title": "Right to Patient Confidentiality", "icon": Icons.privacy_tip, "color": Colors.purple, "description": "Medical records should remain private and secure."},
  {"title": "Right to Clean Water and Sanitation", "icon": Icons.water, "color": Colors.teal, "description": "Access to clean drinking water is essential for health."},
  {"title": "Right to Free Public Healthcare", "icon": Icons.public, "color": Colors.cyan, "description": "Public hospitals should provide free medical services."},
  {"title": "Right to Mental Healthcare", "icon": Icons.psychology, "color": Colors.amber, "description": "Everyone should have access to mental health support."},
  {"title": "Right to Disability Support and Rehabilitation", "icon": Icons.accessible, "color": Colors.brown, "description": "Disabled individuals should receive proper healthcare and rehabilitation."},
  {"title": "Right to Protection from Infectious Diseases", "icon": Icons.coronavirus, "color": Colors.indigo, "description": "Governments must take measures to prevent disease outbreaks."}
];
