import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';

import '../widgets/custom_appbar.dart'; 
import '../providers/language_provider.dart';
import '../services/translation_service.dart';
import 'quiz1.dart'; // Your QuizScreen widget

/// Data model for constitutional parts.
class ConstitutionPart {
  final String partNumber;    // e.g. "Part I"
  final String title;         // e.g. "The Union and its Territory"
  final String articleRange;  // e.g. "Articles 1-4"

  ConstitutionPart({
    required this.partNumber,
    required this.title,
    required this.articleRange,
  });
}

// Original list of all constitutional parts in English (for Firestore doc IDs).
final List<ConstitutionPart> constitutionParts = [
  ConstitutionPart(
    partNumber: 'Part I',
    title: 'The Union and its Territory',
    articleRange: 'Articles 1-4',
  ),
  ConstitutionPart(
    partNumber: 'Part II',
    title: 'Citizenship',
    articleRange: 'Articles 5-11',
  ),
  ConstitutionPart(
    partNumber: 'Part III',
    title: 'Fundamental Rights',
    articleRange: 'Articles 12-35',
  ),
  ConstitutionPart(
    partNumber: 'Part IV',
    title: 'Directive Principles of State Policy',
    articleRange: 'Articles 36-51',
  ),
  ConstitutionPart(
    partNumber: 'Part IVA',
    title: 'Fundamental Duties',
    articleRange: 'Article 51A',
  ),
  ConstitutionPart(
    partNumber: 'Part V',
    title: 'The Union',
    articleRange: 'Articles 52-151',
  ),
  ConstitutionPart(
    partNumber: 'Part VI',
    title: 'The States',
    articleRange: 'Articles 152-237',
  ),
  ConstitutionPart(
    partNumber: 'Part VIII',
    title: 'The Union Territories',
    articleRange: 'Articles 239-242',
  ),
  ConstitutionPart(
    partNumber: 'Part IX',
    title: 'Panchayats',
    articleRange: 'Articles 243-243O',
  ),
  ConstitutionPart(
    partNumber: 'Part IXA',
    title: 'Municipalities',
    articleRange: 'Articles 243P-243ZG',
  ),
  ConstitutionPart(
    partNumber: 'Part X',
    title: 'The Scheduled and Tribal Areas',
    articleRange: 'Articles 244-244A',
  ),
  ConstitutionPart(
    partNumber: 'Part XI',
    title: 'Relations between the Union and the States',
    articleRange: 'Articles 245-263',
  ),
  ConstitutionPart(
    partNumber: 'Part XII',
    title: 'Finance, Property, Contracts and Suits',
    articleRange: 'Articles 264-300A',
  ),
  ConstitutionPart(
    partNumber: 'Part XIII',
    title: 'Trade, Commerce and Intercourse within the Territory of India',
    articleRange: 'Articles 301-307',
  ),
  ConstitutionPart(
    partNumber: 'Part XIV',
    title: 'Services under the Union and the States',
    articleRange: 'Articles 308-323',
  ),
  ConstitutionPart(
    partNumber: 'Part XIVA',
    title: 'Tribunals',
    articleRange: 'Articles 323A-323B',
  ),
  ConstitutionPart(
    partNumber: 'Part XV',
    title: 'Elections',
    articleRange: 'Articles 324-329A',
  ),
  ConstitutionPart(
    partNumber: 'Part XVI',
    title: 'Special Provisions relating to certain classes',
    articleRange: 'Articles 330-342',
  ),
  ConstitutionPart(
    partNumber: 'Part XVII',
    title: 'Official Language',
    articleRange: 'Articles 343-351',
  ),
  ConstitutionPart(
    partNumber: 'Part XVIII',
    title: 'Emergency Provisions',
    articleRange: 'Articles 352-360',
  ),
  ConstitutionPart(
    partNumber: 'Part XIX',
    title: 'Miscellaneous',
    articleRange: 'Articles 361-367',
  ),
  ConstitutionPart(
    partNumber: 'Part XX',
    title: 'Amendment of the Constitution',
    articleRange: 'Article 368',
  ),
  ConstitutionPart(
    partNumber: 'Part XXI',
    title: 'Temporary, Transitional and Special Provisions',
    articleRange: 'Articles 369-392',
  ),
  ConstitutionPart(
    partNumber: 'Part XXII',
    title: 'Short Title, Commencement, Authoritative Text in Hindi and English',
    articleRange: 'Articles 393-395',
  ),
];

class QuizHomePage extends StatefulWidget {
  const QuizHomePage({super.key});

  @override
  State<QuizHomePage> createState() => _QuizHomePageState();
}

class _QuizHomePageState extends State<QuizHomePage> {
  // Stats loaded from SharedPreferences.
  String latestPart = "N/A";
  int latestCompleted = 0;
  int latestTotal = 0;
  double latestAccuracy = 0.0;

  // Translated part data (for the grid).
  List<Map<String, String>> _translatedConstitutionParts = [];

  // We track the current language to detect changes
  // and only re-translate when necessary.
  String? _currentLanguage;

  // UI text to translate
  String _translatedTitle = "Constitutional Quiz";
  String _translatedLatestPartLabel = "Latest Part";
  String _translatedQuestionsCompletedLabel = "Questions Completed";
  String _translatedAccuracyLabel = "Accuracy";
  String _translatedContinueLearning = "Continue Learning";
  String _translatedNoPartCompleted = "No Part Completed";
  String _translatedQuestionsCompletedText = "questions completed";
  String _translatedAllParts = "All Parts";
  String _translatedNoPart = "No Part";
  String _translatedLast = "Last:";

  // We'll store the user’s latestPart in a translated form as well.
  String _translatedLatestPartValue = "";

  @override
  void initState() {
    super.initState();
    loadLatestStats();
  }

  /// Load local stats from SharedPreferences.
  Future<void> loadLatestStats() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      latestPart = prefs.getString("latestPart") ?? "N/A";
      latestCompleted = prefs.getInt("latestCompleted") ?? 0;
      latestTotal = prefs.getInt("latestTotal") ?? 0;
      latestAccuracy = prefs.getDouble("latestAccuracy") ?? 0.0;
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    // We listen to the current language from LanguageProvider.
    final languageProvider = Provider.of<LanguageProvider>(context, listen: true);
    final selectedLang = languageProvider.selectedLanguage;

    // If the language changed, re-run translations immediately.
    if (_currentLanguage != selectedLang) {
      _currentLanguage = selectedLang;
      _updateTranslations(_currentLanguage!);
    }
  }

  /// Translates all static text + constitution part data + latestPart value.
  Future<void> _updateTranslations(String langCode) async {
    try {
      // 1. Translate the top-level screen title.
      _translatedTitle =
          await TranslationService.translate("Constitutional Quiz", langCode);

      // 2. Translate stat tab labels.
      _translatedLatestPartLabel =
          await TranslationService.translate("Latest Part", langCode);
      _translatedQuestionsCompletedLabel =
          await TranslationService.translate("Questions Completed", langCode);
      _translatedAccuracyLabel =
          await TranslationService.translate("Accuracy", langCode);

      // 3. Translate "Continue Learning" and "No Part Completed" text.
      _translatedContinueLearning =
          await TranslationService.translate("Continue Learning", langCode);
      _translatedNoPartCompleted =
          await TranslationService.translate("No Part Completed", langCode);

      // 4. Translate "questions completed" (for the list tile).
      _translatedQuestionsCompletedText = await TranslationService.translate(
        "questions completed",
        langCode,
      );

      // 5. Translate "All Parts" heading.
      _translatedAllParts =
          await TranslationService.translate("All Parts", langCode);

      // 6. Translate "No Part" (for stat if there's no part).
      _translatedNoPart =
          await TranslationService.translate("No Part", langCode);

      // 7. Translate "Last:" label for the top row stat.
      _translatedLast = await TranslationService.translate("Last:", langCode);

      // 8. Translate the dynamic latestPart value if not "N/A".
      if (latestPart != "N/A") {
        _translatedLatestPartValue =
            await TranslationService.translate(latestPart, langCode);
      } else {
        _translatedLatestPartValue = "";
      }

      // 9. Translate the entire constitutionParts list.
      List<Map<String, String>> newTranslatedParts = [];
      for (var part in constitutionParts) {
        final tPartNumber =
            await TranslationService.translate(part.partNumber, langCode);
        final tTitle = await TranslationService.translate(part.title, langCode);
        final tArticles =
            await TranslationService.translate(part.articleRange, langCode);
        newTranslatedParts.add({
          "originalPartNumber": part.partNumber, // keep original for doc ID
          "originalTitle": part.title,
          "originalArticles": part.articleRange,
          "tPartNumber": tPartNumber,
          "tTitle": tTitle,
          "tArticles": tArticles,
        });
      }

      // Update the state so the UI re-renders immediately
      // with the new translated text.
      setState(() {
        _translatedConstitutionParts = newTranslatedParts;
      });
    } catch (e) {
      print("Error translating quiz home page data: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    // Get screen dimensions.
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return CustomAppBar(
      title: _translatedTitle, // Translated "Constitutional Quiz"
      icon: Icons.quiz,
      body: Scrollbar(
        thumbVisibility: true,
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // TOP "STATS" ROW (Dynamic + translated labels)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // "Last: $latestPart" or "No Part"
                  _buildStatTab(
                    context,
                    latestPart != "N/A"
                        ? "$_translatedLast $_translatedLatestPartValue"
                        : _translatedNoPart,
                    _translatedLatestPartLabel,
                  ),
                  // e.g. "3 / 10" => "Questions Completed"
                  _buildStatTab(
                    context,
                    latestTotal > 0 ? "$latestCompleted / $latestTotal" : "0 / 0",
                    _translatedQuestionsCompletedLabel,
                  ),
                  // e.g. "45.6%" => "Accuracy"
                  _buildStatTab(
                    context,
                    latestTotal > 0
                        ? "${latestAccuracy.toStringAsFixed(1)}%"
                        : "0%",
                    _translatedAccuracyLabel,
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // CONTINUE LEARNING SECTION
              Text(
                _translatedContinueLearning,
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 2,
                child: ListTile(
                  onTap: () {
                    if (latestPart != "N/A") {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => QuizScreen(partName: latestPart),
                        ),
                      );
                    }
                  },
                  contentPadding: const EdgeInsets.all(16),
                  title: Text(
                    latestPart != "N/A"
                        ? _translatedLatestPartValue
                        : _translatedNoPartCompleted,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 8),
                      Text(
                        latestTotal > 0
                            ? '$latestCompleted / $latestTotal $_translatedQuestionsCompletedText'
                            : '0 / 0 $_translatedQuestionsCompletedText',
                        style: const TextStyle(fontSize: 14),
                      ),
                      const SizedBox(height: 8),
                      LinearProgressIndicator(
                        value: latestTotal > 0 ? latestCompleted / latestTotal : 0,
                        backgroundColor: Colors.grey.shade300,
                        valueColor: const AlwaysStoppedAnimation<Color>(Colors.blue),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // ALL PARTS SECTION
              Text(
                _translatedAllParts, // e.g. "All Parts" in current language
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),

              // GridView for constitutional parts (translated).
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _translatedConstitutionParts.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 0.56,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                ),
                itemBuilder: (context, index) {
                  final partData = _translatedConstitutionParts[index];
                  return _buildPartBlock(partData, screenWidth);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Builds each stat tab with translated labels/values.
  Widget _buildStatTab(BuildContext context, String value, String label) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        padding: const EdgeInsets.symmetric(vertical: 20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade200,
              blurRadius: 6,
              spreadRadius: 2,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              value,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    color: Colors.blue,
                    fontWeight: FontWeight.bold,
                    fontSize: 16, 
                  ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              textAlign: TextAlign.center,
              style: Theme.of(context)
                  .textTheme
                  .bodyMedium
                  ?.copyWith(color: Colors.black54, fontSize: 14),
            ),
          ],
        ),
      ),
    );
  }

  // Builds each constitutional part block using translated text, but uses
  // the original doc ID (English) for Firestore lookups.
  Widget _buildPartBlock(Map<String, String> partData, double screenWidth) {
    // The original doc ID (in English).
    final docId =
        "${partData["originalPartNumber"]}: ${partData["originalTitle"]} (${partData["originalArticles"]})";

    // The translated text to display in UI.
    final tPartNumber = partData["tPartNumber"] ?? "";
    final tTitle = partData["tTitle"] ?? "";
    final tArticles = partData["tArticles"] ?? "";

    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => QuizScreen(partName: docId),
          ),
        );
      },
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        elevation: 3,
        child: Padding(
          padding: EdgeInsets.all(screenWidth * 0.04),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                tPartNumber,
                style: const TextStyle(
                  fontSize: 16,
                  color: Colors.blue,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                tTitle,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                tArticles,
                style: const TextStyle(
                  fontSize: 14,
                  color: Colors.grey,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
