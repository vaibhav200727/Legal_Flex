import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:provider/provider.dart';

// Import your custom app bar, language provider, and translation service.
import '../widgets/custom_appbar.dart';
import '../providers/language_provider.dart';
import '../services/translation_service.dart';

class ConsumerSimpScreen extends StatefulWidget {
  const ConsumerSimpScreen({super.key});

  @override
  _ConsumerSimpScreenState createState() => _ConsumerSimpScreenState();
}

class _ConsumerSimpScreenState extends State<ConsumerSimpScreen> {
  final FlutterTts flutterTts = FlutterTts();

  // Local data for Consumer Rights articles.
  final List<Map<String, String>> _articles = [
    {
      "title": "Right to Safety:",
      "part": "Consumer Rights",
      "simplifiedText": "Consumers are protected against hazardous products and services.",
      "exampleScenario": "A company recalls a defective product that poses a risk to consumers' health and safety.",
      "originalArticle": "As provided under the Consumer Protection Act, ensuring safety standards."
    },
    {
      "title": "Right to be Informed:",
      "part": "Consumer Rights",
      "simplifiedText": "Consumers have the right to receive complete and accurate information about products and services.",
      "exampleScenario": "Food labels display nutritional content, expiry dates, and ingredients so consumers can make informed choices.",
      "originalArticle": "Consumer Protection guidelines mandate full disclosure of product information."
    },
    {
      "title": "Right to Choose:",
      "part": "Consumer Rights",
      "simplifiedText": "Consumers can choose from a variety of products and services without undue pressure.",
      "exampleScenario": "Multiple companies offer similar products, allowing consumers to select based on quality and price.",
      "originalArticle": "The principle of free choice as upheld by consumer rights legislation."
    },
    {
      "title": "Right to Redressal:",
      "part": "Consumer Rights",
      "simplifiedText": "Consumers can seek compensation for defective goods or poor services.",
      "exampleScenario": "A customer files a complaint with a consumer forum and receives a refund for a malfunctioning appliance.",
      "originalArticle": "Enshrined in the Consumer Protection Act to guarantee fair treatment."
    },
    {
      "title": "Right to Consumer Education:",
      "part": "Consumer Rights",
      "simplifiedText": "Consumers should be educated about their rights and responsibilities.",
      "exampleScenario": "Workshops and online resources help consumers understand how to identify scams and make better purchasing decisions.",
      "originalArticle": "As promoted by consumer rights organizations and stipulated in consumer protection policies."
    },
    {
      "title": "Right to Fair Trade Practices:",
      "part": "Consumer Rights",
      "simplifiedText": "Consumers deserve transparent, honest, and fair treatment in transactions.",
      "exampleScenario": "Retailers clearly state pricing and terms of sale, avoiding hidden fees and deceptive advertising.",
      "originalArticle": "A core principle of the Consumer Protection Act ensuring fair market practices."
    },
    {
      "title": "Right to Privacy:",
      "part": "Consumer Rights",
      "simplifiedText": "Consumers have the right to secure their personal information from misuse.",
      "exampleScenario": "An e-commerce platform employs strict data protection measures to safeguard customer data.",
      "originalArticle": "Part of digital consumer rights under modern data protection laws."
    }
  ];

  // Translated screen title and articles.
  String _translatedScreenTitle = "Consumer Rights Articles";
  List<Map<String, String>> _translatedArticles = [];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  /// Update translations for the screen title and each article field.
  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLanguage = languageProvider.selectedLanguage;

    try {
      // Translate the screen title.
      _translatedScreenTitle = await TranslationService.translate(
        "Consumer Rights Articles",
        selectedLanguage,
      );

      // Translate each article's fields.
      List<Map<String, String>> newArticles = [];
      for (var article in _articles) {
        final tTitle = await TranslationService.translate(article['title']!, selectedLanguage);
        final tPart = await TranslationService.translate(article['part']!, selectedLanguage);
        final tSimplifiedText =
            await TranslationService.translate(article['simplifiedText']!, selectedLanguage);
        final tExampleScenario =
            await TranslationService.translate(article['exampleScenario']!, selectedLanguage);
        final tOriginalArticle =
            await TranslationService.translate(article['originalArticle']!, selectedLanguage);

        newArticles.add({
          "title": tTitle,
          "part": tPart,
          "simplifiedText": tSimplifiedText,
          "exampleScenario": tExampleScenario,
          "originalArticle": tOriginalArticle,
        });
      }

      if (mounted) {
        setState(() {
          _translatedArticles = newArticles;
        });
      }
    } catch (e) {
      debugPrint("❌ Translation error: $e");
    }
  }

  /// Text-to-speech functionality.
  void _speak(String text) async {
    await flutterTts.speak(text);
  }

  @override
  Widget build(BuildContext context) {
    return CustomAppBar(
      title: _translatedScreenTitle,
      icon: Icons.shopping_cart,
      body: ListView.builder(
        padding: const EdgeInsets.all(12.0),
        itemCount: _translatedArticles.length,
        itemBuilder: (context, index) {
          final article = _translatedArticles[index];
          return Container(
            margin: const EdgeInsets.symmetric(vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.blue),
              borderRadius: BorderRadius.circular(8),
            ),
            child: ListTile(
              leading: const Icon(Icons.article, color: Colors.blue),
              title: Text(
                article["title"] ?? "",
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              trailing: const Icon(Icons.chevron_right, color: Colors.blue),
              onTap: () {
                _showArticleDialog(article);
              },
            ),
          );
        },
      ),
    );
  }

  /// Displays an AlertDialog with detailed article information.
  void _showArticleDialog(Map<String, String> article) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(article["title"] ?? ""),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildDialogSection("📌 Part", article["part"]),
                _buildDialogSection("📜 Simplified Text", article["simplifiedText"]),
                _buildDialogSection("💡 Example/Scenario", article["exampleScenario"]),
                _buildDialogSection("📖 Original Article", article["originalArticle"]),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: () => _speak(article["simplifiedText"] ?? ""),
                  icon: const Icon(Icons.volume_up),
                  label: const Text("Read Aloud"),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Close", style: TextStyle(color: Colors.blueAccent)),
            )
          ],
        );
      },
    );
  }

  /// Helper widget for formatting dialog sections.
  Widget _buildDialogSection(String title, String? content) {
    if (content == null || content.isEmpty) return const SizedBox();
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.blueAccent,
            ),
          ),
          const SizedBox(height: 5),
          Text(content, style: const TextStyle(fontSize: 14)),
        ],
      ),
    );
  }
}
