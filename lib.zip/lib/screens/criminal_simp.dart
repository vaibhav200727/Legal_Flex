import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:provider/provider.dart';

// Import your custom app bar, language provider, and translation service.
import '../widgets/custom_appbar.dart';
import '../providers/language_provider.dart';
import '../services/translation_service.dart';

class CriminalArticlesScreen extends StatefulWidget {
  const CriminalArticlesScreen({super.key});

  @override
  _CriminalArticlesScreenState createState() => _CriminalArticlesScreenState();
}

class _CriminalArticlesScreenState extends State<CriminalArticlesScreen> {
  final FlutterTts flutterTts = FlutterTts();

  // Local data for the articles (frontend only)
  final List<Map<String, String>> _articles = [
    {
      "title": "Article 1: Murder (Sec 302)",
      "part": "IV",
      "simplifiedText": "Deals with punishment for intentional homicide.",
      "exampleScenario":
          "A person is charged under Section 302 for deliberately killing another individual.",
      "originalArticle": "Indian Penal Code, Section 302"
    },
    {
      "title": "Article 2: Rape (Sec 376)",
      "part": "IV",
      "simplifiedText": "Prescribes severe penalties for the crime of rape.",
      "exampleScenario":
          "A trial is conducted under Section 376 for a person convicted of committing rape.",
      "originalArticle": "Indian Penal Code, Section 376"
    },
    {
      "title": "Article 3: Cheating (Sec 420)",
      "part": "IV",
      "simplifiedText": "Criminalizes acts of cheating and dishonesty that cause financial loss.",
      "exampleScenario":
          "A fraud case is tried under Section 420 where an individual deceives another for monetary gain.",
      "originalArticle": "Indian Penal Code, Section 420"
    },
    {
      "title": "Article 4: Theft (Sec 378)",
      "part": "IV",
      "simplifiedText": "Outlines punishment for the act of theft.",
      "exampleScenario":
          "A person is prosecuted under Section 378 for stealing valuables from a store.",
      "originalArticle": "Indian Penal Code, Section 378"
    },
    {
      "title": "Article 5: Attempt to Murder (Sec 307)",
      "part": "IV",
      "simplifiedText": "Addresses offenses related to attempting to commit murder.",
      "exampleScenario":
          "An individual is charged under Section 307 for an attempt to kill another, even though the murder was not completed.",
      "originalArticle": "Indian Penal Code, Section 307"
    },
    {
      "title": "Article 6: Kidnapping for Ransom (Sec 364A)",
      "part": "IV",
      "simplifiedText": "Criminalizes kidnapping with the intent of demanding ransom.",
      "exampleScenario":
          "A person is implicated in a kidnapping case under Section 364A where ransom was demanded for the victim's release.",
      "originalArticle": "Indian Penal Code, Section 364A"
    },
    {
      "title": "Article 7: Obscenity (Sec 294)",
      "part": "IV",
      "simplifiedText": "Penalizes acts of public obscenity, including indecent behavior in public places.",
      "exampleScenario":
          "A person is prosecuted under Section 294 for performing obscene acts in a public area.",
      "originalArticle": "Indian Penal Code, Section 294"
    }
  ];

  // Translated screen title and articles.
  String _translatedScreenTitle = "Criminal Articles";
  List<Map<String, String>> _translatedArticles = [];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  /// Update translations for the screen title and all article fields.
  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLanguage = languageProvider.selectedLanguage;

    try {
      // Translate the screen title.
      _translatedScreenTitle = await TranslationService.translate(
        "Criminal Articles",
        selectedLanguage,
      );

      // Translate each article's fields.
      List<Map<String, String>> newArticles = [];
      for (var article in _articles) {
        final tTitle = await TranslationService.translate(article['title']!, selectedLanguage);
        final tPart = await TranslationService.translate(article['part']!, selectedLanguage);
        final tSimplifiedText =
            await TranslationService.translate(article['simplifiedText']!, selectedLanguage);
        final tExampleScenario =
            await TranslationService.translate(article['exampleScenario']!, selectedLanguage);
        final tOriginalArticle =
            await TranslationService.translate(article['originalArticle']!, selectedLanguage);

        newArticles.add({
          "title": tTitle,
          "part": tPart,
          "simplifiedText": tSimplifiedText,
          "exampleScenario": tExampleScenario,
          "originalArticle": tOriginalArticle,
        });
      }

      if (mounted) {
        setState(() {
          _translatedArticles = newArticles;
        });
      }
    } catch (e) {
      debugPrint("❌ Translation error: $e");
    }
  }

  /// Text-to-speech functionality.
  void _speak(String text) async {
    await flutterTts.speak(text);
  }

  @override
  Widget build(BuildContext context) {
    return CustomAppBar(
      title: _translatedScreenTitle,
      icon: Icons.gavel,
      body: ListView.builder(
        padding: const EdgeInsets.all(12.0),
        itemCount: _translatedArticles.length,
        itemBuilder: (context, index) {
          final article = _translatedArticles[index];
          return Container(
            margin: const EdgeInsets.symmetric(vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.blue),
              borderRadius: BorderRadius.circular(8),
            ),
            child: ListTile(
              leading: const Icon(Icons.article, color: Colors.blue),
              title: Text(
                article["title"] ?? "",
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              trailing: const Icon(Icons.chevron_right, color: Colors.blue),
              onTap: () {
                _showArticleDialog(article);
              },
            ),
          );
        },
      ),
    );
  }

  /// Displays an AlertDialog with detailed article information.
  void _showArticleDialog(Map<String, String> article) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(article["title"] ?? ""),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildDialogSection("📌 Part", article["part"]),
                _buildDialogSection("📜 Simplified Text", article["simplifiedText"]),
                _buildDialogSection("💡 Example/Scenario", article["exampleScenario"]),
                _buildDialogSection("📖 Original Article", article["originalArticle"]),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: () => _speak(article["simplifiedText"] ?? ""),
                  icon: const Icon(Icons.volume_up),
                  label: const Text("Read Aloud"),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Close", style: TextStyle(color: Colors.blueAccent)),
            )
          ],
        );
      },
    );
  }

  /// Helper widget for formatting dialog sections.
  Widget _buildDialogSection(String title, String? content) {
    if (content == null || content.isEmpty) return const SizedBox();
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.blueAccent,
            ),
          ),
          const SizedBox(height: 5),
          Text(content, style: const TextStyle(fontSize: 14)),
        ],
      ),
    );
  }
}
