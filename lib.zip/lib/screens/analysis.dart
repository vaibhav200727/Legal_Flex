import 'dart:async';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import '../services/api_service.dart';
import 'recommendation_screen.dart'; // Suggested Acts/Recommendation screen
import '../widgets/custom_appbar.dart'; // Your custom app bar widget
import 'package:provider/provider.dart';
import '../providers/language_provider.dart';
import '../services/translation_service.dart';

class AnalysisScreen extends StatefulWidget {
  final String caseName;
  final String caseDescription;
  final String priority;
  final String dueDate;
  final String keyFeatures;

  const AnalysisScreen({
    super.key,
    required this.caseName,
    required this.caseDescription,
    required this.priority,
    required this.dueDate,
    required this.keyFeatures,
  });

  @override
  State<AnalysisScreen> createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends State<AnalysisScreen> with SingleTickerProviderStateMixin {
  final List<String> judiciaryFacts = [
    "The Supreme Court of India was established on January 28, 1950.",
    "India has one of the longest constitutions in the world with 448 articles.",
    "The Chief Justice of India is the highest judicial authority in the country.",
    "The Indian Judiciary follows the principle of 'Separation of Powers'.",
    "The concept of 'Public Interest Litigation (PIL)' was introduced in the 1980s.",
    "The Supreme Court has the power of judicial review to ensure laws comply with the Constitution.",
    "The President of India appoints Supreme Court judges based on recommendations from the Collegium system.",
    "There are 25 High Courts in India, with the Allahabad High Court being the largest.",
    "Article 32 of the Indian Constitution gives citizens the right to constitutional remedies.",
    "The Judiciary in India operates independently from the Executive and Legislature."
  ];

  // Translatable Strings (handled via TranslationService)
  String translatedTitle = "Case Analysis";
  String translatedAnalyzing = "Analyzing your case...";
  String translatedProceedButton = "Proceed to Suggested Acts";

  late AnimationController _animationController;
  int _currentFactIndex = 0;
  late Timer _factTimer;
  late Animation<Offset> _slideAnimation;

  bool _isLoading = true;
  bool _hasError = false;
  Map<String, dynamic>? predictionResult;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _slideAnimation = Tween<Offset>(begin: const Offset(1, 0), end: const Offset(0, 0))
        .animate(_animationController);
    _startFactRotation();
    _fetchPrediction();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  @override
  void dispose() {
    _factTimer.cancel();
    _animationController.dispose();
    super.dispose();
  }

  void _startFactRotation() {
    _currentFactIndex = 0;
    _animationController.forward(from: 0);
    _factTimer = Timer.periodic(const Duration(seconds: 10), (timer) {
      setState(() {
        _currentFactIndex = (_currentFactIndex + 1) % judiciaryFacts.length;
        _animationController.forward(from: 0);
      });
    });
  }

  Future<void> _fetchPrediction() async {
    try {
      final apiService = ApiService();
      String caseDetails = "${widget.caseName}. ${widget.caseDescription}";
      predictionResult = await apiService.getPrediction(
        caseDetails: caseDetails,
        keyFeatures: widget.keyFeatures,
      );
      await apiService.savePrediction(
        caseTitle: widget.caseName,
        caseDescription: widget.caseDescription,
        priority: widget.priority,
        filingDate: widget.dueDate,
        prediction: predictionResult!,
      );
      setState(() {
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _hasError = true;
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error fetching prediction: $e")),
      );
    }
  }

  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    String selectedLanguage = languageProvider.selectedLanguage;
    try {
      translatedTitle = await TranslationService.translate("Case Analysis", selectedLanguage);
      translatedAnalyzing = await TranslationService.translate("Analyzing your case...", selectedLanguage);
      translatedProceedButton = await TranslationService.translate("Proceed to Suggested Acts", selectedLanguage);
      if (mounted) setState(() {});
    } catch (e) {
      print("Translation Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    // Use MediaQuery to get screen dimensions.
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;

    return CustomAppBar(
      title: translatedTitle,
      icon: Icons.article,
      body: Center(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.04,
            vertical: screenHeight * 0.02,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Responsive Lottie animation.
              SizedBox(
                width: screenWidth * 0.6,
                height: screenWidth * 0.6,
                child: Lottie.asset('assets/animations/justiceloading.json', fit: BoxFit.contain),
              ),
              SizedBox(height: screenHeight * 0.015),
              Text(
                translatedAnalyzing,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: screenWidth * 0.06, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: screenHeight * 0.02),
              SlideTransition(
                position: _slideAnimation,
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
                  child: Text(
                    judiciaryFacts[_currentFactIndex],
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: screenWidth * 0.04, fontWeight: FontWeight.w500),
                  ),
                ),
              ),
              SizedBox(height: screenHeight * 0.04),
              // Display button based on API result.
              _isLoading
                  ? const SizedBox()
                  : _hasError
                      ? ElevatedButton(
                          onPressed: () => Navigator.pop(context),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            padding: EdgeInsets.symmetric(
                                vertical: screenWidth * 0.04, horizontal: screenWidth * 0.05),
                          ),
                          child: Text(
                            "Go Back",
                            style: TextStyle(color: Colors.white, fontSize: screenWidth * 0.045),
                          ),
                        )
                      : ElevatedButton(
                          onPressed: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (_) => SuggestedActsScreen(
                                  caseName: widget.caseName,
                                  caseDescription: widget.caseDescription,
                                  priority: widget.priority,
                                  dueDate: widget.dueDate,
                                  prediction: predictionResult!,
                                ),
                              ),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            padding: EdgeInsets.symmetric(
                                vertical: screenWidth * 0.04, horizontal: screenWidth * 0.05),
                          ),
                          child: Text(
                            translatedProceedButton,
                            style: TextStyle(color: Colors.white, fontSize: screenWidth * 0.045),
                          ),
                        ),
            ],
          ),
        ),
      ),
    );
  }
}
