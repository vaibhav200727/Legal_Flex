import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:provider/provider.dart';

// Import your custom app bar, language provider, and translation service.
import '../widgets/custom_appbar.dart';
import '../providers/language_provider.dart';
import '../services/translation_service.dart';

class ArticleSimplificationScreen3 extends StatefulWidget {
  const ArticleSimplificationScreen3({super.key});

  @override
  _ArticleSimplificationScreenState3 createState() => _ArticleSimplificationScreenState3();
}

class _ArticleSimplificationScreenState3 extends State<ArticleSimplificationScreen3> {
  final FlutterTts flutterTts = FlutterTts();

  // Local data for the articles (frontend only)
  final List<Map<String, String>> _articles = [
    {
      "title": "Article 41:",
      "part": "Part IV (Directive Principles)",
      "simplifiedText":
          "Encourages the State to secure the right to work, education, and public assistance for those facing unemployment.",
      "exampleScenario":
          "A government launches a job training and placement program to help long-term unemployed citizens re-enter the workforce.",
      "originalArticle":
          "Article 41: Right to work, education, and public assistance in certain cases."
    },
    {
      "title": "Article 42:",
      "part": "Part IV (Directive Principles)",
      "simplifiedText":
          "Aims to ensure just and humane conditions of work along with adequate maternity relief.",
      "exampleScenario":
          "Legislation is introduced to mandate safe working hours and proper maternity leave for employees.",
      "originalArticle":
          "Article 42: Provision for just and humane conditions of work and maternity relief."
    },
    {
      "title": "Article 43:",
      "part": "Part IV (Directive Principles)",
      "simplifiedText":
          "Calls for securing a living wage and equitable remuneration for workers.",
      "exampleScenario":
          "A policy is implemented to guarantee that all workers receive a minimum wage sufficient for a decent standard of living.",
      "originalArticle": "Article 43: Living wage, etc."
    },
    {
      "title": "Article 19(1)(g):",
      "part": "Part III (Fundamental Rights)",
      "simplifiedText":
          "Guarantees the right to practice any profession, trade, or business without undue interference.",
      "exampleScenario":
          "An individual starts a small business and faces no unnecessary regulatory hurdles, exercising their right to choose a profession.",
      "originalArticle":
          "Article 19(1)(g): Right to practice any profession or to carry on any occupation, trade, or business."
    },
    {
      "title": "Article 14:",
      "part": "Part III (Fundamental Rights)",
      "simplifiedText":
          "Ensures equality before the law, thereby prohibiting discrimination in employment opportunities.",
      "exampleScenario":
          "A job candidate is selected purely on merit, with no discrimination based on caste, gender, or religion.",
      "originalArticle":
          "Article 14: Equality before the law."
    },
    {
      "title": "Article 15:",
      "part": "Part III (Fundamental Rights)",
      "simplifiedText":
          "Prohibits discrimination on various grounds, ensuring equal access to job opportunities.",
      "exampleScenario":
          "A company adopts a non-discriminatory hiring policy that promotes diversity and equal opportunity.",
      "originalArticle":
          "Article 15: Prohibition of discrimination on grounds of religion, race, caste, sex, or place of birth."
    },
    {
      "title": "Article 39(e):",
      "part": "Part IV (Directive Principles)",
      "simplifiedText":
          "Directs the State to protect the health and strength of workers by ensuring safe working conditions.",
      "exampleScenario":
          "Workplace safety regulations are strengthened so that employees are protected from hazardous working conditions.",
      "originalArticle":
          "Article 39(e): The State shall direct its policy towards securing that the health and strength of workers, men and women, and the tender age of children are not abused."
    }
  ];

  // Translated screen title and articles.
  String _translatedScreenTitle = "Jobs Simplifications";
  List<Map<String, String>> _translatedArticles = [];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  /// Update translations for the screen title and all article fields.
  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLanguage = languageProvider.selectedLanguage;

    try {
      // Translate the screen title.
      _translatedScreenTitle = await TranslationService.translate(
        "Article Simplifications",
        selectedLanguage,
      );

      // Translate each article's fields.
      List<Map<String, String>> newArticles = [];
      for (var article in _articles) {
        final tTitle = await TranslationService.translate(article['title']!, selectedLanguage);
        final tPart = await TranslationService.translate(article['part']!, selectedLanguage);
        final tSimplifiedText =
            await TranslationService.translate(article['simplifiedText']!, selectedLanguage);
        final tExampleScenario =
            await TranslationService.translate(article['exampleScenario']!, selectedLanguage);
        final tOriginalArticle =
            await TranslationService.translate(article['originalArticle']!, selectedLanguage);

        newArticles.add({
          "title": tTitle,
          "part": tPart,
          "simplifiedText": tSimplifiedText,
          "exampleScenario": tExampleScenario,
          "originalArticle": tOriginalArticle,
        });
      }

      if (mounted) {
        setState(() {
          _translatedArticles = newArticles;
        });
      }
    } catch (e) {
      debugPrint("❌ Translation error: $e");
    }
  }

  /// Text-to-speech functionality.
  void _speak(String text) async {
    await flutterTts.speak(text);
  }

  @override
  Widget build(BuildContext context) {
    return CustomAppBar(
      title: _translatedScreenTitle,
      icon: Icons.article,
      body: ListView.builder(
        padding: const EdgeInsets.all(12.0),
        itemCount: _translatedArticles.length,
        itemBuilder: (context, index) {
          final article = _translatedArticles[index];
          return Container(
            margin: const EdgeInsets.symmetric(vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.blue),
              borderRadius: BorderRadius.circular(8),
            ),
            child: ListTile(
              leading: const Icon(Icons.article, color: Colors.blue),
              title: Text(
                article["title"] ?? "",
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              trailing: const Icon(Icons.chevron_right, color: Colors.blue),
              onTap: () {
                _showArticleDialog(article);
              },
            ),
          );
        },
      ),
    );
  }

  /// Displays an AlertDialog with detailed article information.
  void _showArticleDialog(Map<String, String> article) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(article["title"] ?? ""),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildDialogSection("📌 Part", article["part"]),
                _buildDialogSection("📜 Simplified Text", article["simplifiedText"]),
                _buildDialogSection("💡 Example/Scenario", article["exampleScenario"]),
                _buildDialogSection("📖 Original Article", article["originalArticle"]),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: () => _speak(article["simplifiedText"] ?? ""),
                  icon: const Icon(Icons.volume_up),
                  label: const Text("Read Aloud"),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Close", style: TextStyle(color: Colors.blueAccent)),
            )
          ],
        );
      },
    );
  }

  /// Helper widget for formatting dialog sections.
  Widget _buildDialogSection(String title, String? content) {
    if (content == null || content.isEmpty) return const SizedBox();
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.blueAccent,
            ),
          ),
          const SizedBox(height: 5),
          Text(content, style: const TextStyle(fontSize: 14)),
        ],
      ),
    );
  }
}
