import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_chat_ui/flutter_chat_ui.dart';
import 'package:flutter_chat_types/flutter_chat_types.dart' as types;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:uuid/uuid.dart';
import 'package:crypto/crypto.dart' as crypto;
import 'package:intl/intl.dart';

// Import your custom BlockchainService (ensure it's implemented with init(), storeDocument(), etc.)
import 'package:project/services/blockchain_service.dart';
import 'package:project/screens/pdf_preview_screen.dart';
import 'package:project/widgets/custom_appbar.dart';

enum ChatState {
  welcome,
  categorySelection,
  documentSelection,
  fillingPlaceholders,
  completed
}

class ChatbotScreen extends StatefulWidget {
  const ChatbotScreen({super.key});

  @override
  _ChatbotScreenState createState() => _ChatbotScreenState();
}

class _ChatbotScreenState extends State<ChatbotScreen> {
  // Chat UI messages
  final List<types.Message> _messages = [];

  // Bot & User references
  final types.User _botUser = const types.User(id: 'bot', firstName: 'Bot');
  final types.User _userUser = const types.User(id: 'user', firstName: 'User');

  // For generating unique message IDs
  final Uuid _uuid = const Uuid();

  // Controller for the user's text input
  final TextEditingController _messageController = TextEditingController();

  // The UID loaded from SharedPreferences
  String storedUid = "";

  // Current chatbot state
  ChatState _chatState = ChatState.welcome;

  // Category data
  final List<String> _categoryList = [
    "1. Essential Legal Affidavits & Declarations",
    "2. Rental & Property Agreements",
    "3. Employment & Business Contracts",
    "4. Police Complaints & Legal Notices",
    "5. Consumer & Service Complaints",
    "6. Legal & Financial Agreements",
    "7. Tenant & Landlord Complaints",
    "8. Workplace & Labor Complaints",
    "9. Personal Legal Documents"
  ];

  final List<String> _categoryCollections = [
    "legal_affidavits",
    "rental_property",
    "employment_business",
    "police_complaints",
    "consumer_complaints",
    "legal_financial_agreements",
    "tenant_landlord_complaints",
    "workplace_labor_complaints",
    "personal_legal_documents"
  ];

  // Firestore docs for the chosen category
  List<DocumentSnapshot> _docsInCategory = [];
  int _selectedCategoryIndex = -1;
  int _selectedDocIndex = -1;
  String _selectedDocName = "";

  // Document template & placeholders
  String _templateText = "";
  List<String> _placeholders = [];
  final Map<String, String> _answers = {};
  int _currentPlaceholderIndex = 0;

  // PDF file path for local preview
  String? _pdfFilePath;

  // Blockchain service (for docHash storage)
  final BlockchainService _blockchainService = BlockchainService();

  // We will log debug statements in chatbot_logs.txt
  File? _logFile;

  @override
  void initState() {
    super.initState();
    _initLogging();                // 1) Initialize logging
    _loadUidAndStart();            // 2) Load UID & start conversation
  }

  /// Step 1: Initialize the log file
  Future<void> _initLogging() async {
    final directory = await getApplicationDocumentsDirectory();
    _logFile = File('${directory.path}/chatbot_logs.txt');
    // Overwrite or create fresh log file
    _logFile!.writeAsStringSync(
      "=== Chatbot Logs Started at ${DateTime.now()} ===\n",
      mode: FileMode.write,
    );
  }

  /// Helper: Write logs to the file and do a standard print
  void _log(String msg) {
    final timestamp = DateFormat('yyyy-MM-dd HH:mm:ss').format(DateTime.now());
    final logLine = "[$timestamp] $msg\n";
    // 1) Print to console
    print(logLine);
    // 2) Append to file
    _logFile?.writeAsStringSync(logLine, mode: FileMode.append);
  }

  /// Step 2: Load UID from SharedPreferences and start chatbot conversation
  Future<void> _loadUidAndStart() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      storedUid = prefs.getString('uid') ?? "";
      _log("Loaded UID from SharedPreferences: $storedUid");

      // Initialize your blockchain service if needed
      await _blockchainService.init();
      _log("BlockchainService initialized.");

      _startConversation();
    } catch (e) {
      _log("Error in _loadUidAndStart: $e");
    }
  }

  /// Start or restart the conversation
  void _startConversation() {
    setState(() {
      _messages.clear();
      _chatState = ChatState.welcome;
      _pdfFilePath = null;
    });

    _addBotMessage(
      "Hello! What document type would you like to generate today?\nType \"exit\" or \"back\" at any time.\n\nPick a category by typing its number:\n${_categoryList.join("\n")}",
    );

    setState(() => _chatState = ChatState.categorySelection);
  }

  /// Helper: Add a bot message to the UI
  void _addBotMessage(String text) {
    final botMsg = types.TextMessage(
      author: _botUser,
      createdAt: DateTime.now().millisecondsSinceEpoch,
      id: _uuid.v4(),
      text: text.trim(),
    );
    setState(() => _messages.insert(0, botMsg));
    _log("BOT: $text");
  }

  /// Helper: Add a user message to the UI
  void _addUserMessage(String text) {
    final userMsg = types.TextMessage(
      author: _userUser,
      createdAt: DateTime.now().millisecondsSinceEpoch,
      id: _uuid.v4(),
      text: text.trim(),
    );
    setState(() => _messages.insert(0, userMsg));
    _log("USER: $text");
  }

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  /// "Back" logic for each ChatState
  void _handleBack() {
    switch (_chatState) {
      case ChatState.completed:
        _addBotMessage("Document Generated. Type \"exit\" to restart.");
        break;
      case ChatState.welcome:
      case ChatState.categorySelection:
        _addBotMessage(
          "Which category do you want? Type 1–9:\n${_categoryList.join("\n")}",
        );
        _chatState = ChatState.categorySelection;
        break;
      case ChatState.documentSelection:
        _chatState = ChatState.categorySelection;
        _addBotMessage(
          "Pick a category by typing its number:\n${_categoryList.join("\n")}",
        );
        break;
      case ChatState.fillingPlaceholders:
        if (_currentPlaceholderIndex == 0) {
          _chatState = ChatState.documentSelection;
          _askDocSelection();
        } else {
          _currentPlaceholderIndex--;
          final field = _placeholders[_currentPlaceholderIndex];
          _addBotMessage("Please enter a value for: {$field}");
        }
        break;
    }
  }

  /// Step A: Ask user to pick a doc from the chosen category
  void _askDocSelection() {
    String docMsg = "Choose a document by typing its number:\n";
    for (int i = 0; i < _docsInCategory.length; i++) {
      docMsg += "${i + 1}. ${_docsInCategory[i].id}\n";
    }
    _addBotMessage(docMsg);
  }

  /// Step B: Handle category selection
  Future<void> _handleCategorySelection(String userInput) async {
    final catNum = int.tryParse(userInput) ?? -1;
    if (catNum < 1 || catNum > 9) {
      _addBotMessage("Invalid category. Please enter 1–9.");
      return;
    }
    _selectedCategoryIndex = catNum - 1;
    final collectionName = _categoryCollections[_selectedCategoryIndex];
    _log("Selected category index=$_selectedCategoryIndex => $collectionName");

    try {
      final snap = await FirebaseFirestore.instance.collection(collectionName).get();
      _docsInCategory = snap.docs;
      if (_docsInCategory.isEmpty) {
        _addBotMessage("No documents found in that category. Type \"exit\" to restart.");
        return;
      }
      _chatState = ChatState.documentSelection;
      _askDocSelection();
    } catch (e) {
      _log("Error reading Firestore for category: $e");
      _addBotMessage("Error reading Firestore: $e. Type \"exit\" to restart.");
    }
  }

  /// Step C: Handle doc selection
  Future<void> _handleDocumentSelection(String userInput) async {
    final docNum = int.tryParse(userInput) ?? -1;
    if (docNum < 1 || docNum > _docsInCategory.length) {
      _addBotMessage("Invalid document number. Type 1–${_docsInCategory.length} or \"exit\".");
      return;
    }
    _selectedDocIndex = docNum - 1;
    final docSnap = _docsInCategory[_selectedDocIndex];
    _templateText = docSnap.get("template");
    _placeholders = List<String>.from(docSnap.get("fields"));
    _selectedDocName = docSnap.id;
    _answers.clear();
    _currentPlaceholderIndex = 0;

    setState(() => _chatState = ChatState.fillingPlaceholders);
    _log("Selected Doc: $_selectedDocName => placeholders=${_placeholders.length}");
    _askNextPlaceholder();
  }

  /// Step D: Ask each placeholder question
  void _askNextPlaceholder() {
    if (_currentPlaceholderIndex < _placeholders.length) {
      final field = _placeholders[_currentPlaceholderIndex];
      _addBotMessage("Please enter a value for: {$field}");
    } else {
      _generateDocument();
    }
  }

  /// Step E: Generate final doc, store hash on chain, upload to Firebase, etc.
  Future<void> _generateDocument() async {
    _log("Starting document generation...");
    // 1) Fill placeholders
    String filledDoc = _templateText;
    _answers.forEach((key, value) {
      filledDoc = filledDoc.replaceAll("{$key}", value);
    });

    // 2) Create docName with subcategory + timestamp
    final timestamp = DateFormat("ddMMyy_HHmmssSSS").format(DateTime.now());
    final docName = "${_selectedDocName}_$timestamp";

    // 3) Build PDF in memory
    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        build: (pw.Context context) => pw.Padding(
          padding: const pw.EdgeInsets.all(20),
          child: pw.Text(filledDoc, style: pw.TextStyle(fontSize: 16)),
        ),
      ),
    );
    final pdfBytes = await pdf.save();
    _log("Converted doc to PDF. pdfBytes.length=${pdfBytes.length}");

    // 4) Compute docHash from the generated PDF file bytes
    final docHash = crypto.sha256.convert(pdfBytes).toString();
    _log("Computed docHash from PDF: $docHash");

    // 5) Upload PDF to Firebase
    final storageRef = FirebaseStorage.instance.ref().child("documents_generated/$docName.pdf");
    String downloadUrl = "";
    try {
      final uploadTask = storageRef.putData(pdfBytes);
      final snapshot = await uploadTask.whenComplete(() {});
      downloadUrl = await snapshot.ref.getDownloadURL();
      _log("Uploaded PDF. downloadUrl=$downloadUrl");
    } catch (e) {
      _log("Error uploading PDF to Firebase: $e");
      _addBotMessage("Error uploading PDF: $e");
    }

    // 6) Store docHash on chain
    try {
      await _blockchainService.storeDocument(docName, docHash);
      _log("Stored docHash on-chain for docName=$docName => hash=$docHash");
    } catch (e) {
      _log("Blockchain Error storing docHash for $docName: $e");
    }

    // 7) Store doc metadata in Firestore (no docHash)
    try {
      await FirebaseFirestore.instance
          .collection("documents_generated")
          .doc(docName)
          .set({
        "uid": storedUid,
        "document": filledDoc,
        "timestamp": FieldValue.serverTimestamp(),
        "downloadUrl": downloadUrl,
        "sub_category": _selectedDocName,
      });
      _log("Saved doc metadata in Firestore => docName=$docName");
    } catch (e) {
      _log("Firestore Error: $e");
      _addBotMessage("Error storing doc metadata: $e");
    }

    // 8) Optionally save locally for preview
    try {
      Directory? dir;
      if (Platform.isAndroid) {
        dir = Directory("/storage/emulated/0/Download");
      } else {
        dir = await getApplicationDocumentsDirectory();
      }
      final filePath = "${dir.path}/$docName.pdf";
      final file = File(filePath);
      await file.writeAsBytes(pdfBytes);
      _pdfFilePath = filePath;
      _log("Saved PDF locally at $filePath");
      _addBotMessage(
        "Document Generated & Stored!\n"
        "Type \"preview\" (with quotes) to view the PDF, or \"exit\" to restart."
      );
      setState(() => _chatState = ChatState.completed);
    } catch (e) {
      _log("Error saving PDF locally: $e");
      _addBotMessage(
        "Error saving PDF locally: $e\n"
        "Type \"exit\" to restart."
      );
    }
  }

  /// If the user is in placeholder state
  void _handlePlaceholderInput(String userInput) {
    final field = _placeholders[_currentPlaceholderIndex];
    _answers[field] = userInput.trim();
    _log("Placeholder answered => $field=$userInput");
    _currentPlaceholderIndex++;
    _askNextPlaceholder();
  }

  /// Once doc is generated
  void _handleCompletedInput(String userInput) {
    if (userInput == "\"preview\"") {
      if (_pdfFilePath != null) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => PdfPreviewScreen(pdfPath: _pdfFilePath!),
          ),
        );
      } else {
        _addBotMessage("No PDF file path found. Type \"exit\" to restart.");
      }
    } else {
      // anything else => restart
      _startConversation();
    }
  }

  /// Main chat input handler
  void _handleSendPressed() {
    final userMsg = _messageController.text.trim();
    if (userMsg.isEmpty) return;
    _addUserMessage(userMsg);
    _messageController.clear();

    if (userMsg == "\"exit\"") {
      _startConversation();
      return;
    }
    if (userMsg == "\"back\"") {
      _handleBack();
      return;
    }

    switch (_chatState) {
      case ChatState.welcome:
      case ChatState.categorySelection:
        _handleCategorySelection(userMsg);
        break;
      case ChatState.documentSelection:
        _handleDocumentSelection(userMsg);
        break;
      case ChatState.fillingPlaceholders:
        _handlePlaceholderInput(userMsg);
        break;
      case ChatState.completed:
        _handleCompletedInput(userMsg);
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      body: CustomAppBar(
        title: "Legal Chatbot",
        icon: Icons.gavel,
        body: Container(
          color: isDarkMode ? Colors.black : Colors.white,
          child: Column(
            children: [
              // Chat area
              Expanded(
                child: Chat(
                  messages: _messages,
                  onSendPressed: (_) {},
                  user: _userUser,
                  showUserAvatars: true,
                  theme: DefaultChatTheme(
                    backgroundColor: Colors.transparent,
                    inputBackgroundColor: Colors.transparent,
                  ),
                ),
              ),
              // Input Bar
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _messageController,
                        decoration: InputDecoration(
                          hintText: "Type your requirements...",
                          hintStyle: TextStyle(
                            color: isDarkMode ? Colors.grey[400] : Colors.grey[500],
                          ),
                          filled: true,
                          fillColor: isDarkMode ? Colors.grey[800] : Colors.grey[200],
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 14
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(24),
                            borderSide: BorderSide.none,
                          ),
                        ),
                        style: TextStyle(
                          fontSize: 16,
                          color: isDarkMode ? Colors.white : Colors.black,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    // Send Button
                    GestureDetector(
                      onTap: _handleSendPressed,
                      child: Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: const Color.fromARGB(255, 3, 34, 108),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.send, color: Colors.white, size: 24),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Helper: parse date from docId like "prefix_ddmmyyyy_optionalStuff"
  String _parseDateFromDocId(String docId) {
    final parts = docId.split("_");
    if (parts.length >= 2) {
      final ddmmyyyy = parts[1];
      if (ddmmyyyy.length == 8) {
        final dd = ddmmyyyy.substring(0, 2);
        final mm = ddmmyyyy.substring(2, 4);
        final yyyy = ddmmyyyy.substring(4, 8);
        return "$dd/$mm/$yyyy";
      }
    }
    return "Unknown Date";
  }
}
