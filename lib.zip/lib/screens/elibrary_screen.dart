import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';
import '../services/book_service.dart';
import '../../services/translation_service.dart';
import '../../providers/language_provider.dart';
import '../../widgets/custom_appbar.dart';
import 'pdf_screen.dart';

class LawLibraryScreen extends StatefulWidget {
  const LawLibraryScreen({super.key});

  @override
  State<LawLibraryScreen> createState() => _LawLibraryScreenState();
}

class _LawLibraryScreenState extends State<LawLibraryScreen> {
  String translatedTitle = "Library";
  String selectedLanguage = "en";
  String? selectedCategory;
  List<Map<String, dynamic>> allBooks = [];
  List<Map<String, dynamic>> continueReadingBooks = [];
  bool isLoading = true;
  String? uid;
  Stream<List<Map<String, dynamic>>>? continueReadingStream;

  final BookService _bookService = BookService();

  @override
  void initState() {
    super.initState();
    _loadUid();
    _fetchBooks();
  }

  Future<void> _loadUid() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      uid = prefs.getString('uid') ; // Use the UID from Firestore
      if (uid != null) {
        continueReadingStream = _bookService.streamContinueReadingBooks(uid!);
        print("Initialized continueReadingStream for UID: $uid");
      } else {
        print("Failed to initialize continueReadingStream: UID is null");
      }
    });
    print("Loaded UID in LawLibraryScreen: $uid");
  }

  Future<void> _fetchBooks() async {
    setState(() {
      isLoading = true;
    });
    allBooks = await _bookService.fetchAllBooks();
    for (var book in allBooks) {
      print("Book in allBooks: ${book['title']}, file_url: ${book['file_url']}, id: ${book['id']}");
    }
    setState(() {
      isLoading = false;
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    selectedLanguage = languageProvider.selectedLanguage;

    try {
      translatedTitle = await TranslationService.translate("Library", selectedLanguage);
      if (mounted) setState(() {});
    } catch (e) {
      print("❌ Translation Error: $e");
    }
  }

  String _sanitizeFileName(String title) {
    return title
        .replaceAll(RegExp(r'[^\w\s-]'), '')
        .replaceAll(RegExp(r'\s+'), '_')
        .toLowerCase();
  }

  Future<String> _downloadPdf(String url, String docName) async {
    try {
      final sanitizedUrl = url.trim();
      print("Attempting to download PDF from URL: $sanitizedUrl");
      if (sanitizedUrl.isEmpty) {
        throw Exception("Invalid PDF URL: empty or null for document $docName");
      }

      final parsedUri = Uri.tryParse(sanitizedUrl);
      if (parsedUri == null || !parsedUri.hasAbsolutePath) {
        throw Exception("Invalid PDF URL: $sanitizedUrl for document $docName");
      }

      final dir = await getTemporaryDirectory();
      final filePath = "${dir.path}/$docName.pdf";
      print("Downloading PDF to temporary location: $filePath");

      final response = await http.get(parsedUri);
      if (response.statusCode == 200) {
        final file = File(filePath);
        await file.writeAsBytes(response.bodyBytes);
        print("PDF downloaded successfully to: $filePath");
        return filePath;
      } else {
        throw Exception("Failed to download PDF: ${response.statusCode} for URL $sanitizedUrl");
      }
    } catch (e) {
      print("Error downloading PDF: $e");
      throw Exception("Error downloading PDF: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context);

    final filteredBooks = selectedCategory == null
        ? allBooks
        : allBooks.where((book) => book['category'] == selectedCategory).toList();

    final popularCollections = [
      {
        'title': 'Administration',
        'count': 6,
        'gradient': [Colors.redAccent, Colors.orangeAccent],
      },
      {
        'title': 'Constitution',
        'count': 4,
        'gradient': [Colors.blueAccent, Colors.lightBlueAccent],
      },
      {
        'title': 'Governance',
        'count': 6,
        'gradient': [Colors.teal, Colors.tealAccent],
      },
      {
        'title': 'Judiciary',
        'count': 6,
        'gradient': [Colors.pinkAccent, Colors.pink.shade200],
      },
      {
        'title': 'Law',
        'count': 6,
        'gradient': [Colors.greenAccent, Colors.lightGreenAccent],
      },
      {
        'title': 'Miscellaneous',
        'count': 8,
        'gradient': [Colors.deepPurpleAccent, Colors.purpleAccent.shade200],
      },
      {
        'title': 'Rights',
        'count': 6,
        'gradient': [Colors.cyanAccent, Colors.cyan.shade200],
      },
      {
        'title': 'Politics',
        'count': 5,
        'gradient': [Colors.amberAccent, Colors.yellowAccent],
      },
    ];

    return CustomAppBar(
      title: translatedTitle,
      icon: Icons.library_books,
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Popular Collections',
              style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 12.h),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              crossAxisSpacing: 12.w,
              mainAxisSpacing: 12.h,
              childAspectRatio: 2.2,
              children: popularCollections.map((collection) {
                return _collectionBox(
                  collection['title'] as String,
                  collection['count'] as int,
                  collection['gradient'] as List<Color>,
                );
              }).toList(),
            ),
            SizedBox(height: 24.h),
            Text(
              'Continue Reading',
              style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 12.h),
            continueReadingStream == null
                ? Center(
                    child: Text(
                      'Loading recent books...',
                      style: TextStyle(fontSize: 16.sp, color: Colors.grey),
                    ),
                  )
                : StreamBuilder<List<Map<String, dynamic>>>(
                    stream: continueReadingStream,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return Center(child: CircularProgressIndicator());
                      }
                      if (snapshot.hasError) {
                        print("Error in continue reading stream: ${snapshot.error}");
                        print("Stack trace: ${snapshot.stackTrace}");
                        return Center(
                          child: Column(
                            children: [
                              Text(
                                'Error loading recent books',
                                style: TextStyle(fontSize: 16.sp, color: Colors.grey),
                              ),
                              SizedBox(height: 8.h),
                              ElevatedButton(
                                onPressed: () {
                                  setState(() {
                                    continueReadingStream = _bookService.streamContinueReadingBooks(uid!);
                                  });
                                },
                                child: Text('Retry'),
                              ),
                            ],
                          ),
                        );
                      }
                      continueReadingBooks = snapshot.data ?? [];
                      if (continueReadingBooks.isEmpty) {
                        return Center(
                          child: Text(
                            'No recent books',
                            style: TextStyle(fontSize: 16.sp, color: Colors.grey),
                          ),
                        );
                      }
                      return Column(
                        children: continueReadingBooks.map((doc) {
                          print("Rendering continue reading book: $doc");
                          return _continueReadingCard(doc);
                        }).toList(),
                      );
                    },
                  ),
            SizedBox(height: 24.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  selectedCategory != null
                      ? 'Books in $selectedCategory'
                      : 'All Books',
                  style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold),
                ),
                if (selectedCategory != null)
                  TextButton(
                    onPressed: () {
                      setState(() {
                        selectedCategory = null;
                      });
                    },
                    child: Text(
                      'Clear',
                      style: TextStyle(fontSize: 14.sp),
                    ),
                  ),
              ],
            ),
            SizedBox(height: 12.h),
            isLoading
                ? const Center(child: CircularProgressIndicator())
                : filteredBooks.isEmpty
                    ? Center(
                        child: Text(
                          'No books',
                          style: TextStyle(fontSize: 16.sp, color: Colors.grey),
                        ),
                      )
                    : GridView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: filteredBooks.length,
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          crossAxisSpacing: 12.w,
                          mainAxisSpacing: 12.h,
                          childAspectRatio: 0.4,
                        ),
                        itemBuilder: (context, index) {
                          final book = filteredBooks[index];
                          return _bookCard(
                            book['cover_url'] as String,
                            book['title'] as String,
                            book['file_url'] as String,
                            book['id'] as String,
                          );
                        },
                      ),
          ],
        ),
      ),
    );
  }

  Widget _continueReadingCard(Map<String, dynamic> doc) {
    // Add safety checks for required fields
    final String bookId = doc['id']?.toString() ?? '';
    final String title = doc['title']?.toString() ?? 'Unknown Title';
    final String fileUrl = doc['file_url']?.toString() ?? '';
    final int lastPage = (doc['lastPage'] is int) ? doc['lastPage'] : 1;
    final int totalPages = (doc['totalPages'] is int) ? doc['totalPages'] : 1;

    return GestureDetector(
      onTap: () async {
        try {
          if (fileUrl.isEmpty) {
            throw Exception("Invalid PDF URL: empty or null for document $title");
          }

          final docName = _sanitizeFileName(title);
          final pdfPath = await _downloadPdf(fileUrl, docName);

          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => PdfScreen(
                pdfPath: pdfPath,
                title: title,
                downloadUrl: fileUrl,
                bookId: bookId,
                initialPage: lastPage,
              ),
            ),
          );
        } catch (e) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Error: $e")),
          );
        }
      },
      child: Card(
        elevation: 2,
        margin: EdgeInsets.only(bottom: 12.h),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.r),
        ),
        child: Padding(
          padding: EdgeInsets.all(12.w),
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: Colors.blue.shade100,
                radius: 20.r,
                child: Icon(
                  Icons.picture_as_pdf,
                  color: Colors.blue,
                  size: 20.r,
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      '$lastPage/$totalPages Pages Read',
                      style: TextStyle(
                        fontSize: 12.sp,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _bookCard(String imageUrl, String title, String fileUrl, String bookId) {
    print("Attempting to load image for $title: $imageUrl");
    print("File URL for $title: $fileUrl");
    return GestureDetector(
      onTap: () async {
        try {
          if (fileUrl.trim().isEmpty) {
            throw Exception("File URL is empty or null for book: $title");
          }

          final docName = _sanitizeFileName(title);
          final pdfPath = await _downloadPdf(fileUrl, docName);

          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => PdfScreen(
                pdfPath: pdfPath,
                title: title,
                downloadUrl: fileUrl,
                bookId: bookId,
                initialPage: 1,
              ),
            ),
          );
        } catch (e) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Error: $e")),
          );
        }
      },
      child: Container(
        margin: EdgeInsets.only(bottom: 8.h),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10.r),
              child: Image.network(
                imageUrl,
                width: 120.w,
                height: 150.h,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  print("Error loading image for $title: $error");
                  return Container(
                    width: 120.w,
                    height: 150.h,
                    color: Colors.grey,
                    child: Icon(
                      Icons.book,
                      size: 40.r,
                    ),
                  );
                },
                loadingBuilder: (context, child, loadingProgress) {
                  if (loadingProgress == null) return child;
                  return Container(
                    width: 120.w,
                    height: 150.h,
                    color: Colors.grey.shade300,
                    child: Center(
                      child: CircularProgressIndicator(
                        value: loadingProgress.expectedTotalBytes != null
                            ? loadingProgress.cumulativeBytesLoaded /
                                (loadingProgress.expectedTotalBytes ?? 1)
                            : null,
                      ),
                    ),
                  );
                },
              ),
            ),
            SizedBox(height: 4.h),
            SizedBox(
              width: 120.w,
              child: LayoutBuilder(
                builder: (context, constraints) {
                  double fontSize = 13.sp;
                  const double minFontSize = 10.0;

                  final textSpan = TextSpan(
                    text: title,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: fontSize,
                    ),
                  );
                  final textPainter = TextPainter(
                    text: textSpan,
                    maxLines: 2,
                    textDirection: TextDirection.ltr,
                  );
                  textPainter.layout(maxWidth: constraints.maxWidth);

                  while (textPainter.didExceedMaxLines && fontSize > minFontSize) {
                    fontSize -= 0.5;
                    textPainter.text = TextSpan(
                      text: title,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: fontSize,
                      ),
                    );
                    textPainter.layout(maxWidth: constraints.maxWidth);
                  }

                  return Text(
                    title,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: fontSize,
                    ),
                    maxLines: 2,
                    softWrap: true,
                    overflow: TextOverflow.clip,
                    textAlign: TextAlign.left,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _collectionBox(String title, int count, List<Color> gradientColors) {
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedCategory = title;
        });
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 13.h, horizontal: 12.w),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12.r),
          gradient: LinearGradient(colors: gradientColors),
          boxShadow: [
            BoxShadow(
              color: gradientColors.last.withOpacity(0.3),
              blurRadius: 6,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextStyle(
                fontSize: 14.sp,
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 4.h),
            Text(
              '$count books',
              style: TextStyle(color: Colors.white70, fontSize: 12.sp),
            ),
          ],
        ),
     ),
);
}
}
