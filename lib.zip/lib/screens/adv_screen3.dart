import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/custom_appbar.dart';
// Replace with your actual payment success screen import:
import 'package:project/screens/adv_screen5.dart';

class LawyerDetailScreen extends StatefulWidget {
  final Map<String, dynamic> lawyerData;

  const LawyerDetailScreen({super.key, required this.lawyerData});

  @override
  _LawyerDetailScreenState createState() => _LawyerDetailScreenState();
}

class _LawyerDetailScreenState extends State<LawyerDetailScreen> {
  // Lawyer details from passed data.
  late final String lawyerId;
  late final String name;
  late final String degree;
  late final String lawyerType;
  late final String profileImageUrl;
  late final String state;
  late final String city;
  late final int fees;

  // Session duration for a given day (stored in minutes as String, e.g. "60 minutes")
  late String sessionDuration;

  // Availability data.
  final Map<String, List<String>> _availabilitySlots = {};
  final Map<String, List<String>> _bookedSlots = {};
  Map<String, List<String>> _availableSlots = {};

  // Next 7 days from tomorrow (formatted as "yyyy-MM-dd")
  List<String> _availableDates = [];
  String? _selectedDate;
  String? _selectedTimeSlot;

  String? _userUid;
  bool _loadingAvailability = true;

  // Razorpay instance.
  late Razorpay _razorpay;

  // Map to hold per-date session duration (in minutes).
  final Map<String, int> _dateDurations = {};

  @override
  void initState() {
    super.initState();
    final data = widget.lawyerData;
    lawyerId = data['uid'] ?? "";
    name = data['name'] ?? "Unknown Lawyer";
    degree = data['degree'] ?? "Not Listed";
    lawyerType = data['lawyerType'] ?? "Not Specified";
    profileImageUrl = data['profileImageUrl'] ?? "";
    state = data['state'] ?? "";
    city = data['city'] ?? "";
    fees = data['feesPerHour'] ?? 0;

    // Default session duration before fetching availability.
    sessionDuration = "60 minutes";

    _fetchUserUid();
    _fetchAvailabilityAndBookedSlots();

    // Initialize Razorpay.
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void dispose() {
    _razorpay.clear();
    super.dispose();
  }

  Future<void> _fetchUserUid() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _userUid = prefs.getString('uid');
    });
  }

  /// Fetch availability from Firestore and compute available slots.
  Future<void> _fetchAvailabilityAndBookedSlots() async {
    setState(() => _loadingAvailability = true);
    try {
      // Generate next 7 days from tomorrow.
      List<DateTime> dateObjs = List.generate(
          7, (index) => DateTime.now().add(Duration(days: index + 1)));
      _availableDates =
          dateObjs.map((d) => DateFormat('yyyy-MM-dd').format(d)).toList();

      // 1) Load availability document.
      DocumentSnapshot availabilityDoc = await FirebaseFirestore.instance
          .collection('advoconnect_availability')
          .doc(lawyerId)
          .get();

      if (availabilityDoc.exists) {
        final data = availabilityDoc.data() as Map<String, dynamic>?;
        if (data != null) {
          // Update sessionDuration from backend if available
          if (data.containsKey('sessionDuration')) {
            sessionDuration = "${data['sessionDuration']} minutes";
          }
          // Process the slots field.
          final slotsMap = data['slots'] ?? {};
          (slotsMap as Map<String, dynamic>).forEach((dateStr, value) {
            if (value is Map) {
              _availabilitySlots[dateStr] = List<String>.from(value['slots'] ?? []);
              _dateDurations[dateStr] = value['duration'] is int ? value['duration'] as int : 60;
            }
          });
        }
      }
      // Ensure each generated date has an entry.
      for (var dateStr in _availableDates) {
        if (!_availabilitySlots.containsKey(dateStr)) {
          _availabilitySlots[dateStr] = [];
          _dateDurations[dateStr] = 60; // default 60 minutes
        }
      }

      // 2) Load existing bookings.
      QuerySnapshot bookingSnapshot = await FirebaseFirestore.instance
          .collection('advoconnect_calls')
          .where('lawyerId', isEqualTo: lawyerId)
          .get();
      for (var doc in bookingSnapshot.docs) {
        Map<String, dynamic> bookingData = doc.data() as Map<String, dynamic>;
        String bookedDate = bookingData['date'] ?? "";
        String bookedTime = bookingData['timeSlot'] ?? "";
        if (bookedDate.isNotEmpty && bookedTime.isNotEmpty) {
          _bookedSlots.putIfAbsent(bookedDate, () => []).add(bookedTime);
        }
      }

      // 3) Compute available slots = offered slots minus booked slots.
      _availableSlots = {};
      _availabilitySlots.forEach((dateStr, offeredSlots) {
        List<String> booked = _bookedSlots[dateStr] ?? [];
        List<String> remain = offeredSlots.where((s) => !booked.contains(s)).toList();
        _availableSlots[dateStr] = remain;
      });

      // Default selected date: first date with available slots.
      _selectedDate = _availableDates.firstWhere(
        (d) => _availableSlots[d] != null && _availableSlots[d]!.isNotEmpty,
        orElse: () => _availableDates.isNotEmpty ? _availableDates.first : "",
      );
    } catch (e) {
      print("Error fetching availability: $e");
    }
    setState(() => _loadingAvailability = false);
  }

  /// Open Razorpay checkout window with dynamic amount.
  Future<void> _openCheckout() async {
    // Retrieve the session duration (in minutes) for the selected date.
    int durationForDate = _dateDurations[_selectedDate!] ?? 60;
    double multiplier = 1.0;
    if (durationForDate == 30) {
      multiplier = 0.5;
    } else if (durationForDate == 120) {
      multiplier = 2.0;
    } else if (durationForDate == 180) {
      multiplier = 3.0;
    }
    double amountToPay = fees.toDouble() * multiplier;

    var options = {
      'key': 'rzp_test_CkutVrejMBd1qG', // Replace with your Razorpay key.
      'amount': (amountToPay * 100).toInt(), // Amount in paise.
      'name': 'Consultation Payment for $name',
      'description': 'Consultation Payment',
      'prefill': {
        'contact': '1234567890',
        'email': 'test@example.com',
      },
      'external': {
        'wallets': ['paytm']
      },
    };

    try {
      _razorpay.open(options);
    } catch (e) {
      print("Error opening Razorpay checkout: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error opening checkout: $e")),
      );
    }
  }

  /// Razorpay payment success handler.
  void _handlePaymentSuccess(PaymentSuccessResponse response) async {
    print("Payment Success: ${response.paymentId}");
    int durationForDate = _dateDurations[_selectedDate!] ?? 60;
    double multiplier = 1.0;
    if (durationForDate == 30) {
      multiplier = 0.5;
    } else if (durationForDate == 120) {
      multiplier = 2.0;
    } else if (durationForDate == 180) {
      multiplier = 3.0;
    }
    double amountToPay = fees.toDouble() * multiplier;

    // Show loading dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(child: CircularProgressIndicator()),
    );

    // Ensure lawyer specialty is properly shown (e.g., "Corporate Law").
    String lawyerSpecialty = lawyerType;
    if (!lawyerType.toLowerCase().contains("law")) {
      lawyerSpecialty = "$lawyerType Law";
    }

    // Create the booking in Firestore
    try {
      await _createBooking();
      print("Booking successfully created in Firestore");
    } catch (e) {
      print("Error creating booking: $e");
      Navigator.pop(context); // Close loading dialog
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Payment succeeded but booking failed: $e")),
      );
      return;
    }

    // Close loading dialog and navigate
    Navigator.pop(context);
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => PaymentSuccessfulScreen(
          amountPaid: amountToPay,
          transactionId: response.paymentId ?? "",
          paymentMethod: "RazorPay",
          lawyerName: name,
          lawyerSpecialty: lawyerSpecialty,
          lawyerImageUrl: profileImageUrl,
          bookingDate: _selectedDate ?? "",
          bookingTime: _selectedTimeSlot ?? "",
          bookingDuration: "$durationForDate minutes",
        ),
      ),
    );
  }

  /// Razorpay payment error handler.
  void _handlePaymentError(PaymentFailureResponse response) {
    print("Payment Error: ${response.message}");
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Payment Failed: ${response.message}")),
    );
  }

  /// Razorpay external wallet handler.
  void _handleExternalWallet(ExternalWalletResponse response) {
    print("External Wallet: ${response.walletName}");
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("External Wallet: ${response.walletName}")),
    );
  }

  /// Create a booking document in Firestore.
  Future<void> _createBooking() async {
    if (_userUid == null || _selectedDate == null || _selectedTimeSlot == null) return;
    int durationForDate = _dateDurations[_selectedDate!] ?? 60;
    await FirebaseFirestore.instance.collection('advoconnect_calls').add({
      'lawyerId': lawyerId,
      'userId': _userUid,
      'date': _selectedDate,
      'timeSlot': _selectedTimeSlot,
      'sessionDuration': durationForDate,
      'status': 'booked',
      'amount': fees,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  /// Confirm booking: open Razorpay checkout.
  Future<void> _confirmBooking() async {
    if (_selectedDate == null ||
        _selectedTimeSlot == null ||
        _selectedDate!.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please select a date and time slot.")),
      );
      return;
    }
    await _openCheckout();
    // Booking creation is handled on payment success.
  }

  /// Build dynamic lawyer card using data from widget.lawyerData.
  Widget _buildLawyerCard() {
    final String degreeDynamic = widget.lawyerData['degree'] ?? "Not Listed";
    final String lawyerTypeDynamic = widget.lawyerData['lawyerType'] ?? "Not Specified";
    final String stateDynamic = widget.lawyerData['state'] ?? "Unknown";
    final String cityDynamic = widget.lawyerData['city'] ?? "Unknown";
    final int feesDynamic = widget.lawyerData['feesPerHour'] ?? 0;
    final String profileDynamic = widget.lawyerData['profileImageUrl'] ?? "";
    final String nameDynamic = widget.lawyerData['name'] ?? "Unknown Lawyer";

    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.blue, width: 1),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          // Lawyer Avatar.
          CircleAvatar(
            radius: 28,
            backgroundColor: const Color(0xFFE5E7EB),
            backgroundImage: profileDynamic.isNotEmpty ? NetworkImage(profileDynamic) : null,
            child: profileDynamic.isEmpty
                ? const Icon(Icons.person, color: Color(0xFF9CA3AF), size: 28)
                : null,
          ),
          const SizedBox(height: 12),
          Text(
            nameDynamic,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 4),
          Text(
            "Degree: $degreeDynamic",
            style: const TextStyle(fontSize: 14, color: Colors.grey),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Type of Law Practiced: ',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF111827),
                ),
              ),
              Flexible(
                child: Text(
                  lawyerTypeDynamic,
                  style: const TextStyle(fontSize: 14, color: Color(0xFF374151)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.location_on, size: 16, color: Color(0xFF9CA3AF)),
              const SizedBox(width: 4),
              Text(
                '$stateDynamic, $cityDynamic',
                style: const TextStyle(fontSize: 13, color: Color(0xFF6B7280)),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            '₹$feesDynamic/session per hour',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }

  /// Build date selector chips showing date and per-day duration.
  Widget _buildDateSelector() {
    double screenWidth = MediaQuery.of(context).size.width;
    double itemWidth = (screenWidth - 56) / 3;
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: _availableDates.map((dateStr) {
        final parsedDate = DateFormat('yyyy-MM-dd').parse(dateStr);
        bool isSelected = (dateStr == _selectedDate);
        int dateDur = _dateDurations[dateStr] ?? 60;
        String displayDur = "$dateDur minutes";
        return GestureDetector(
          onTap: () {
            setState(() {
              _selectedDate = dateStr;
              _selectedTimeSlot = null;
            });
          },
          child: Container(
            width: itemWidth,
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
              color: isSelected ? Colors.blue : Colors.white,
              border: Border.all(color: Colors.blue),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    DateFormat('EEE, dd MMM').format(parsedDate),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.blue,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "($displayDur)",
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.blue,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  /// Build grid view of available time slots.
  Widget _buildTimeSlotsGrid() {
    if (_selectedDate == null ||
        !_availableSlots.containsKey(_selectedDate!) ||
        _availableSlots[_selectedDate!]!.isEmpty) {
      return const Center(child: Text("No available slots."));
    }
    final timings = _availableSlots[_selectedDate!]!;
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: timings.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 2.5,
      ),
      itemBuilder: (context, index) {
        final timeSlot = timings[index];
        bool isSelected = (timeSlot == _selectedTimeSlot);
        return GestureDetector(
          onTap: () {
            setState(() {
              _selectedTimeSlot = timeSlot;
            });
          },
          child: Container(
            decoration: BoxDecoration(
              color: isSelected ? Colors.blue : Colors.white,
              border: Border.all(color: Colors.blue),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Center(
              child: Text(
                timeSlot,
                style: TextStyle(
                  fontSize: 14,
                  color: isSelected ? Colors.white : Colors.blue,
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return CustomAppBar(
      title: "Lawyer Details",
      icon: Icons.person,
      body: Container(
        color: Colors.white,
        child: Column(
          children: [
            // Lawyer card at the top.
            _buildLawyerCard(),
            const Divider(height: 1, color: Colors.grey),
            _loadingAvailability
                ? const Expanded(child: Center(child: CircularProgressIndicator()))
                : Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "Select Date",
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 12),
                          _buildDateSelector(),
                          const SizedBox(height: 20),
                          const Text(
                            "Available Time Slots",
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 12),
                          _buildTimeSlotsGrid(),
                        ],
                      ),
                    ),
                  ),
            // Confirm Booking button at bottom.
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              child: ElevatedButton(
                onPressed: _confirmBooking,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 40),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  textStyle: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                child: const Text('Confirm Booking'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}