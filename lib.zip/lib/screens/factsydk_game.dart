import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/translation_service.dart';
import '../providers/language_provider.dart';
import '../widgets/custom_appbar.dart';
import 'package:project/screens/game1.dart';
import 'package:project/screens/game2.dart';

class LegalGamesScreen extends StatefulWidget {
  const LegalGamesScreen({super.key});

  @override
  State<LegalGamesScreen> createState() => _LegalGamesScreenState();
}

class _LegalGamesScreenState extends State<LegalGamesScreen>
    with TickerProviderStateMixin {
  late AnimationController _factController;
  late AnimationController _fateController;

  bool isFactFlipped = false;
  bool isFateFlipped = false;

  String selectedLanguage = "en";
  String translatedTitle = "Legal Games";
  String translatedSubtitle = "Test Your Legal Knowledge";
  String translatedFactOrFaux = "Fact or Faux";
  String translatedChooseYourFate = "Choose Your Fate";
  String translatedLeaderboard = "Leaderboard";

  @override
  void initState() {
    super.initState();
    _factController = AnimationController(
      duration: const Duration(milliseconds: 700),
      vsync: this,
    );
    _fateController = AnimationController(
      duration: const Duration(milliseconds: 700),
      vsync: this,
    );
  }

  @override
  void dispose() {
    _factController.dispose();
    _fateController.dispose();
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    selectedLanguage = languageProvider.selectedLanguage;

    try {
      translatedTitle =
          await TranslationService.translate("Legal Games", selectedLanguage);
      translatedSubtitle = await TranslationService.translate(
          "Test Your Legal Knowledge", selectedLanguage);
      translatedFactOrFaux =
          await TranslationService.translate("Fact or Faux", selectedLanguage);
      translatedChooseYourFate = await TranslationService.translate(
          "Choose Your Fate", selectedLanguage);
      translatedLeaderboard =
          await TranslationService.translate("Leaderboard", selectedLanguage);
      if (mounted) setState(() {});
    } catch (e) {
      print("❌ Translation Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context);
    final screenWidth = media.size.width;
    final screenHeight = media.size.height;

    return CustomAppBar(
      title: translatedTitle,
      icon: Icons.games,
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.05,
          vertical: screenHeight * 0.025,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              translatedSubtitle,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: screenHeight * 0.03),
            _buildFlipCard(
              controller: _factController,
              isFlipped: isFactFlipped,
              front: _buildGameCard(
                context,
                iconData: Icons.balance,
                gameTitle: translatedFactOrFaux,
                description: 'Test your knowledge of legal facts',
                statLabel: 'Best Score: 850',
                media: media,
              ),
              back: _buildBackCard(
                context,
                instructions: '''
1. You will be presented with legal statements.
2. Decide whether each is a fact or faux.
3. +50 points for correct answers, -20 for wrong ones.
4. Aim for the highest score!
                ''',
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const FactOrFauxGame()),
                  );
                },
                media: media,
              ),
              onTap: () {
                setState(() => isFactFlipped = !isFactFlipped);
                isFactFlipped
                    ? _factController.forward()
                    : _factController.reverse();
              },
            ),
            SizedBox(height: screenHeight * 0.025),
            _buildFlipCard(
              controller: _fateController,
              isFlipped: isFateFlipped,
              front: _buildGameCard(
                context,
                iconData: Icons.gavel,
                gameTitle: translatedChooseYourFate,
                description: 'Make legal decisions in scenarios',
                statLabel: 'Cases Solved: 12',
                media: media,
              ),
              back: _buildBackCard(
                context,
                instructions: '''
1. You will face a legal scenario.
2. Choose the most suitable advice.
3. Each right choice earns 10 points.
4. Think critically and respond wisely.
                ''',
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const ChooseYourFateGame()),
                  );
                },
                media: media,
              ),
              onTap: () {
                setState(() => isFateFlipped = !isFateFlipped);
                isFateFlipped
                    ? _fateController.forward()
                    : _fateController.reverse();
              },
            ),
            SizedBox(height: screenHeight * 0.04),
            Text(
              translatedLeaderboard,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: screenHeight * 0.02),
            _buildLeaderboard(media),
          ],
        ),
      ),
    );
  }

  Widget _buildFlipCard({
    required AnimationController controller,
    required bool isFlipped,
    required Widget front,
    required Widget back,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedBuilder(
        animation: controller,
        builder: (context, child) {
          final angle = controller.value * pi;
          final isFront = controller.value < 0.5;
          return Transform(
            transform: Matrix4.identity()
              ..setEntry(3, 2, 0.001)
              ..rotateY(angle),
            alignment: Alignment.center,
            child: isFront
                ? front
                : Transform(
                    alignment: Alignment.center,
                    transform: Matrix4.rotationY(pi),
                    child: back,
                  ),
          );
        },
      ),
    );
  }

  Widget _buildGameCard(BuildContext context,
      {required IconData iconData,
      required String gameTitle,
      required String description,
      required String statLabel,
      required MediaQueryData media}) {
    final screenWidth = media.size.width;
    return Container(
      padding: EdgeInsets.all(screenWidth * 0.04),
      decoration: BoxDecoration(
        color: Colors.indigo.shade50,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(2, 2)),
        ],
      ),
      child: Row(
        children: [
          Icon(iconData, color: Colors.indigo, size: screenWidth * 0.1),
          SizedBox(width: screenWidth * 0.04),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  gameTitle,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: screenWidth * 0.01),
                Text(description),
                SizedBox(height: screenWidth * 0.03),
                Text(
                  statLabel,
                  style: const TextStyle(fontStyle: FontStyle.italic),
                ),
              ],
            ),
          ),
          Icon(Icons.touch_app, size: screenWidth * 0.08, color: Colors.indigo),
        ],
      ),
    );
  }

  Widget _buildBackCard(BuildContext context,
      {required String instructions,
      required VoidCallback onPressed,
      required MediaQueryData media}) {
    final screenWidth = media.size.width;
    return Container(
      padding: EdgeInsets.all(screenWidth * 0.04),
      decoration: BoxDecoration(
        color: Colors.indigo.shade100,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(2, 2)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Instructions",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: screenWidth * 0.03),
          Text(instructions),
          SizedBox(height: screenWidth * 0.04),
          Align(
            alignment: Alignment.centerRight,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.play_arrow, color: Colors.white),
              label: const Text("Play", style: TextStyle(color: Colors.white)),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.indigo),
              onPressed: onPressed,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLeaderboard(MediaQueryData media) {
    final List<Map<String, Object>> leaderboard = [
      {'name': 'Alice Johnson', 'score': 1240},
      {'name': 'Mohit Singh', 'score': 1180},
      {'name': 'Jenny Kim', 'score': 1125},
      {'name': 'Arjun Verma', 'score': 1100},
      {'name': 'Sara Patel', 'score': 1050},
    ];
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: leaderboard.map((entry) {
          return ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.indigo,
              child: Text(
                (entry['name'] as String)[0],
                style: const TextStyle(color: Colors.white),
              ),
            ),
            title: Text(entry['name'] as String),
            trailing: Text(
              '${entry['score']} pts',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          );
        }).toList(),
      ),
    );
  }
}
