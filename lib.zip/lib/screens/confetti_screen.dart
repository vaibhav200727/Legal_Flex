import 'package:flutter/material.dart';
import 'package:confetti/confetti.dart';
import 'package:lottie/lottie.dart';
import 'package:project/screens/home_screen.dart';

class ProfileCreatedPage extends StatefulWidget {
  const ProfileCreatedPage({super.key});

  @override
  _ProfileCreatedPageState createState() => _ProfileCreatedPageState();
}

class _ProfileCreatedPageState extends State<ProfileCreatedPage>
    with SingleTickerProviderStateMixin {
  final ConfettiController _confettiController =
      ConfettiController(duration: const Duration(seconds: 3));
  late final AnimationController _lottieController;

  @override
  void initState() {
    super.initState();

    // Play confetti animation
    _confettiController.play();

    // Initialize the Lottie animation controller
    _lottieController = AnimationController(vsync: this);

    // If you only want the animation to play once, stop after it completes
    _lottieController.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        _lottieController.stop();
      }
    });
  }

  @override
  void dispose() {
    _confettiController.dispose();
    _lottieController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final bool isSmallScreen = size.width < 400;
    final double animationSize = isSmallScreen ? 350 : 500;
    final double buttonHeight = isSmallScreen ? 45 : 55;
    final double fontSizeTitle = isSmallScreen ? 26 : 32;
    final double fontSizeSubtitle = isSmallScreen ? 14 : 16;
    final double spacing = isSmallScreen ? 15 : 30;

    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          // Confetti Animation
          Align(
            alignment: Alignment.topCenter,
            child: ConfettiWidget(
              confettiController: _confettiController,
              blastDirectionality: BlastDirectionality.explosive,
              shouldLoop: false,
              colors: [
                Colors.blue,
                Colors.red,
                Colors.green,
                Colors.orange,
                Colors.purple,
              ],
              numberOfParticles: 7,
            ),
          ),

          // Main Content
          Center(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: size.width * 0.08),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // GPay Tick Animation
                  SizedBox(
                    width: animationSize,
                    height: animationSize,
                    child: Lottie.asset(
                      'assets/animations/gpay_tick.json',
                      controller: _lottieController,
                      fit: BoxFit.contain,
                      onLoaded: (composition) {
                        // Make sure to reset and play from the beginning
                        _lottieController
                          ..duration = composition.duration
                          ..reset()
                          ..forward(from: 0.0);
                      },
                    ),
                  ),
                  SizedBox(height: spacing),

                  // Title: "Profile Created"
                  Text(
                    "Profile Created!",
                    style: TextStyle(
                      fontSize: fontSizeTitle,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: spacing / 2),

                  // Subtitle
                  Text(
                    "Your account has been successfully created.\nGet started now!",
                    style: TextStyle(
                      fontSize: fontSizeSubtitle,
                      color: Colors.grey,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: spacing * 1.2),

                  // Continue Button
                  SizedBox(
                    width: size.width * 0.8,
                    height: buttonHeight,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const HomeScreen(),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color.fromARGB(255, 33, 94, 224),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                      ),
                      child: const Text(
                        "Get Started",
                        style: TextStyle(fontSize: 18, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
