import 'package:flutter/material.dart';
import 'package:project/models/post.dart';
import 'package:project/screens/createpost_screen.dart';
import 'package:project/widgets/custom_appbar.dart';
import 'package:project/widgets/post_card.dart';
import 'package:project/services/post_service.dart';

class CommunityScreen extends StatefulWidget {
  const CommunityScreen({super.key});

  @override
  State<CommunityScreen> createState() => _CommunityScreenState();
}

class _CommunityScreenState extends State<CommunityScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";

  // Default filter and sort options.
  String _selectedCategory = "All Categories";
  final List<String> filterOptions = [
    "All Categories",
    "Corporate Law",
    "Criminal Law",
    "Family Law",
    "Copyright Law"
  ];

  final List<String> sortOptions = [
    "Most Liked",
    "Least Liked",
    "Oldest",
    "Newest",
  ];
  String _selectedSort = "Newest";

  // Navigation debounce.
  bool _isNavigating = false;

  void _onSearchChanged(String value) {
    setState(() {
      _searchQuery = value.trim().toLowerCase();
    });
  }

  void _onFilterPressed() {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return SafeArea(
          child: ListView(
            shrinkWrap: true,
            children: filterOptions.map((option) {
              return ListTile(
                title: Text(option),
                onTap: () {
                  setState(() {
                    _selectedCategory = option;
                  });
                  Navigator.pop(context);
                },
              );
            }).toList(),
          ),
        );
      },
    );
  }

  void _onSortPressed() {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return SafeArea(
          child: ListView(
            shrinkWrap: true,
            children: sortOptions.map((option) {
              return ListTile(
                title: Text(option),
                onTap: () {
                  setState(() {
                    _selectedSort = option;
                  });
                  Navigator.pop(context);
                },
              );
            }).toList(),
          ),
        );
      },
    );
  }

  // Apply search filter based on post title.
  List<Post> _applySearchFilter(List<Post> posts) {
    if (_searchQuery.isEmpty) return posts;
    return posts
        .where((post) => post.postTitle.toLowerCase().contains(_searchQuery))
        .toList();
  }

  // Returns the stream of posts from PostService.
  Stream<List<Post>> _postStream() {
    return PostService().getPosts(
      category: _selectedCategory,
      sortOption: _selectedSort,
    );
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    return CustomAppBar(
      title: "Community Forum",
      icon: Icons.group,
      body: Column(
        children: [
          // Search and "+ Post" button row.
          Padding(
            padding: EdgeInsets.symmetric(
                horizontal: screenWidth * 0.05, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    height: 48,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.grey.shade300),
                    ),
                    child: Row(
                      children: [
                        const SizedBox(width: 8),
                        const Icon(Icons.search, color: Colors.grey),
                        const SizedBox(width: 4),
                        Expanded(
                          child: TextField(
                            controller: _searchController,
                            onChanged: _onSearchChanged,
                            decoration: const InputDecoration(
                              hintText: "Search discussions...",
                              border: InputBorder.none,
                              hintStyle: TextStyle(color: Colors.grey),
                            ),
                            style: const TextStyle(fontSize: 14),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: _isNavigating
                      ? null
                      : () async {
                          setState(() => _isNavigating = true);
                          final newPost = await Navigator.push<Post>(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  const CreateNewPostScreen(),
                            ),
                          );
                          if (newPost != null) {
                            setState(() {}); // Refresh stream if needed.
                          }
                          setState(() => _isNavigating = false);
                        },
                  icon: const Icon(Icons.add, size: 16),
                  label: const Text('Post', style: TextStyle(fontSize: 14)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black87,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                      side: BorderSide(color: Colors.grey.shade300),
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Filter and Sort buttons.
          Padding(
            padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
            child: Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _onFilterPressed,
                    icon: const Icon(Icons.filter_list, size: 16),
                    label: Text(_selectedCategory,
                        style: const TextStyle(fontSize: 14)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black87,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                        side: BorderSide(color: Colors.grey.shade300),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _onSortPressed,
                    icon: const Icon(Icons.sort, size: 16),
                    label: Text(_selectedSort,
                        style: const TextStyle(fontSize: 14)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black87,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                        side: BorderSide(color: Colors.grey.shade300),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          // Post feed: Listen to the posts stream.
          Expanded(
            child: StreamBuilder<List<Post>>(
              stream: _postStream(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(child: Text("Error: ${snapshot.error}"));
                }
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                List<Post> postsFromStream = snapshot.data ?? [];
                postsFromStream = _applySearchFilter(postsFromStream);
                if (postsFromStream.isEmpty) {
                  return const Center(child: Text("No posts found."));
                }
                return ListView.separated(
                  itemCount: postsFromStream.length,
                  itemBuilder: (context, index) {
                    return PostCard(post: postsFromStream[index]);
                  },
                  separatorBuilder: (context, index) => const Divider(
                    thickness: 1,
                    indent: 16,
                    endIndent: 16,
                    color: Color.fromARGB(165, 110, 108, 108),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
