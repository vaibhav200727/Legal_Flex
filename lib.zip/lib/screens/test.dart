import 'package:flutter/material.dart';
import 'dart:math';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/custom_appbar.dart';

class LegalGlossaryScreen extends StatefulWidget {
  const LegalGlossaryScreen({super.key});

  @override
  _LegalGlossaryScreenState createState() => _LegalGlossaryScreenState();
}

class _LegalGlossaryScreenState extends State<LegalGlossaryScreen> {
  bool showAllTerms = false;
  String searchQuery = "";
  List<String> recentlyViewed = [];
  Set<String> savedTerms = {};
  List<String> alphabet = List.generate(26, (index) => String.fromCharCode(65 + index));
  String wordOfTheDay = "";
  String wordDescription = "";
  String selectedLetter = "";

  List<Map<String, String>> legalGlossaryTerms = [
    // A
    {"term": "Adoption Law", "category": "Family Law", "description": "Legal process of adopting a child in India."},
    {"term": "Arbitration", "category": "Dispute Resolution", "description": "A method of resolving disputes outside courts."},
    {"term": "Affidavit", "category": "Legal Document", "description": "A written statement confirmed by oath."},
    {"term": "Anticipatory Bail", "category": "Criminal Law", "description": "Pre-arrest bail granted under Indian law."},
    {"term": "Acquittal", "category": "Criminal Law", "description": "A legal judgment that officially clears an accused."},
    {"term": "Adverse Possession", "category": "Property Law", "description": "Claiming land ownership through continuous use."},
    {"term": "Amendment", "category": "Constitutional Law", "description": "Change or addition to the Indian Constitution."},
    {"term": "Act", "category": "Legislation", "description": "A law passed by the Parliament or State Legislature."},
    {"term": "Arrest Warrant", "category": "Criminal Law", "description": "A legal document authorizing the arrest of a person."},
    {"term": "Alimony", "category": "Family Law", "description": "Spousal support paid after divorce."},

    // B
    {"term": "Bail", "category": "Criminal Law", "description": "Temporary release of an accused before trial."},
    {"term": "Bench", "category": "Judiciary", "description": "A panel of judges in a court."},
    {"term": "Bond", "category": "Legal Document", "description": "A written obligation for payment or performance."},
    {"term": "Burden of Proof", "category": "Evidence Law", "description": "Responsibility to prove an assertion in court."},
    {"term": "Bribery", "category": "Corruption Law", "description": "Offering money or gifts to influence actions."},
    {"term": "By-laws", "category": "Corporate Law", "description": "Rules made by a company or local authority."},
    {"term": "Bench Warrant", "category": "Criminal Law", "description": "Issued by a judge for someone's arrest."},
    {"term": "Beneficiary", "category": "Property Law", "description": "Person who receives benefits from a will/trust."},
    {"term": "Breach of Contract", "category": "Contract Law", "description": "Failure to fulfill a contractual obligation."},
    {"term": "Burglary", "category": "Criminal Law", "description": "Illegal entry into a property to commit a crime."},

    // C
    {"term": "Capital Punishment", "category": "Criminal Law", "description": "The death penalty as a legal punishment."},
    {"term": "Caveat", "category": "Civil Law", "description": "A notice preventing action without notifying the issuer."},
    {"term": "Charge Sheet", "category": "Criminal Law", "description": "A formal police document accusing someone of a crime."},
    {"term": "Cheque Bounce", "category": "Banking Law", "description": "A criminal offense when a cheque is dishonored."},
    {"term": "Child Custody", "category": "Family Law", "description": "Legal right to care for a child after divorce."},
    {"term": "Civil Suit", "category": "Civil Law", "description": "A non-criminal case filed in a court."},
    {"term": "Contempt of Court", "category": "Judiciary", "description": "Disrespecting or disobeying the court's authority."},
    {"term": "Corporate Law", "category": "Business Law", "description": "Laws governing business entities."},
    {"term": "Criminal Breach of Trust", "category": "Criminal Law", "description": "Misuse of property entrusted by another person."},
    {"term": "Cyber Law", "category": "Technology Law", "description": "Laws related to online crimes and digital security."},

    // D
    {"term": "Defamation", "category": "Civil Law", "description": "A false statement harming a person's reputation."},
    {"term": "Decree", "category": "Civil Law", "description": "A final judgment by a court."},
    {"term": "Doctrine of Basic Structure", "category": "Constitutional Law", "description": "The fundamental principles of the Constitution."},
    {"term": "Domestic Violence", "category": "Family Law", "description": "Abuse within a domestic relationship."},
    {"term": "Double Jeopardy", "category": "Criminal Law", "description": "Protection against being tried twice for the same offense."},
    {"term": "Divorce", "category": "Family Law", "description": "Legal dissolution of a marriage."},
    {"term": "Dowry Prohibition Act", "category": "Criminal Law", "description": "A law preventing dowry practices in India."},
    {"term": "Debt Recovery Tribunal", "category": "Financial Law", "description": "A court handling recovery of debts by banks."},
    {"term": "Doctrine of Laches", "category": "Civil Law", "description": "A legal claim may be denied if delayed excessively."},
    {"term": "Dying Declaration", "category": "Criminal Law", "description": "Statement recorded before the death of a witness."},
  ];

  @override
  void initState() {
    super.initState();
    _loadSavedData();
    _setWordOfTheDay();
  }

  Future<void> _loadSavedData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      recentlyViewed = prefs.getStringList('recentlyViewed') ?? [];
      savedTerms = prefs.getStringList('savedTerms')?.toSet() ?? {};
    });
  }

  Future<void> _saveRecentlyViewed() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('recentlyViewed', recentlyViewed);
  }

  Future<void> _saveTerms() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('savedTerms', savedTerms.toList());
  }

  void addToRecentlyViewed(String term) {
    if (!recentlyViewed.contains(term)) {
      setState(() {
        recentlyViewed.insert(0, term); // Insert at the beginning
        if (recentlyViewed.length > 5) recentlyViewed.removeLast(); // Keep only the last 5
        _saveRecentlyViewed(); // Save to SharedPreferences
      });
    }
  }

  void toggleSaved(String term) {
    setState(() {
      if (savedTerms.contains(term)) {
        savedTerms.remove(term);
      } else {
        savedTerms.add(term);
      }
      _saveTerms();
    });
  }

  void _setWordOfTheDay() {
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final random = Random(today.hashCode);
    final randomIndex = random.nextInt(legalGlossaryTerms.length);

    setState(() {
      wordOfTheDay = legalGlossaryTerms[randomIndex]["term"]!;
      wordDescription = legalGlossaryTerms[randomIndex]["description"]!;
    });
  }

  Widget buildAlphabetBar() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: alphabet.map((letter) {
          return GestureDetector(
            onTap: () {
              setState(() {
                selectedLetter = (selectedLetter == letter) ? "" : letter; // Toggle selection
              });
            },
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                color: selectedLetter == letter ? Colors.blueAccent : Colors.transparent,
              ),
              child: Text(
                letter,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: selectedLetter == letter ? Colors.white : Colors.black54,
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;

    // Filter terms by search and selected letter
    List<Map<String, String>> filteredLegalTerms = legalGlossaryTerms.where((term) {
      bool matchesSearch = searchQuery.isEmpty || term["term"]!.toLowerCase().contains(searchQuery);
      bool matchesLetter = selectedLetter.isEmpty || term["term"]!.toUpperCase().startsWith(selectedLetter);
      return matchesSearch && matchesLetter;
    }).toList();

    // Decide how many terms to show based on showAllTerms
    List<Map<String, String>> displayedTerms = showAllTerms
        ? filteredLegalTerms
        : filteredLegalTerms.take(4).toList();

    return CustomAppBar(
      title: "Legal Glossary",
      icon: Icons.library_books,
      body: Scrollbar(
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05, vertical: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Search Bar
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 15),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(30),
                    boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 4)],
                  ),
                  child: TextField(
                    onChanged: (query) {
                      setState(() {
                        searchQuery = query.toLowerCase();
                      });
                    },
                    decoration: InputDecoration(
                      hintText: "Search legal terms",
                      prefixIcon: Icon(Icons.search, color: Colors.blueAccent),
                      border: InputBorder.none,
                    ),
                  ),
                ),
                SizedBox(height: 20),

                // Word of the Day
                Container(
                  padding: EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: Colors.blue[50],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "WORD OF THE DAY",
                        style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.blueAccent),
                      ),
                      SizedBox(height: 8),
                      Text(
                        wordOfTheDay,
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 5),
                      Text(
                        wordDescription,
                        style: TextStyle(fontSize: 14, color: Colors.black87),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 20),

                // Recently Viewed Section
                Text("Recently Viewed", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                recentlyViewed.isEmpty
                    ? Text("No recent views", style: TextStyle(color: Colors.grey))
                    : SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: recentlyViewed.map((term) {
                            return Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 5),
                              child: Chip(label: Text(term)),
                            );
                          }).toList(),
                        ),
                      ),
                SizedBox(height: 20),

                // Saved Terms Section
                Text("Saved Terms", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                savedTerms.isEmpty
                    ? Text("No saved terms", style: TextStyle(color: Colors.grey))
                    : Column(
                        children: savedTerms.map((term) {
                          return Card(
                            child: ListTile(
                              title: Text(term, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                              trailing: IconButton(
                                icon: Icon(
                                  Icons.bookmark,
                                  color: Colors.red,
                                ),
                                onPressed: () => toggleSaved(term),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                SizedBox(height: 20),

                // Alphabet Bar
                buildAlphabetBar(),
                SizedBox(height: 20),

                // Display filtered (or limited) results
                Column(
                  children: displayedTerms.map((term) {
                    return Card(
                      child: ListTile(
                        title: Text(
                          term["term"]!,
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(
                          term["description"]!,
                          style: TextStyle(color: Colors.black87),
                        ),
                        // Add onTap to update recently viewed
                        onTap: () {
                          addToRecentlyViewed(term["term"]!);
                        },
                        trailing: IconButton(
                          icon: Icon(
                            savedTerms.contains(term["term"]) ? Icons.bookmark : Icons.bookmark_border,
                            color: savedTerms.contains(term["term"]) ? Colors.red : Colors.black54,
                          ),
                          onPressed: () => toggleSaved(term["term"]!),
                        ),
                      ),
                    );
                  }).toList(),
                ),

                // View All / Show Less
                if (filteredLegalTerms.length > 4)
                  TextButton(
                    onPressed: () {
                      setState(() {
                        showAllTerms = !showAllTerms;
                      });
                    },
                    child: Text(
                      showAllTerms ? "Show Less ▲" : "View All ▼",
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.blueAccent),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
