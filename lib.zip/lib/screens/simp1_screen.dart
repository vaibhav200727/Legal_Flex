import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:project/screens/consumer_simp.dart';
import 'package:project/screens/contracts_simp.dart';
import 'package:project/screens/criminal_simp.dart';
import 'package:project/screens/cyber_simp.dart';
import 'package:project/screens/jobs_simp.dart';
import 'package:project/screens/tax_simp.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../providers/language_provider.dart';
import '../services/translation_service.dart';
import '../widgets/custom_appbar.dart';

// Import your destination pages
import 'simp2_screen.dart';
import 'simp3_screen.dart';
import 'simp4_screen.dart';
import 'simp5_screen.dart';
import 'simp6_screen.dart';
import 'simp7_screen.dart';

class SimplificationScreen extends StatefulWidget {
  const SimplificationScreen({super.key});
  @override
  _SimplificationScreenState createState() => _SimplificationScreenState();
}

class _SimplificationScreenState extends State<SimplificationScreen> {
  String translatedFeaturedCategories = "Featured Categories";
  String translatedPopularTopics = "Popular Topics";
  String translatedRecentExplanations = "Recent Explanations";
  String translatedLegalQuiz = "Legal Quiz";
  String translatedRecentlyVisited = "Recently Visited";
  String translatedSearchHint = "Search laws, terms, or topics";
  String translatedQuizQuestion =
      "Which Article grants the Right to Freedom of Speech?";
  String translatedPropertyRights = "Property Rights";
  String translatedFamilyLaw = "Family Law";
  String translatedEmploymentLaw = "Employment Law";
  String translatedCriminalLaw = "Criminal Law";
  String translatedConstitutionalBodies = "Constitutional Bodies & Governance";
  String translatedRightsResponsibilities = "Rights & Responsibilities";
  String translatedAdminFinancial = "Administrative & Financial Structure";
  String translatedLocalElections = "Local Administration & Elections";
  String translatedLegalFramework = "Legal Framework & Transitional Provisions";
  String translatedLanguageEmergency = "Language & Emergency Powers";
  String translatedCyber = "Cyber";
  String translatedTax = "Taxation";
  String translatedConsumer = "Consumer";
  String translatedContracts = "Contracts";
  String translatedJobs = "Jobs";
  String translatedCriminal = "Criminal";
  String selectedLanguage = "en";

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  @override
  void initState() {
    super.initState();
    Provider.of<LanguageProvider>(context, listen: false)
        .addListener(_updateTranslations);
  }

  @override
  void dispose() {
    Provider.of<LanguageProvider>(context, listen: false)
        .removeListener(_updateTranslations);
    super.dispose();
  }

  Future<void> _updateTranslations() async {
    final languageProvider =
        Provider.of<LanguageProvider>(context, listen: false);
    selectedLanguage = languageProvider.selectedLanguage;

    try {
      translatedFeaturedCategories = await TranslationService.translate(
          "Featured Categories", selectedLanguage);
      translatedPopularTopics = await TranslationService.translate(
          "Popular Topics", selectedLanguage);
      translatedRecentExplanations = await TranslationService.translate(
          "Recent Explanations", selectedLanguage);
      translatedLegalQuiz =
          await TranslationService.translate("Legal Quiz", selectedLanguage);
      translatedRecentlyVisited = await TranslationService.translate(
          "Recently Visited", selectedLanguage);
      translatedSearchHint = await TranslationService.translate(
          "Search laws, terms, or topics", selectedLanguage);
      translatedQuizQuestion = await TranslationService.translate(
          "Which Article grants the Right to Freedom of Speech?",
          selectedLanguage);
      translatedPropertyRights = await TranslationService.translate(
          "Property Rights", selectedLanguage);
      translatedFamilyLaw =
          await TranslationService.translate("Family Law", selectedLanguage);
      translatedEmploymentLaw = await TranslationService.translate(
          "Employment Law", selectedLanguage);
      translatedCriminalLaw = await TranslationService.translate(
          "Criminal Law", selectedLanguage);
      translatedConstitutionalBodies = await TranslationService.translate(
          "Constitutional Bodies & Governance", selectedLanguage);
      translatedRightsResponsibilities = await TranslationService.translate(
          "Rights & Responsibilities", selectedLanguage);
      translatedAdminFinancial = await TranslationService.translate(
          "Administrative & Financial Structure", selectedLanguage);
      translatedLocalElections = await TranslationService.translate(
          "Local Administration & Elections", selectedLanguage);
      translatedLegalFramework = await TranslationService.translate(
          "Legal Framework & Transitional Provisions", selectedLanguage);
      translatedLanguageEmergency = await TranslationService.translate(
          "Language & Emergency Powers", selectedLanguage);
      translatedCyber = await TranslationService.translate("Cyber", selectedLanguage);
      translatedTax = await TranslationService.translate("Taxation", selectedLanguage);
      translatedConsumer = await TranslationService.translate("Consumer", selectedLanguage);
      translatedContracts = await TranslationService.translate("Contracts", selectedLanguage);
      translatedJobs = await TranslationService.translate("Jobs", selectedLanguage);
      translatedCriminal = await TranslationService.translate("Criminal", selectedLanguage);

      if (mounted) {
        setState(() {});
      }
    } catch (e) {
      print("❌ Translation Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final double buttonWidth = screenWidth * 0.9; // Responsive button width

    // Define the carousel categories along with their target pages.
    // Using gradients from the LawLibraryScreen palette.
    List<Map<String, dynamic>> categories = [
      {
        "title": translatedConstitutionalBodies,
        "icon": Icons.account_balance,
        "gradient": [Colors.blueAccent, Colors.lightBlueAccent],
        "page": const ConstitutionalBodiesScreen(),
      },
      {
        "title": translatedRightsResponsibilities,
        "icon": Icons.gavel,
        "gradient": [Colors.pinkAccent, Colors.pink],
        "page": const RightsResponsibilitiesScreen(),
      },
      {
        "title": translatedAdminFinancial,
        "icon": Icons.business,
        "gradient": [Colors.teal, Colors.tealAccent],
        "page": const AdminFinancialScreen(),
      },
      {
        "title": translatedLocalElections,
        "icon": Icons.how_to_vote,
        "gradient": [Colors.greenAccent, Colors.lightGreenAccent],
        "page": const LocalAdminElectionScreen(),
      },
      {
        "title": translatedLegalFramework,
        "icon": Icons.book,
        "gradient": [Colors.redAccent, Colors.orangeAccent],
        "page": const LegalFrameworkScreen(),
      },
      {
        "title": translatedLanguageEmergency,
        "icon": Icons.language,
        "gradient": [Colors.cyanAccent, Colors.cyan],
        "page": const LanguageEmergencyScreen(),
      },
    ];

    return CustomAppBar(
      title: "Simplified Laws",
      icon: Icons.library_books,
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Search Bar
              const SizedBox(height: 15),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 1),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: const [
                    BoxShadow(color: Colors.black26, blurRadius: 4)
                  ],
                ),
                child: TextField(
                  textAlignVertical: TextAlignVertical.center,
                  decoration: InputDecoration(
                    hintText: translatedSearchHint,
                    prefixIcon:
                        const Icon(Icons.search, color: Colors.blueAccent),
                    border: InputBorder.none,
                    contentPadding:
                        const EdgeInsets.symmetric(vertical: 15),
                  ),
                ),
              ),
              const SizedBox(height: 25),

              // Featured Categories Carousel
              Text(translatedFeaturedCategories,
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              CarouselSlider(
                options: CarouselOptions(
                    height: 150,
                    enlargeCenterPage: true,
                    autoPlay: true),
                items: categories.map((category) {
                  return GestureDetector(
                    onTap: () {
                      // Navigate to the target page when tapped.
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => category["page"],
                        ),
                      );
                    },
                    child: Container(
                      width: screenWidth * 0.7,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: category["gradient"] as List<Color>,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(category["icon"],
                              color: Colors.white, size: 40),
                          const SizedBox(height: 8),
                          Text(
                            category["title"],
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),

              const SizedBox(height: 20),

              // Popular Searches (Connected to target pages)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("Popular Searches",
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w500)),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildCircleItem(
                            translatedCyber,
                            Icons.security,
                            [Colors.indigo, Colors.indigoAccent],
                            const CyberSimplificationScreen()),
                        _buildCircleItem(
                            translatedTax,
                            Icons.attach_money,
                            [Colors.teal, Colors.tealAccent],
                            const ArticleSimplificationScreen1()),
                        _buildCircleItem(
                            translatedConsumer,
                            Icons.shopping_cart,
                            [Colors.deepOrange, Colors.orangeAccent],
                            const ConsumerSimpScreen()),
                      ],
                    ),
                    const SizedBox(height: 15),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildCircleItem(
                            translatedContracts,
                            Icons.library_books,
                            [const Color.fromARGB(255, 198, 83, 224), const Color.fromARGB(255, 207, 157, 229)],
                            const ContractArticlesScreen()),
                        _buildCircleItem(
                            translatedJobs,
                            Icons.work,
                            [Colors.cyan, Colors.cyanAccent],
                            const ArticleSimplificationScreen3()),
                        _buildCircleItem(
                            translatedCriminal,
                            Icons.gavel,
                            [Colors.purple, Colors.deepPurpleAccent],
                            const CriminalArticlesScreen()),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Recently Viewed
              const Text("Recently Viewed",
                  style:
                      TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              Column(
                children: [
                  "Fundamental Rights",
                  "Criminal Law",
                  "Employment Law",
                  "Contract Law"
                ]
                    .map((law) => Card(
                          child: ListTile(
                            title: Text(law,
                                style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold)),
                          ),
                        ))
                    .toList(),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  /// Modified circle item with gradient background.
  Widget _buildCircleItem(
      String text, IconData icon, List<Color> gradientColors, Widget targetPage) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => targetPage),
        );
      },
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(colors: gradientColors),
            ),
            child: Center(
              child: Icon(icon, color: Colors.white, size: 30),
            ),
          ),
          const SizedBox(height: 5),
          Text(text,
              style:
                  const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}
