import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:provider/provider.dart';
import '../widgets/custom_appbar.dart';
import '../providers/language_provider.dart';
import '../providers/save_provider.dart';
import '../services/translation_service.dart';

class ConsumerRightsScreen extends StatefulWidget {
  const ConsumerRightsScreen({super.key});

  @override
  _ConsumerRightsScreenState createState() => _ConsumerRightsScreenState();
}

class _ConsumerRightsScreenState extends State<ConsumerRightsScreen> {
  final FlutterTts flutterTts = FlutterTts();

  String headerText = "Know Your Rights";
  List<String> translatedTitles = consumerRights.map((e) => e['title'] as String).toList();
  List<String> translatedDescriptions = consumerRights.map((e) => e['description'] as String).toList();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLanguage = languageProvider.selectedLanguage;

    try {
      String newHeader = await TranslationService.translate("Know Your Rights", selectedLanguage);
      if (mounted) {
        setState(() {
          headerText = newHeader;
        });
      }
    } catch (e) {
      print("❌ Translation error for header: $e");
    }

    List<String> newTitles = [];
    List<String> newDescriptions = [];
    for (var item in consumerRights) {
      try {
        String tTitle = await TranslationService.translate(item['title'], selectedLanguage);
        String tDesc = await TranslationService.translate(item['description'], selectedLanguage);
        newTitles.add(tTitle);
        newDescriptions.add(tDesc);
      } catch (e) {
        print("❌ Translation error for ${item['title']}: $e");
        newTitles.add(item['title']);
        newDescriptions.add(item['description']);
      }
    }
    if (mounted) {
      setState(() {
        translatedTitles = newTitles;
        translatedDescriptions = newDescriptions;
      });
    }
  }

  void _speak(String text) async {
    await flutterTts.speak(text);
  }

  /// Toggle saved status using SaveProvider.
  void toggleSaveItem(BuildContext context, String item) {
    final saveProvider = Provider.of<SaveProvider>(context, listen: false);
    if (saveProvider.savedItems.contains(item)) {
      saveProvider.removeItem(item);
    } else {
      saveProvider.addItem(item);
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isSmallScreen = screenWidth < 600;
    final saveProvider = Provider.of<SaveProvider>(context);

    return CustomAppBar(
      title: "Know Your Rights",
      icon: Icons.shopping_cart,
      body: Padding(
        padding: EdgeInsets.all(isSmallScreen ? 8.0 : 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            Text(
              headerText,
              style: TextStyle(fontSize: isSmallScreen ? 16 : 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: consumerRights.length,
                itemBuilder: (context, index) {
                  final title = translatedTitles[index];
                  final description = translatedDescriptions[index];
                  final isSaved = saveProvider.savedItems.contains(title);
                  return Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    margin: EdgeInsets.symmetric(vertical: isSmallScreen ? 4 : 6),
                    child: Padding(
                      padding: EdgeInsets.all(isSmallScreen ? 8 : 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                consumerRights[index]['icon'],
                                color: consumerRights[index]['color'],
                                size: isSmallScreen ? 28 : 32,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  title,
                                  style: TextStyle(
                                    fontSize: isSmallScreen ? 14 : 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: Icon(Icons.volume_up, color: Colors.blue, size: isSmallScreen ? 22 : 26),
                                onPressed: () => _speak(description),
                              ),
                              IconButton(
                                icon: Icon(
                                  isSaved ? Icons.bookmark : Icons.bookmark_border,
                                  color: isSaved ? Colors.blue : Colors.grey,
                                  size: isSmallScreen ? 22 : 26,
                                ),
                                onPressed: () {
                                  toggleSaveItem(context, title);
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text(
                            description,
                            style: TextStyle(fontSize: isSmallScreen ? 15 : 20, color: Colors.grey),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

final List<Map<String, dynamic>> consumerRights = [
  {"title": "Right to Be Informed", "icon": Icons.info, "color": Colors.blue, "description": "Consumers must be provided with accurate details about goods and services."},
  {"title": "Right to Safety", "icon": Icons.shield, "color": Colors.red, "description": "Consumers should be protected from hazardous products and services."},
  {"title": "Right to Choose", "icon": Icons.shopping_basket, "color": Colors.green, "description": "Consumers have the freedom to select from a variety of goods and services."},
  {"title": "Right to Redress", "icon": Icons.support, "color": Colors.orange, "description": "Consumers should have access to fair compensation for defective products or fraud."},
  {"title": "Right to Consumer Education", "icon": Icons.book, "color": Colors.purple, "description": "Consumers should be educated on their rights and responsibilities."},
  {"title": "Right to Fair Trade Practices", "icon": Icons.balance, "color": Colors.teal, "description": "Businesses must ensure ethical dealings and fair competition."},
  {"title": "Right to Protection Against Misleading Advertisements", "icon": Icons.ad_units, "color": Colors.amber, "description": "Consumers must not be deceived by false claims in ads."},
  {"title": "Right to Product Warranty & Guarantees", "icon": Icons.verified, "color": Colors.brown, "description": "Products should come with legal warranties and safety guarantees."},
  {"title": "Right to File Consumer Complaints", "icon": Icons.feedback, "color": Colors.pink, "description": "Consumers should have easy access to complaint redressal forums."},
  {"title": "Right to Ethical Business Practices", "icon": Icons.handshake, "color": Colors.indigo, "description": "Companies should operate with transparency and fairness."}
];
