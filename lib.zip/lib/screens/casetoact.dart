import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../providers/language_provider.dart';
import '../services/translation_service.dart';
import '../widgets/custom_appbar.dart';
import 'analysis.dart';

class CaseToActScreen extends StatefulWidget {
  const CaseToActScreen({super.key});

  @override
  _CaseToActScreenState createState() => _CaseToActScreenState();
}

class _CaseToActScreenState extends State<CaseToActScreen> {
  final TextEditingController caseNameController = TextEditingController();
  final TextEditingController caseDescriptionController = TextEditingController();
  final TextEditingController dueDateController = TextEditingController();

  List<TextEditingController> keyFeatureControllers = [
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
  ];

  String selectedPriority = "Medium";

  // Translatable Strings
  String translatedTitle = "Case Filing";
  String translatedCaseNameHint = "Enter case name";
  String translatedCaseDescription = "Case Description";
  String translatedCaseDescHint = "Enter detailed case description...";
  String translatedKeyFeaturesLabel = "Key Features";
  String translatedPriorityLabel = "Priority Level";
  String translatedLowText = "Low";
  String translatedMediumText = "Medium";
  String translatedHighText = "High";
  String translatedDueDateLabel = "Case Filing Date";
  String translatedSelectDueDate = "Select filing date";
  String translatedSubmitButtonText = "Submit Case";

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  Future<void> _updateTranslations() async {
    final languageProvider =
        Provider.of<LanguageProvider>(context, listen: false);
    String selectedLanguage = languageProvider.selectedLanguage;
    try {
      translatedTitle =
          await TranslationService.translate("Case Filing", selectedLanguage);
      translatedCaseNameHint = await TranslationService.translate(
          "Enter case name", selectedLanguage);
      translatedCaseDescription = await TranslationService.translate(
          "Case Description", selectedLanguage);
      translatedCaseDescHint = await TranslationService.translate(
          "Enter detailed case description...", selectedLanguage);
      translatedKeyFeaturesLabel = await TranslationService.translate(
          "Key Features", selectedLanguage);
      translatedPriorityLabel = await TranslationService.translate(
          "Priority Level", selectedLanguage);
      translatedLowText =
          await TranslationService.translate("Low", selectedLanguage);
      translatedMediumText =
          await TranslationService.translate("Medium", selectedLanguage);
      translatedHighText =
          await TranslationService.translate("High", selectedLanguage);
      translatedDueDateLabel = await TranslationService.translate(
          "Case Filing Date", selectedLanguage);
      translatedSelectDueDate = await TranslationService.translate(
          "Select filing date", selectedLanguage);
      translatedSubmitButtonText = await TranslationService.translate(
          "Submit Case", selectedLanguage);
      if (mounted) setState(() {});
    } catch (e) {
      print("❌ Translation Error: $e");
    }
  }

  Future<void> _selectDueDate(BuildContext context) async {
    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
      builder: (context, child) {
        return Theme(
          data: ThemeData.light().copyWith(
            primaryColor: Colors.blue,
            colorScheme: ColorScheme.light(primary: Colors.blue),
            buttonTheme: ButtonThemeData(textTheme: ButtonTextTheme.primary),
          ),
          child: child!,
        );
      },
    );

    if (pickedDate != null) {
      setState(() {
        dueDateController.text = DateFormat('yyyy-MM-dd').format(pickedDate);
      });
    }
  }

  Future<void> _submitCase() async {
    // Gather key features into a comma-separated string.
    List<String> keyFeaturesList = keyFeatureControllers
        .map((controller) => controller.text.trim())
        .where((text) => text.isNotEmpty)
        .toList();
    String keyFeaturesCommaSeparated = keyFeaturesList.join(", ");

    String caseTitle = caseNameController.text.trim();
    String caseDescription = caseDescriptionController.text.trim();
    String dueDate = dueDateController.text.trim();
    String priority = selectedPriority;
    String caseDetails = "$caseTitle. $caseDescription";

    if (caseTitle.isEmpty ||
        caseDescription.isEmpty ||
        keyFeaturesCommaSeparated.isEmpty ||
        dueDate.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please fill in all required fields.")),
      );
      return;
    }

    // Navigate to AnalysisScreen immediately.
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AnalysisScreen(
          caseName: caseTitle,
          caseDescription: caseDescription,
          priority: priority,
          dueDate: dueDate,
          keyFeatures: keyFeaturesCommaSeparated,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Obtain screen dimensions for responsive design.
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;

    return CustomAppBar(
      title: translatedTitle,
      icon: Icons.article,
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.04,
          vertical: screenHeight * 0.02,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildLabel(translatedTitle, screenWidth),
            _buildTextField(
              controller: caseNameController,
              hint: translatedCaseNameHint,
              screenWidth: screenWidth,
            ),
            _buildLabel(translatedCaseDescription, screenWidth),
            _buildTextField(
              controller: caseDescriptionController,
              hint: translatedCaseDescHint,
              maxLines: 4,
              screenWidth: screenWidth,
            ),
            _buildLabel(translatedKeyFeaturesLabel, screenWidth),
            _buildKeyFeatures(screenWidth),
            _buildLabel(translatedPriorityLabel, screenWidth),
            _buildPrioritySelector(screenWidth),
            _buildLabel(translatedDueDateLabel, screenWidth),
            _buildDatePickerField(screenWidth),
            SizedBox(height: screenHeight * 0.03),
            _buildSubmitButton(screenWidth),
          ],
        ),
      ),
    );
  }

  Widget _buildLabel(String text, double screenWidth) {
    return Padding(
      padding: EdgeInsets.only(
          top: screenWidth * 0.04, bottom: screenWidth * 0.02),
      child: Text(text,
          style:
              TextStyle(fontWeight: FontWeight.w600, fontSize: screenWidth * 0.045)),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hint,
    int maxLines = 1,
    required double screenWidth,
  }) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(
        hintText: hint,
        filled: true,
        fillColor: Colors.grey.shade100,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide.none,
        ),
        contentPadding: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.03,
          vertical: screenWidth * 0.035,
        ),
      ),
    );
  }

  Widget _buildKeyFeatures(double screenWidth) {
    return Column(
      children: keyFeatureControllers.asMap().entries.map((entry) {
        int index = entry.key;
        return Padding(
          padding: EdgeInsets.only(bottom: screenWidth * 0.02),
          child: Row(
            children: [
              Expanded(
                child: _buildTextField(
                  controller: keyFeatureControllers[index],
                  hint: "Feature ${index + 1}",
                  screenWidth: screenWidth,
                ),
              ),
              SizedBox(width: screenWidth * 0.02),
              IconButton(
                icon: Icon(
                  index == keyFeatureControllers.length - 1
                      ? Icons.add
                      : Icons.remove,
                  color: Colors.blue,
                  size: screenWidth * 0.06,
                ),
                onPressed: () {
                  setState(() {
                    if (index == keyFeatureControllers.length - 1) {
                      keyFeatureControllers.add(TextEditingController());
                    } else {
                      keyFeatureControllers.removeAt(index);
                    }
                  });
                },
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildPrioritySelector(double screenWidth) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: Colors.grey.shade100,
      ),
      padding: EdgeInsets.all(screenWidth * 0.02),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [translatedLowText, translatedMediumText, translatedHighText]
            .map((priority) {
          return Expanded(
            child: GestureDetector(
              onTap: () {
                setState(() {
                  selectedPriority = priority;
                });
              },
              child: Container(
                alignment: Alignment.center,
                padding: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
                decoration: BoxDecoration(
                  color: selectedPriority == priority ? Colors.blue : Colors.transparent,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  priority,
                  style: TextStyle(
                    color: selectedPriority == priority ? Colors.white : Colors.black,
                    fontWeight: FontWeight.w500,
                    fontSize: screenWidth * 0.04,
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildDatePickerField(double screenWidth) {
    return GestureDetector(
      onTap: () => _selectDueDate(context),
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey.shade400),
          borderRadius: BorderRadius.circular(8),
          color: Colors.grey.shade100,
        ),
        padding: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.03,
          vertical: screenWidth * 0.04,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              dueDateController.text.isEmpty
                  ? translatedSelectDueDate
                  : dueDateController.text,
              style: TextStyle(
                color: dueDateController.text.isEmpty ? Colors.grey.shade600 : Colors.black,
                fontSize: screenWidth * 0.045,
              ),
            ),
            Icon(Icons.calendar_today, color: Colors.grey.shade600, size: screenWidth * 0.06),
          ],
        ),
      ),
    );
  }

  Widget _buildSubmitButton(double screenWidth) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: _submitCase,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.blue,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          padding: EdgeInsets.symmetric(vertical: screenWidth * 0.04),
        ),
        child: Text(
          translatedSubmitButtonText,
          style: TextStyle(color: Colors.white, fontSize: screenWidth * 0.045),
        ),
      ),
    );
  }
}
