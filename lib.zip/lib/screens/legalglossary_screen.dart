import 'package:flutter/material.dart';
import 'dart:math';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/custom_appbar.dart';
import '../data/legal_terms.dart'; // Import your legal glossary data

class LegalGlossaryScreen extends StatefulWidget {
  const LegalGlossaryScreen({super.key});

  @override
  _LegalGlossaryScreenState createState() => _LegalGlossaryScreenState();
}

class _LegalGlossaryScreenState extends State<LegalGlossaryScreen> {
  bool showAllTerms = false;
  String searchQuery = "";
  // Using a Set to store saved terms as Map<String, String>
  // Note: Maps are not inherently hashable so we use custom comparison.
  // Here, we use a List and ensure uniqueness based on the term.
  List<Map<String, String>> savedTerms = [];
  List<String> alphabet =
      List.generate(26, (index) => String.fromCharCode(65 + index));
  String wordOfTheDay = "";
  String wordDescription = "";
  String selectedLetter = "";

  @override
  void initState() {
    super.initState();
    _loadSavedData();
    _setWordOfTheDay();
  }

  Future<void> _loadSavedData() async {
    final prefs = await SharedPreferences.getInstance();
    List<String>? savedList = prefs.getStringList('savedTerms');
    setState(() {
      savedTerms = savedList.map((entry) {
        List<String> termData = entry.split('|'); // Stored as "term|description"
        return {"term": termData[0], "description": termData[1]};
      }).toList();
    });
    }

  Future<void> _saveTerms() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> savedList =
        savedTerms.map((termMap) => "${termMap['term']}|${termMap['description']}").toList();
    await prefs.setStringList('savedTerms', savedList);
  }

  void toggleSaved(Map<String, String> term) {
    setState(() {
      // Check if the term already exists based on the "term" field.
      int index = savedTerms.indexWhere((t) => t["term"] == term["term"]);
      if (index != -1) {
        savedTerms.removeAt(index);
      } else {
        savedTerms.add(term);
      }
      _saveTerms();
    });
  }

  void _setWordOfTheDay() {
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final random = Random(today.hashCode);
    final randomIndex = random.nextInt(legalGlossaryTerms.length);

    setState(() {
      wordOfTheDay = legalGlossaryTerms[randomIndex]["term"]!;
      wordDescription = legalGlossaryTerms[randomIndex]["description"]!;
    });
  }

  Widget buildAlphabetBar() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 10),
      child: Scrollbar(
        thumbVisibility: true,
        controller: ScrollController(),
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: alphabet.map((letter) {
              return GestureDetector(
                onTap: () {
                  setState(() {
                    selectedLetter = (selectedLetter == letter) ? "" : letter;
                  });
                },
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  margin: EdgeInsets.symmetric(horizontal: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: selectedLetter == letter
                        ? Colors.blueAccent
                        : Colors.transparent,
                  ),
                  child: Text(
                    letter,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: selectedLetter == letter ? Colors.white : Colors.black54,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;

    // Filter terms by search and selected letter
    List<Map<String, String>> filteredLegalTerms = legalGlossaryTerms.where((term) {
      bool matchesSearch = searchQuery.isEmpty ||
          term["term"]!.toLowerCase().contains(searchQuery);
      bool matchesLetter = selectedLetter.isEmpty ||
          term["term"]!.toUpperCase().startsWith(selectedLetter);
      return matchesSearch && matchesLetter;
    }).toList();

    // Decide how many terms to show based on showAllTerms
    List<Map<String, String>> displayedTerms = showAllTerms
        ? filteredLegalTerms
        : filteredLegalTerms.take(4).toList();

    return CustomAppBar(
      title: "Legal Glossary",
      icon: Icons.library_books,
      body: Scrollbar(
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Padding(
            padding: EdgeInsets.symmetric(
                horizontal: screenWidth * 0.05, vertical: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Search Bar
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 15),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(30),
                    boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 4)],
                  ),
                  child: TextField(
                    onChanged: (query) {
                      setState(() {
                        searchQuery = query.toLowerCase();
                      });
                    },
                    decoration: InputDecoration(
                      hintText: "Search legal terms",
                      prefixIcon:
                          Icon(Icons.search, color: Colors.blueAccent),
                      border: InputBorder.none,
                    ),
                  ),
                ),
                SizedBox(height: 20),

                // Word of the Day
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(15),
                  margin: EdgeInsets.symmetric(horizontal: 5),
                  decoration: BoxDecoration(
                    color: Colors.blue[50],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "WORD OF THE DAY",
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.blueAccent),
                      ),
                      SizedBox(height: 8),
                      Text(
                        wordOfTheDay,
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 5),
                      Text(
                        wordDescription,
                        style: TextStyle(fontSize: 15, color: Colors.black87),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 20),
                // Saved Terms Section
                Padding(
                      padding: EdgeInsets.only(left: 8), // ✅ Added left padding (15px) for "Saved Terms"
                      child: Text(
                        "Saved Terms",
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                    ),
                SizedBox(height: 10),
                savedTerms.isEmpty
                    ? Padding(
                        padding: EdgeInsets.only(left: 10),  // ✅ Added left padding (15px)
                        child: Text(
                          "No saved terms",
                          style: TextStyle(color: Colors.grey),
                        ),
                      )
                    : Column(
                        children: savedTerms.map((termMap) {
                          return Card(
                            child: ListTile(
                              title: Text(
                                termMap["term"]!,
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold),
                              ),
                              subtitle: Text(
                                termMap["description"]!,
                                style: TextStyle(color: Colors.black87),
                              ),
                              trailing: IconButton(
                                icon: Icon(Icons.bookmark,
                                    color: Colors.red),
                                onPressed: () =>
                                    toggleSaved(termMap),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                SizedBox(height: 20),

                // Alphabet Bar
                buildAlphabetBar(),
                SizedBox(height: 20),

                // Display filtered legal terms
                Column(
                  children: displayedTerms.map((term) {
                    return Card(
                      child: ListTile(
                        title: Text(
                          term["term"]!,
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(
                          term["description"]!,
                          style: TextStyle(color: Colors.black87),
                        ),
                        onTap: () {
                          // You can add additional onTap functionality if needed
                        },
                        trailing: IconButton(
                          icon: Icon(
                            savedTerms.any((t) =>
                                    t["term"] == term["term"])
                                ? Icons.bookmark
                                : Icons.bookmark_border,
                            color: savedTerms.any((t) =>
                                    t["term"] == term["term"])
                                ? Colors.red
                                : Colors.black54,
                          ),
                          onPressed: () => toggleSaved({
                            "term": term["term"]!,
                            "description": term["description"]!,
                          }),
                        ),
                      ),
                    );
                  }).toList(),
                ),

                // View All / Show Less button
                if (filteredLegalTerms.length > 4)
                  TextButton(
                    onPressed: () {
                      setState(() {
                        showAllTerms = !showAllTerms;
                      });
                    },
                    child: Text(
                      showAllTerms ? "Show Less ▲" : "View All ▼",
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.blueAccent),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
