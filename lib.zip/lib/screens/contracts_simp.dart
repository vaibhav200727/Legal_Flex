import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:provider/provider.dart';

// Import your custom app bar, language provider, and translation service.
import '../widgets/custom_appbar.dart';
import '../providers/language_provider.dart';
import '../services/translation_service.dart';

class ContractArticlesScreen extends StatefulWidget {
  const ContractArticlesScreen({super.key});

  @override
  _ContractArticlesScreenState createState() => _ContractArticlesScreenState();
}

class _ContractArticlesScreenState extends State<ContractArticlesScreen> {
  final FlutterTts flutterTts = FlutterTts();

  // Local data for contract articles (frontend only)
  final List<Map<String, String>> _articles = [
    {
      "title": "Section 2(a): Offer",
      "part": "Part II",
      "simplifiedText": "Defines the proposal made by one party to another to enter into a contract.",
      "exampleScenario": "A seller offers to sell a car to a buyer on specific terms.",
      "originalArticle": "Indian Contract Act, 1872, Section 2(a): Defines an offer or proposal."
    },
    {
      "title": "Section 2(b): Acceptance",
      "part": "Part II",
      "simplifiedText": "Establishes that the acceptance of an offer forms a binding contract.",
      "exampleScenario": "The buyer agrees to the offered terms and confirms the purchase of the car.",
      "originalArticle": "Indian Contract Act, 1872, Section 2(b): Defines acceptance of an offer."
    },
    {
      "title": "Section 10: Valid Contracts",
      "part": "Part II",
      "simplifiedText": "States that a contract is enforceable only if it is made with free consent, lawful consideration, and for a lawful object.",
      "exampleScenario": "Both parties willingly agree on all terms without coercion, ensuring the contract's validity.",
      "originalArticle": "Indian Contract Act, 1872, Section 10: Conditions for a valid contract."
    },
    {
      "title": "Section 11: Capacity to Contract",
      "part": "Part II",
      "simplifiedText": "Specifies that only persons who are legally competent can enter into a contract.",
      "exampleScenario": "A contract signed by a minor or an incapacitated person is deemed void.",
      "originalArticle": "Indian Contract Act, 1872, Section 11: Defines the capacity to contract."
    },
    {
      "title": "Section 23: Lawful Object",
      "part": "Part II",
      "simplifiedText": "Requires that the object of a contract must be lawful and not against public policy.",
      "exampleScenario": "A contract for an illegal activity, such as smuggling, is unenforceable.",
      "originalArticle": "Indian Contract Act, 1872, Section 23: Agreements with unlawful objects are void."
    },
    {
      "title": "Section 73: Compensation for Breach",
      "part": "Part II",
      "simplifiedText": "Provides for compensation in cases where a breach of contract causes loss or damage.",
      "exampleScenario": "If a party fails to deliver goods as agreed, the other party may claim damages.",
      "originalArticle": "Indian Contract Act, 1872, Section 73: Entitles a party to compensation for breach of contract."
    },
    {
      "title": "Section 74: Penalty for Breach",
      "part": "Part II",
      "simplifiedText": "Deals with penalty clauses in contracts and the consequences of a breach.",
      "exampleScenario": "A contract includes a penalty clause for late delivery, which is enforced if the delivery is delayed.",
      "originalArticle": "Indian Contract Act, 1872, Section 74: Specifies the penalty for breach of contract."
    }
  ];

  // Translated screen title and articles.
  String _translatedScreenTitle = "Contract Articles";
  List<Map<String, String>> _translatedArticles = [];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  /// Update translations for the screen title and all article fields.
  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLanguage = languageProvider.selectedLanguage;

    try {
      // Translate the screen title.
      _translatedScreenTitle = await TranslationService.translate(
        "Contract Articles",
        selectedLanguage,
      );

      // Translate each article's fields.
      List<Map<String, String>> newArticles = [];
      for (var article in _articles) {
        final tTitle = await TranslationService.translate(article['title']!, selectedLanguage);
        final tPart = await TranslationService.translate(article['part']!, selectedLanguage);
        final tSimplifiedText =
            await TranslationService.translate(article['simplifiedText']!, selectedLanguage);
        final tExampleScenario =
            await TranslationService.translate(article['exampleScenario']!, selectedLanguage);
        final tOriginalArticle =
            await TranslationService.translate(article['originalArticle']!, selectedLanguage);

        newArticles.add({
          "title": tTitle,
          "part": tPart,
          "simplifiedText": tSimplifiedText,
          "exampleScenario": tExampleScenario,
          "originalArticle": tOriginalArticle,
        });
      }

      if (mounted) {
        setState(() {
          _translatedArticles = newArticles;
        });
      }
    } catch (e) {
      debugPrint("❌ Translation error: $e");
    }
  }

  /// Text-to-speech functionality.
  void _speak(String text) async {
    await flutterTts.speak(text);
  }

  @override
  Widget build(BuildContext context) {
    return CustomAppBar(
      title: _translatedScreenTitle,
      icon: Icons.gavel,
      body: ListView.builder(
        padding: const EdgeInsets.all(12.0),
        itemCount: _translatedArticles.length,
        itemBuilder: (context, index) {
          final article = _translatedArticles[index];
          return Container(
            margin: const EdgeInsets.symmetric(vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.blue),
              borderRadius: BorderRadius.circular(8),
            ),
            child: ListTile(
              leading: const Icon(Icons.article, color: Colors.blue),
              title: Text(
                article["title"] ?? "",
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              trailing: const Icon(Icons.chevron_right, color: Colors.blue),
              onTap: () {
                _showArticleDialog(article);
              },
            ),
          );
        },
      ),
    );
  }

  /// Displays an AlertDialog with detailed article information.
  void _showArticleDialog(Map<String, String> article) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(article["title"] ?? ""),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildDialogSection("📌 Part", article["part"]),
                _buildDialogSection("📜 Simplified Text", article["simplifiedText"]),
                _buildDialogSection("💡 Example/Scenario", article["exampleScenario"]),
                _buildDialogSection("📖 Original Article", article["originalArticle"]),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: () => _speak(article["simplifiedText"] ?? ""),
                  icon: const Icon(Icons.volume_up),
                  label: const Text("Read Aloud"),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Close", style: TextStyle(color: Colors.blueAccent)),
            )
          ],
        );
      },
    );
  }

  /// Helper widget for formatting dialog sections.
  Widget _buildDialogSection(String title, String? content) {
    if (content == null || content.isEmpty) return const SizedBox();
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.blueAccent,
            ),
          ),
          const SizedBox(height: 5),
          Text(content, style: const TextStyle(fontSize: 14)),
        ],
      ),
    );
  }
}
