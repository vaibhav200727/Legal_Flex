import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:provider/provider.dart';
import '../widgets/custom_appbar.dart';
import '../providers/language_provider.dart';
import '../providers/save_provider.dart';
import '../services/translation_service.dart';

class EducationRightsScreen extends StatefulWidget {
  const EducationRightsScreen({super.key});

  @override
  _EducationRightsScreenState createState() => _EducationRightsScreenState();
}

class _EducationRightsScreenState extends State<EducationRightsScreen> {
  final FlutterTts flutterTts = FlutterTts();

  String headerText = "Know Your Rights";
  List<String> translatedTitles = educationRights.map((e) => e['title'] as String).toList();
  List<String> translatedDescriptions = educationRights.map((e) => e['description'] as String).toList();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLanguage = languageProvider.selectedLanguage;

    try {
      String newHeader = await TranslationService.translate("Know Your Rights", selectedLanguage);
      if (mounted) {
        setState(() {
          headerText = newHeader;
        });
      }
    } catch (e) {
      print("❌ Translation error for header: $e");
    }

    List<String> newTitles = [];
    List<String> newDescriptions = [];
    for (var item in educationRights) {
      try {
        String tTitle = await TranslationService.translate(item['title'], selectedLanguage);
        String tDesc = await TranslationService.translate(item['description'], selectedLanguage);
        newTitles.add(tTitle);
        newDescriptions.add(tDesc);
      } catch (e) {
        print("❌ Translation error for ${item['title']}: $e");
        newTitles.add(item['title']);
        newDescriptions.add(item['description']);
      }
    }
    if (mounted) {
      setState(() {
        translatedTitles = newTitles;
        translatedDescriptions = newDescriptions;
      });
    }
  }

  void _speak(String text) async {
    await flutterTts.speak(text);
  }

  // Toggle saved status using SaveProvider.
  void toggleSaveItem(BuildContext context, String item) {
    final saveProvider = Provider.of<SaveProvider>(context, listen: false);
    if (saveProvider.savedItems.contains(item)) {
      saveProvider.removeItem(item);
    } else {
      saveProvider.addItem(item);
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isSmallScreen = screenWidth < 600;
    final saveProvider = Provider.of<SaveProvider>(context);

    return CustomAppBar(
      title: "Know Your Rights",
      icon: Icons.school,
      body: Padding(
        padding: EdgeInsets.all(isSmallScreen ? 8.0 : 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            Text(
              headerText,
              style: TextStyle(fontSize: isSmallScreen ? 16 : 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: educationRights.length,
                itemBuilder: (context, index) {
                  final title = translatedTitles[index];
                  final description = translatedDescriptions[index];
                  final isSaved = saveProvider.savedItems.contains(title);
                  return Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    margin: EdgeInsets.symmetric(vertical: isSmallScreen ? 4 : 6),
                    child: Padding(
                      padding: EdgeInsets.all(isSmallScreen ? 8 : 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                educationRights[index]['icon'],
                                color: educationRights[index]['color'],
                                size: isSmallScreen ? 20 : 24,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  title,
                                  style: TextStyle(
                                    fontSize: isSmallScreen ? 14 : 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: Icon(Icons.volume_up, color: Colors.blue, size: isSmallScreen ? 22 : 26),
                                onPressed: () => _speak(description),
                              ),
                              IconButton(
                                icon: Icon(
                                  isSaved ? Icons.bookmark : Icons.bookmark_border,
                                  color: isSaved ? Colors.blue : Colors.grey,
                                  size: isSmallScreen ? 22 : 26,
                                ),
                                onPressed: () {
                                  toggleSaveItem(context, title);
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text(
                            description,
                            style: TextStyle(fontSize: isSmallScreen ? 15 : 20, color: Colors.grey),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

final List<Map<String, dynamic>> educationRights = [
  {"title": "Right to Education", "icon": Icons.menu_book, "color": Colors.blue, "description": "Every child has the right to free and compulsory education."},
  {"title": "Right to Non-Discrimination", "icon": Icons.equalizer, "color": Colors.green, "description": "No student should face discrimination in education."},
  {"title": "Right to Higher Education", "icon": Icons.school, "color": Colors.orange, "description": "Access to universities and vocational training should be fair."},
  {"title": "Right to Educational Resources", "icon": Icons.library_books, "color": Colors.red, "description": "Students should have access to books, libraries, and technology."},
  {"title": "Right to Special Education", "icon": Icons.accessibility, "color": Colors.purple, "description": "Education should be inclusive for students with disabilities."},
  {"title": "Right to Free School Meals", "icon": Icons.restaurant, "color": Colors.teal, "description": "Children should receive nutritious meals at school."},
  {"title": "Right to Protection Against Harassment", "icon": Icons.gavel, "color": Colors.cyan, "description": "Students should be safe from bullying and harassment."},
  {"title": "Right to Study in One’s Native Language", "icon": Icons.translate, "color": Colors.amber, "description": "Education should be available in local languages."},
  {"title": "Right to Quality Education", "icon": Icons.star, "color": Colors.brown, "description": "Education should meet high-quality learning standards."},
  {"title": "Right to Cultural and Moral Education", "icon": Icons.diversity_3, "color": Colors.indigo, "description": "Students should learn about diverse cultures and ethics."}
];
