import 'dart:math';
import 'package:flutter/material.dart';
import '../data/game1_data.dart';
import 'package:project/screens/factsydk_game.dart';

class FactOrFauxGame extends StatefulWidget {
  const FactOrFauxGame({super.key});

  @override
  State<FactOrFauxGame> createState() => _FactOrFauxGameState();
}

class _FactOrFauxGameState extends State<FactOrFauxGame> {
  List<Map<String, dynamic>> selectedQuestions = [];
  int score = 0;
  int streak = 0;
  int currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _loadRandomQuestions();
  }

  void _loadRandomQuestions() {
    selectedQuestions.clear();
    final shuffled = List<Map<String, dynamic>>.from(factOrFauxDatasetIndian)..shuffle();
    selectedQuestions = shuffled.take(10).toList();

    setState(() {
      score = 0;
      streak = 0;
      currentIndex = 0;
    });
  }

  List<Color> getGradientColors(int index) {
    final total = 50;
    final hue = (index * (360 / total)) % 360;
    final color1 = HSLColor.fromAHSL(1, hue, 0.7, 0.5).toColor();
    final color2 = HSLColor.fromAHSL(1, hue, 0.6, 0.6).toColor();
    return [color1, color2];
  }

  void _answer(bool userAnswer) {
    final currentQuestion = selectedQuestions[currentIndex];
    final bool isCorrect = currentQuestion['isFact'] == userAnswer;

    setState(() {
      if (isCorrect) {
        score += 50;
        streak += 1;
      } else {
        score -= 20;
        streak = 0;
      }

      if (currentIndex < selectedQuestions.length - 1) {
        currentIndex++;
      } else {
        _showScorecard();
      }
    });
  }

  void _showScorecard() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('🎉 Game Over'),
        content: Text(
          'Your final score is $score points.\nGreat job!',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 18),
        ),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          ElevatedButton.icon(
            icon: const Icon(Icons.refresh),
            label: const Text("Try Again"),
            onPressed: () {
              Navigator.pop(context);
              _loadRandomQuestions();
            },
          ),
          TextButton.icon(
            icon: const Icon(Icons.exit_to_app),
            label: const Text("Exit"),
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => const LegalGamesScreen()),
              );
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (selectedQuestions.isEmpty) return const SizedBox();

    final question = selectedQuestions[currentIndex];
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            // Score & Streak
            Padding(
              padding: EdgeInsets.symmetric(
                horizontal: screenWidth * 0.05,
                vertical: screenHeight * 0.02,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Score: $score",
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  Row(
                    children: [
                      const Icon(Icons.local_fire_department, color: Colors.red),
                      Text(" $streak Streak",
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
                    ],
                  ),
                ],
              ),
            ),

            // Question Card
            Expanded(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.07),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    gradient: LinearGradient(
                      colors: getGradientColors(currentIndex),
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  padding: EdgeInsets.symmetric(
                    horizontal: screenWidth * 0.06,
                    vertical: screenHeight * 0.04,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        question['icon'] ?? Icons.help_outline,
                        color: Colors.white,
                        size: screenWidth * 0.14,
                      ),
                      SizedBox(height: screenHeight * 0.03),
                      Expanded(
                        child: Center(
                          child: SingleChildScrollView(
                            child: Text(
                              question['statement'],
                              style: const TextStyle(
                                fontSize: 26,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            SizedBox(height: screenHeight * 0.02),

            // Fact or Faux Buttons
            Padding(
              padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.08),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  // ❌ Faux
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      shape: const CircleBorder(),
                      padding: EdgeInsets.all(screenWidth * 0.055),
                    ),
                    onPressed: () => _answer(false),
                    child: Icon(Icons.close, size: screenWidth * 0.07, color: Colors.white),
                  ),
                  // ✅ Fact
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      shape: const CircleBorder(),
                      padding: EdgeInsets.all(screenWidth * 0.055),
                    ),
                    onPressed: () => _answer(true),
                    child: Icon(Icons.check, size: screenWidth * 0.07, color: Colors.white),
                  ),
                ],
              ),
            ),
            SizedBox(height: screenHeight * 0.03),
          ],
        ),
      ),
    );
  }
}
