import 'package:flutter/material.dart';
import 'package:flutter_cached_pdfview/flutter_cached_pdfview.dart';
import 'package:url_launcher/url_launcher.dart';

class PdfPreviewScreen extends StatelessWidget {
  final String downloadUrl;
  final String fileName;

  const PdfPreviewScreen({
    super.key,
    required this.downloadUrl,
    required this.fileName,
  });

  Future<void> _downloadPdf(BuildContext context) async {
    final uri = Uri.parse(downloadUrl);
    try {
      final bool launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!launched) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Could not launch URL")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error launching URL: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(fileName),
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            tooltip: "Download PDF",
            onPressed: () => _downloadPdf(context),
          ),
        ],
      ),
      body: PDF().fromUrl(
        downloadUrl,
        placeholder: (progress) =>
            Center(child: Text("$progress % loaded")),
        errorWidget: (error) => Center(child: Text("Error: $error")),
      ),
    );
  }
}
