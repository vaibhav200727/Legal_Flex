import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:async';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';



import '../providers/theme_provider.dart';
import '../providers/language_provider.dart';
import '../services/translation_service.dart';

// Import your service screens
import 'package:project/screens/casetoact.dart';
import '../data/gov_schemes_data.dart';
import 'package:project/screens/elibrary_screen.dart';
import 'package:project/screens/adv_screen2.dart';
import 'package:project/screens/adv_screen1.dart';
import 'package:project/screens/adv_screen3.dart';
import 'package:project/screens/adv_screen4.dart';
import 'package:project/screens/adv_screen5.dart';
import 'package:project/screens/game1.dart';
import 'package:project/screens/commmunity_screen.dart';
import 'package:project/screens/whatif_screen.dart';
import 'package:project/screens/ayr_screen.dart';
import 'package:project/screens/factsydk_game.dart';
import 'package:project/screens/chatbot_screen.dart';
import 'package:project/screens/legaldoc_screen1.dart';
import 'package:project/screens/legalglossary_screen.dart';
import 'package:project/screens/ocr_screen.dart';
import 'simp1_screen.dart';
import 'package:project/screens/quiz_screen.dart';
import 'package:project/screens/faq_screen.dart';
import 'package:project/screens/features_screen.dart';

// Import the scheme detail screen (the screen to which the carousel will lead)
import 'package:project/screens/government_schemes_screen.dart';

import 'package:project/widgets/custom_appbar.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // Overlay for colorblind modes
  OverlayEntry? _overlayEntry;
  
  // =======================
  // SEARCH BAR (AT THE TOP)
  // =======================
  final TextEditingController _searchController = TextEditingController();
  List<Map<String, dynamic>> filteredPopularTopics = [];
  
  // MAIN FEATURES (displayed in four large boxes)
  final List<Map<String, dynamic>> mainFeatures = const [
    {'title': 'ActWise', 'icon': Icons.balance},
    {'title': 'AdvoConnect', 'icon': Icons.person},
    {'title': 'DocuLegis', 'icon': Icons.article},
    {'title': 'ScanLaw', 'icon': Icons.document_scanner},
  ];

  // POPULAR TOPICS (layman-oriented features)
  final List<Map<String, dynamic>> popularTopics = const [
    {'title': 'LawLite', 'icon': Icons.folder},
    {'title': 'Know Your Rights', 'icon': Icons.gavel},
    {'title': 'LexiLaw', 'icon': Icons.library_books},
    {'title': 'NyayVaani', 'icon': Icons.school},
    {'title': 'LawChat', 'icon': Icons.menu_book},
    {'title': 'NyayQueries', 'icon': Icons.help},
    {'title': 'LawFacts', 'icon': Icons.fact_check},
    {'title': 'LawScenarios', 'icon': Icons.quiz},
    {'title': 'LegiQuiz', 'icon': Icons.question_answer},
    {'title': 'NyayManch', 'icon': Icons.forum},
  ];

  // =======================
  // GOVERNMENT SCHEMES CAROUSEL
  // =======================
  final PageController _schemeController = PageController();
  late Timer _schemeTimer;
  int _currentSchemePage = 0;
  
  // Updated schemes with an image key (update image paths later)
  final List<Map<String, String>> governmentSchemes = [
    {
      'title': 'Scheme A',
      'description': 'Financial aid for law students',
      'image': 'assets/images/banner2.jpg',
    },
    {
      'title': 'Scheme B',
      'description': 'Subsidized resources for new lawyers',
      'image': 'assets/images/scheme_b.jpg',
    },
    {
      'title': 'Scheme C',
      'description': 'Free legal training programs',
      'image': 'assets/images/scheme_c.jpg',
    },
    // Add more schemes if needed
  ];
  
  // =======================
  // RECENTLY VIEWED FEATURES (LAST 4)
  // =======================
  List<Map<String, dynamic>> _recentlyViewed = [];
  
  // Translated static texts
  String translatedSearchHint = "Search features...";
  String selectedLanguage = "en";
  
  // Lawyer-oriented features translations
  String translatedActWise = "ActWise";
  String translatedKnowYourRights = "Know Your Rights";
  String translatedDocuLegis = "DocuLegis";
  String translatedLexiLaw = "LexiLaw";
  String translatedLawLite = "LawLite";
  String translatedAdvoConnect = "AdvoConnect";
  String translatedNyayVaani = "NyayVaani";
  String translatedLawChat = "LawChat";
  String translatedNyayQueries = "NyayQueries";
  String translatedLawFacts = "LawFacts";
  String translatedLawScenarios = "LawScenarios";
  String translatedScanLaw = "ScanLaw";
  String translatedLegiQuiz = "LegiQuiz";
  String translatedNyayManch = "NyayManch";

  // Helper set to identify layman-oriented features
  final Set<String> laymanFeatures = {
    "LawLite",
    "Know Your Rights",
    "LexiLaw",
    "NyayVaani",
    "LawChat",
    "NyayQueries",
    "LawFacts",
    "LawScenarios",
    "LegiQuiz",
    "NyayManch"
  };
  
  @override
  void initState() {
    super.initState();
    filteredPopularTopics = List.from(popularTopics);
    _startSchemeAutoSlide();
    
    Provider.of<LanguageProvider>(context, listen: false)
        .addListener(_updateTranslations);
    _updateTranslations();
  }
  
  @override
  void dispose() {
    _schemeTimer.cancel();
    _schemeController.dispose();
    _searchController.dispose();
    Provider.of<LanguageProvider>(context, listen: false)
        .removeListener(_updateTranslations);
    super.dispose();
  }
  
  // =======================
  // CAROUSEL AUTO-SLIDE
  // =======================
  void _startSchemeAutoSlide() {
    _schemeTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (_currentSchemePage < governmentSchemes.length - 1) {
        _currentSchemePage++;
      } else {
        _currentSchemePage = 0;
      }
      _schemeController.animateToPage(
        _currentSchemePage,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
      setState(() {});
    });
  }
  
  // =======================
  // COLORBLIND MODE DROPDOWN
  // =======================
  void _toggleDropdown(BuildContext context) {
    if (_overlayEntry != null) {
      _overlayEntry!.remove();
      _overlayEntry = null;
    } else {
      _overlayEntry = _createDropdown(context);
      Overlay.of(context).insert(_overlayEntry!);
    }
  }
  
  OverlayEntry _createDropdown(BuildContext context) {
    final RenderBox renderBox = context.findRenderObject() as RenderBox;
    final Offset offset = renderBox.localToGlobal(Offset.zero);
    return OverlayEntry(
      builder: (context) => Positioned(
        top: offset.dy + 50,
        right: 10,
        child: Material(
          elevation: 5,
          borderRadius: BorderRadius.circular(8),
          color: Theme.of(context).brightness == Brightness.dark
              ? Colors.grey[900]
              : Colors.white,
          child: Consumer<ThemeProvider1>(
            builder: (context, themeProvider, child) => Column(
              mainAxisSize: MainAxisSize.min,
              children: themeProvider.colorBlindFilters.keys.map((String mode) {
                return InkWell(
                  onTap: () {
                    themeProvider.setColorBlindMode(mode);
                    _toggleDropdown(context);
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 10,
                    ),
                    child: Text(
                      mode,
                      style: TextStyle(
                        fontSize: 16,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
      ),
    );
  }
  
  // =======================
  // FEATURE TAP HANDLER + RECENTLY VIEWED UPDATE
  // =======================
  Future<void> _handleFeatureTap(String title) async {
    // Add the feature to recently viewed list (if found)
    final feature = _getFeatureByTitle(title);
    if (feature != null) {
      setState(() {
        _recentlyViewed.removeWhere((f) => f['title'] == title);
        _recentlyViewed.insert(0, feature);
        if (_recentlyViewed.length > 4) {
          _recentlyViewed = _recentlyViewed.sublist(0, 4);
        }
      });
    }
    
    // Navigate based on the title
    switch (title) {
      case 'ActWise':
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const CaseToActScreen()));
        break;
      case 'Know Your Rights':
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const KnowYourRightsScreen()));
        break;
      case 'DocuLegis':
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const LegalDocsScreen()));
        break;
      case 'LexiLaw':
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => LegalGlossaryScreen()));
        break;
      case 'LawLite':
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const SimplificationScreen()));
        break;
      case 'AdvoConnect':
  SharedPreferences prefs = await SharedPreferences.getInstance();
  String? profession = prefs.getString('profession')?.trim().toLowerCase();
  String? uid = prefs.getString('uid');

  print('🧠 Profession: $profession');
  print('🔐 UID: $uid');

  if (profession != 'legal advisor') {
    // 🔁 Route normal users or unknown professions to user lawyer view
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => LawyersScreen()),
    );
    break;
  }

  // ✅ Valid Legal Advisor, now check registration
  try {
    DocumentSnapshot doc = await FirebaseFirestore.instance
        .collection('advoconnect_lawyers')
        .doc(uid)
        .get();

    bool isRegistered = doc.exists && (doc.data() as Map<String, dynamic>)['isRegistered'] == true;

    if (isRegistered) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => CallManagementScreen()),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => LawyerProfileScreen()),
      );
    }
  } catch (e) {
    print('❌ Error fetching registration info: $e');
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Error checking registration status.')),
    );
  }
  break;



      case 'NyayVaani':
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const LawLibraryScreen()));
        break;
      case 'LawChat':
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const ChatbotScreen()));
        break;
      case 'NyayQueries':
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const FAQScreen()));
        break;
      case 'LawFacts':
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const LegalGamesScreen()));
        break;
      case 'LawScenarios':
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const IndianConstitutionChatScreen()));
        break;
      case 'ScanLaw':
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const CaptureOrUploadImage(title: 'Scan or Upload Document')));
        break;
      case 'LegiQuiz':
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const QuizHomePage()));
        break;
      case 'NyayManch':
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const CommunityScreen()));
        break;
      default:
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Feature "$title" not implemented yet.')),
        );
    }
  }
  
  // Helper function to get a feature (from mainFeatures or popularTopics) by title
  Map<String, dynamic>? _getFeatureByTitle(String title) {
    for (var feature in mainFeatures) {
      if (feature['title'] == title) {
        return feature;
      }
    }
    for (var feature in popularTopics) {
      if (feature['title'] == title) {
        return feature;
      }
    }
    return null;
  }
  
  // =======================
  // SEARCH FILTER
  // =======================
  void _filterPopularTopics(String query) {
    setState(() {
      if (query.isEmpty) {
        filteredPopularTopics = List.from(popularTopics);
      } else {
        filteredPopularTopics = popularTopics
            .where((feature) =>
                feature['title']
                    .toString()
                    .toLowerCase()
                    .contains(query.toLowerCase()))
            .toList();
      }
    });
  }
  
  // =======================
  // TRANSLATIONS
  // =======================
  Future<void> _updateTranslations() async {
    final languageProvider =
        Provider.of<LanguageProvider>(context, listen: false);
    selectedLanguage = languageProvider.selectedLanguage;
    
    try {
      translatedSearchHint = await TranslationService.translate(
        "Search features...",
        selectedLanguage,
      );
      // Translations for lawyer-oriented features
      translatedActWise = await TranslationService.translate(
        "ActWise",
        selectedLanguage,
      );
      translatedKnowYourRights = await TranslationService.translate(
        "Know Your Rights",
        selectedLanguage,
      );
      translatedDocuLegis = await TranslationService.translate(
        "DocuLegis",
        selectedLanguage,
      );
      translatedLexiLaw = await TranslationService.translate(
        "LexiLaw",
        selectedLanguage,
      );
      translatedLawLite = await TranslationService.translate(
        "LawLite",
        selectedLanguage,
      );
      translatedAdvoConnect = await TranslationService.translate(
        "AdvoConnect",
        selectedLanguage,
      );
      translatedNyayVaani = await TranslationService.translate(
        "NyayVaani",
        selectedLanguage,
      );
      translatedLawChat = await TranslationService.translate(
        "LawChat",
        selectedLanguage,
      );
      translatedNyayQueries = await TranslationService.translate(
        "NyayQueries",
        selectedLanguage,
      );
      translatedLawFacts = await TranslationService.translate(
        "LawFacts",
        selectedLanguage,
      );
      translatedLawScenarios = await TranslationService.translate(
        "LawScenarios",
        selectedLanguage,
      );
      translatedScanLaw = await TranslationService.translate(
        "ScanLaw",
        selectedLanguage,
      );
      translatedLegiQuiz = await TranslationService.translate(
        "LegiQuiz",
        selectedLanguage,
      );
      translatedNyayManch = await TranslationService.translate(
        "NyayManch",
        selectedLanguage,
      );
      
      // Trigger UI update after translations change
      if (mounted) setState(() {});
    } catch (e) {
      debugPrint("❌ Translation Error in HomeScreen: $e");
    }
  }
  
  // Helper function to get translated title for layman-oriented features
  String getTranslatedLaymanFeature(String title) {
    switch (title) {
      case "LawLite":
        return translatedLawLite;
      case "Know Your Rights":
        return translatedKnowYourRights;
      case "LexiLaw":
        return translatedLexiLaw;
      case "NyayVaani":
        return translatedNyayVaani;
      case "LawChat":
        return translatedLawChat;
      case "NyayQueries":
        return translatedNyayQueries;
      case "LawFacts":
        return translatedLawFacts;
      case "LawScenarios":
        return translatedLawScenarios;
      case "LegiQuiz":
        return translatedLegiQuiz;
      case "NyayManch":
        return translatedNyayManch;
      default:
        return title;
    }
  }
  
  // =======================
  // BUILD
  // =======================
  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider1>(context, listen: true);
    final bool isDarkMode = themeProvider.isDarkMode;
    final double screenWidth = MediaQuery.of(context).size.width;
    
    return CustomAppBar(
      title: "NyaySetu",
      icon: Icons.groups,
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ColorFiltered(
          colorFilter: themeProvider.currentFilter,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // -----------------------
                // 1) SEARCH BAR AT THE TOP
                // -----------------------
                TextField(
                  controller: _searchController,
                  onChanged: _filterPopularTopics,
                  decoration: InputDecoration(
                    hintText: translatedSearchHint,
                    prefixIcon: Icon(
                      Icons.search,
                      color: isDarkMode ? Colors.white70 : Colors.grey,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                      borderSide: BorderSide.none,
                    ),
                    filled: true,
                    fillColor: isDarkMode ? Colors.grey[800] : Colors.grey[200],
                  ),
                  style: TextStyle(
                    color: isDarkMode ? Colors.white : Colors.black,
                  ),
                ),
                
                const SizedBox(height: 20),
                
                // -----------------------
                // 2) GOVERNMENT SCHEMES CAROUSEL (Full-width Images)
                // -----------------------
                Text(
                  "Government Schemes",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: isDarkMode ? Colors.white : Colors.black,
                  ),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  height: 250, // Adjust carousel height as needed
                  child: PageView.builder(
                    controller: _schemeController,
                    itemCount: governmentSchemes.length,
                    onPageChanged: (index) {
                      setState(() {
                        _currentSchemePage = index;
                      });
                    },
                    itemBuilder: (context, index) {
                      final scheme = governmentSchemes[index];
                      return _buildSchemeImageCard(
                        scheme: scheme,
                        isDarkMode: isDarkMode,
                      );
                    },
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    governmentSchemes.length,
                    (index) => Container(
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      width: _currentSchemePage == index ? 12 : 8,
                      height: _currentSchemePage == index ? 12 : 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _currentSchemePage == index ? Colors.blue : Colors.grey,
                      ),
                    ),
                  ),
                ),
                
                const SizedBox(height: 20),
                
                // -----------------------
                // 3) LAYMAN-ORIENTED FEATURES
                // -----------------------
                Text(
                  "Layman-Oriented Features",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: isDarkMode ? Colors.white : Colors.black,
                  ),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  height: 110,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: filteredPopularTopics.length,
                    itemBuilder: (context, index) {
                      final feature = filteredPopularTopics[index];
                      // Use the translated title for layman features
                      final displayTitle = laymanFeatures.contains(feature['title'])
                          ? getTranslatedLaymanFeature(feature['title'])
                          : feature['title'];
                      return _buildCircularTopicCard(
                        title: displayTitle,
                        icon: feature['icon'],
                        isDarkMode: isDarkMode,
                      );
                    },
                  ),
                ),
                
                const SizedBox(height: 20),
                
                // -----------------------
                // 4) LAWYER-ORIENTED FEATURES (Feature Boxes)
                // -----------------------
                Text(
                  "Lawyer-Oriented Features",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: isDarkMode ? Colors.white : Colors.black,
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: _buildFeatureBox(
                        title: translatedActWise,
                        subtitle: translatedActWise,
                        color: Colors.pinkAccent,
                        isDarkMode: isDarkMode,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _buildFeatureBox(
                        title: translatedAdvoConnect,
                        subtitle: translatedAdvoConnect,
                        color: Colors.greenAccent,
                        isDarkMode: isDarkMode,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: _buildFeatureBox(
                        title: translatedDocuLegis,
                        subtitle: translatedDocuLegis,
                        color: Colors.orangeAccent,
                        isDarkMode: isDarkMode,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _buildFeatureBox(
                        title: translatedScanLaw,
                        subtitle: translatedScanLaw,
                        color: Colors.blueAccent,
                        isDarkMode: isDarkMode,
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 20),
                
                Container(
                  width: screenWidth,
                  padding: const EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                    color: isDarkMode ? Colors.grey[800] : Colors.blue[50],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Explore the Constitution in a simplified way",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: isDarkMode ? Colors.white : Colors.black,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "Learn about the articles",
                        style: TextStyle(
                          fontSize: 16,
                          color: isDarkMode ? Colors.white70 : Colors.black54,
                        ),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () {
                          // Navigate to LawLite screen
                          _handleFeatureTap("LawLite");
                        },
                        child: const Text("Explore More"),
                      ),
                    ],
                  ),
                ),
                
                const SizedBox(height: 20),
                
                // -----------------------
                // 5) RECENTLY VIEWED FEATURES
                // -----------------------
                if (_recentlyViewed.isNotEmpty) ...[
                  Text(
                    "Recently Viewed",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: isDarkMode ? Colors.white : Colors.black,
                    ),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    height: 110,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: _recentlyViewed.length,
                      itemBuilder: (context, index) {
                        final feature = _recentlyViewed[index];
                        final displayTitle = laymanFeatures.contains(feature['title'])
                            ? getTranslatedLaymanFeature(feature['title'])
                            : feature['title'];
                        return _buildCircularTopicCard(
                          title: displayTitle,
                          icon: feature['icon'],
                          isDarkMode: isDarkMode,
                        );
                      },
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<String?> _getProfessionFromPreferences() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString('profession');
}

  
  // -----------------------
  // HELPER WIDGETS
  // -----------------------
  
  // Main feature boxes
  Widget _buildFeatureBox({
    required String title,
    required String subtitle,
    required Color color,
    required bool isDarkMode,
  }) {
    return Container(
      height: 100,
      decoration: BoxDecoration(
        color: isDarkMode ? Colors.grey[700] : color.withOpacity(0.3),
        borderRadius: BorderRadius.circular(12),
      ),
      padding: const EdgeInsets.all(12),
      child: InkWell(
        onTap: () => _handleFeatureTap(title),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              title,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: isDarkMode ? Colors.white : Colors.black87,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: TextStyle(
                color: isDarkMode ? Colors.white70 : Colors.black54,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  // Government Schemes image card for the carousel with a fixed image size of 500x300
  Widget _buildSchemeImageCard({
    required Map<String, String> scheme,
    required bool isDarkMode,
  }) {
    return GestureDetector(
      onTap: () => _handleSchemeTap(scheme),
      child: Container(
        width: double.infinity, // Stretches full width
        height: 100, // Fixed height
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
        ),
        clipBehavior: Clip.antiAlias,
        child: Image.asset(
          scheme['image'] ?? '',
          width: 500, // Intended width for the image
          height: 100, // Intended height for the image
          fit: BoxFit.fill, // Forces the image to fill the container
        ),
      ),
    );
  }
  
  // Navigate to the scheme details screen
  void _handleSchemeTap(Map<String, String> scheme) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SchemeDetailsPage(schemeIndex: 1,),
      ),
    );
  }
  
  // Circular card for Popular Topics and Recently Viewed
  Widget _buildCircularTopicCard({
    required String title,
    required IconData icon,
    required bool isDarkMode,
  }) {
    // Use MediaQuery to calculate a responsive width
    final double screenWidth = MediaQuery.of(context).size.width;
    final double cardWidth = screenWidth < 400 ? screenWidth * 0.4 : 140;
    
    return GestureDetector(
      onTap: () => _handleFeatureTap(title),
      child: Container(
        width: cardWidth,
        margin: const EdgeInsets.only(right: 12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 30,
              backgroundColor: isDarkMode ? Colors.grey[600] : Colors.blue[100],
              child: Icon(icon, size: 30, color: Colors.blue),
            ),
            const SizedBox(height: 8),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: isDarkMode ? Colors.white : Colors.black,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
