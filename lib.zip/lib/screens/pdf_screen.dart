import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:open_file/open_file.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';
import '../services/book_service.dart';

class PdfScreen extends StatefulWidget {
  final String pdfPath;
  final String title;
  final String downloadUrl;
  final String bookId;
  final int initialPage;

  const PdfScreen({
    super.key,
    required this.pdfPath,
    required this.title,
    required this.downloadUrl,
    required this.bookId,
    this.initialPage = 1,
  });

  @override
  State<PdfScreen> createState() => _PdfScreenState();
}

class _PdfScreenState extends State<PdfScreen> {
  final BookService _bookService = BookService();
  late PDFViewController pdfViewController;
  int currentPage = 1;
  int totalPages = 1;
  String? uid;

  @override
  void initState() {
    super.initState();
    currentPage = widget.initialPage;
    _loadUid();
  }

  Future<void> _loadUid() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      uid = prefs.getString('uid');
    });
    print("Loaded UID in PdfScreen: $uid");
  }

  /// Use WillPopScope to ensure reading progress is saved before the screen is popped.
  Future<bool> _onWillPop() async {
    if (uid != null) {
      await _bookService.saveReadingProgress(
        uid: uid!,
        bookId: widget.bookId,
        title: widget.title,
        fileUrl: widget.downloadUrl,
        lastPage: currentPage,
        totalPages: totalPages,
      );
    } else {
      print("Cannot save reading progress: UID is null");
    }
    return true;
  }

  Future<void> _downloadPdf(BuildContext context) async {
    final uri = Uri.parse(widget.downloadUrl);
    try {
      final bool launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!launched) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Could not launch URL")),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Downloading PDF...")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error launching URL: $e")),
      );
    }
  }

  Future<void> _openPdf(BuildContext context) async {
    final result = await OpenFile.open(widget.pdfPath);
    if (result.type != ResultType.done) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Could not open file")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context);
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            widget.title,
            style: TextStyle(fontSize: 18.sp),
          ),
          actions: [
            IconButton(
              icon: Icon(
                Icons.download,
                size: 24.sp,
              ),
              tooltip: "Download PDF",
              onPressed: () => _downloadPdf(context),
            ),
            IconButton(
              icon: Icon(
                Icons.open_in_new,
                size: 24.sp,
              ),
              tooltip: "Open PDF in External App",
              onPressed: () => _openPdf(context),
            ),
          ],
        ),
        body: PDFView(
          filePath: widget.pdfPath,
          enableSwipe: true,
          swipeHorizontal: false,
          autoSpacing: false,
          pageFling: false,
          defaultPage: widget.initialPage,
          onViewCreated: (PDFViewController controller) {
            pdfViewController = controller;
          },
          onRender: (int? pages) {
            if (pages != null) {
              setState(() {
                totalPages = pages;
              });
            }
          },
          onPageChanged: (int? page, int? total) {
            if (page != null) {
              setState(() {
                currentPage = page + 1;
              });
            }
            if (total != null) {
              setState(() {
                totalPages = total;
              });
            }
          },
        ),
     ),
);
}
}
