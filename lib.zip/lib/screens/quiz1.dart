import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'quizresult.dart';
import '../widgets/custom_appbar.dart';
import 'package:provider/provider.dart';
import '../providers/language_provider.dart';
import '../services/translation_service.dart';

class QuizScreen extends StatefulWidget {
  final String partName;
  const QuizScreen({super.key, required this.partName});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  List<dynamic> questions = [];
  // Translated questions will be stored here.
  List<dynamic> _translatedQuestions = [];
  
  int currentQuestionIndex = 0;
  int? selectedOptionIndex;
  int score = 0;
  static const int questionTime = 30;
  int remainingTime = questionTime;
  Timer? timer;
  bool isLoading = true;

  // Additional UI labels to translate.
  String _translatedNextQuestion = "Next Question";
  String _translatedSubmitQuiz = "Submit Quiz";
  String _translatedSelectOption = "Please select an option.";
  String _translatedSeconds = "sec";

  @override
  void initState() {
    super.initState();
    fetchQuizData();
  }

  // Fetch quiz data from Firestore based on the partName.
  Future<void> fetchQuizData() async {
    try {
      DocumentSnapshot doc = await FirebaseFirestore.instance
          .collection('quizzes')
          .doc(widget.partName)
          .get();
      if (doc.exists) {
        setState(() {
          questions = doc.get('questions');
          isLoading = false;
        });
        // Once the quiz data is fetched, translate it.
        await _translateQuizData();
        await _updateStaticLabels();
        startTimer();
      } else {
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      print("Error fetching quiz data: $e");
      setState(() {
        isLoading = false;
      });
    }
  }

  /// Translates each quiz question and its options.
  Future<void> _translateQuizData() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLang = languageProvider.selectedLanguage;
    List<dynamic> newTranslatedQuestions = [];
    try {
      for (var question in questions) {
        String tQuestionText = await TranslationService.translate(question['questionText'], selectedLang);
        List<dynamic> options = question['options'];
        List<dynamic> tOptions = [];
        for (var option in options) {
          String tOption = await TranslationService.translate(option, selectedLang);
          tOptions.add(tOption);
        }
        // Retain the correct option index.
        var newQuestion = {
          'questionText': tQuestionText,
          'options': tOptions,
          'correctOptionIndex': question['correctOptionIndex'],
        };
        newTranslatedQuestions.add(newQuestion);
      }
      setState(() {
        _translatedQuestions = newTranslatedQuestions;
      });
    } catch (e) {
      print("Error translating quiz data: $e");
    }
  }

  /// Update static UI labels (button texts, snack bar messages, timer label).
  Future<void> _updateStaticLabels() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLang = languageProvider.selectedLanguage;
    try {
      _translatedNextQuestion = await TranslationService.translate("Next Question", selectedLang);
      _translatedSubmitQuiz = await TranslationService.translate("Submit Quiz", selectedLang);
      _translatedSelectOption = await TranslationService.translate("Please select an option.", selectedLang);
      _translatedSeconds = await TranslationService.translate("sec", selectedLang);
      setState(() {}); // Update UI with new labels.
    } catch (e) {
      print("Error updating static labels: $e");
    }
  }

  void startTimer() {
    timer?.cancel();
    setState(() {
      remainingTime = questionTime;
    });
    timer = Timer.periodic(const Duration(seconds: 1), (Timer t) {
      if (remainingTime > 0) {
        setState(() {
          remainingTime--;
        });
      } else {
        timer?.cancel();
        processAnswer();
      }
    });
  }

  void processAnswer() {
    var currentQuestion = _translatedQuestions[currentQuestionIndex];
    if (selectedOptionIndex != null &&
        selectedOptionIndex == currentQuestion['correctOptionIndex']) {
      score++;
    }
    if (currentQuestionIndex < _translatedQuestions.length - 1) {
      setState(() {
        currentQuestionIndex++;
        selectedOptionIndex = null;
      });
      startTimer();
    } else {
      timer?.cancel();
      goToScoreCard();
    }
  }

  void goToScoreCard() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => ScoreCardScreen(
          score: score,
          total: _translatedQuestions.length,
        ),
      ),
    );
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    // Calculate responsive font sizes.
    final double questionFontSize = screenWidth * 0.05;
    final double optionFontSize = screenWidth * 0.045;
    final double timerFontSize = screenWidth * 0.04;

    // Determine title for the custom app bar.
    final String appBarTitle = _translatedQuestions.isNotEmpty
        ? 'Question ${currentQuestionIndex + 1} / ${_translatedQuestions.length}'
        : widget.partName;

    return CustomAppBar(
      title: appBarTitle,
      icon: Icons.language,
      body: Scrollbar(
        thumbVisibility: true,
        child: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.04,
            vertical: screenHeight * 0.03,
          ),
          child: (isLoading || _translatedQuestions.isEmpty)
              ? const Center(child: CircularProgressIndicator())
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Display translated question text.
                    Text(
                      _translatedQuestions[currentQuestionIndex]['questionText'],
                      style: TextStyle(
                        fontSize: questionFontSize,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: screenHeight * 0.02),
                    // Timer with clock icon.
                    Row(
                      children: [
                        const Icon(Icons.access_time, color: Colors.redAccent),
                        SizedBox(width: screenWidth * 0.015),
                        Text(
                          "$remainingTime $_translatedSeconds",
                          style: TextStyle(
                            color: Colors.redAccent,
                            fontWeight: FontWeight.bold,
                            fontSize: timerFontSize,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: screenHeight * 0.03),
                    // Options list.
                    Column(
                      children: List.generate(
                        _translatedQuestions[currentQuestionIndex]['options'].length,
                        (index) {
                          final optionText = _translatedQuestions[currentQuestionIndex]['options'][index];
                          bool isSelected = selectedOptionIndex == index;
                          return _buildOptionCard(
                            optionText: optionText,
                            isSelected: isSelected,
                            onTap: () {
                              setState(() {
                                selectedOptionIndex = index;
                              });
                            },
                            screenWidth: screenWidth,
                            optionFontSize: optionFontSize,
                          );
                        },
                      ),
                    ),
                    const Spacer(),
                    // Bottom button: translated "Next Question" or "Submit Quiz".
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              if (selectedOptionIndex == null) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(_translatedSelectOption),
                                  ),
                                );
                                return;
                              }
                              timer?.cancel();
                              processAnswer();
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.teal,
                              padding: EdgeInsets.symmetric(
                                vertical: screenHeight * 0.02,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: Text(
                              (currentQuestionIndex < _translatedQuestions.length - 1)
                                  ? _translatedNextQuestion
                                  : _translatedSubmitQuiz,
                              style: TextStyle(fontSize: optionFontSize, color: Colors.white),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildOptionCard({
    required String optionText,
    required bool isSelected,
    required VoidCallback onTap,
    required double screenWidth,
    required double optionFontSize,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        margin: EdgeInsets.only(bottom: screenWidth * 0.03),
        padding: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.04,
          vertical: screenWidth * 0.05,
        ),
        decoration: BoxDecoration(
          color: isSelected ? Colors.teal.shade100 : Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isSelected ? Colors.teal : Colors.grey.shade300,
            width: isSelected ? 2 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade200,
              blurRadius: 4,
              offset: const Offset(0, 2),
            )
          ],
        ),
        child: Text(
          optionText,
          style: TextStyle(
            fontSize: optionFontSize,
            color: isSelected ? Colors.teal.shade900 : Colors.black87,
          ),
        ),
      ),
    );
  }
}
