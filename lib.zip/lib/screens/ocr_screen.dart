import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:open_file/open_file.dart';
import 'package:file_picker/file_picker.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:provider/provider.dart';

// Import custom app bar widget and translation service (assumed to be implemented)
import '../widgets/custom_appbar.dart';
import '../providers/language_provider.dart';
import '../services/translation_service.dart';

/// Global list to store generated PDF file paths
List<String> generatedPdfPaths = [];

class CaptureOrUploadImage extends StatefulWidget {
  final String title;
  const CaptureOrUploadImage({super.key, required this.title});

  @override
  State<CaptureOrUploadImage> createState() => _CaptureOrUploadImageState();
}

class _CaptureOrUploadImageState extends State<CaptureOrUploadImage> {
  // For image files (from camera or gallery)
  File? _importedImage;
  // For non-image files (PDF, DOC, DOCX)
  String? _uploadedFilePath;
  // Indicates if the current file is an image
  bool _isImage = false;
  String _selectedSegment = 'Camera';
  String? _extractedText; // Holds extracted text to display

  // Translated title for the app bar
  String translatedTitle = '';

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Update the translated title using a language provider and translation service.
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLanguage = languageProvider.selectedLanguage;
    TranslationService.translate(widget.title, selectedLanguage).then((translated) {
      setState(() {
        translatedTitle = translated;
      });
    }).catchError((e) {
      print("Translation error: $e");
      setState(() {
        translatedTitle = widget.title;
      });
    });
  }

  // "Import from Gallery" for Camera segment
  Future<void> _importImageFromGallery() async {
    final picker = ImagePicker();
    final XFile? imageFile =
        await picker.pickImage(source: ImageSource.gallery);
    if (imageFile != null) {
      setState(() {
        _importedImage = File(imageFile.path);
        _isImage = true;
        _uploadedFilePath = null;
        _extractedText = null;
      });
    }
  }

  // Upload document for Upload segment
  Future<void> _uploadDocument() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx'],
    );
    if (result != null && result.files.isNotEmpty) {
      final filePath = result.files.single.path;
      if (filePath != null) {
        final File uploadedFile = File(filePath);
        String ext = filePath.split('.').last.toLowerCase();
        if (ext == 'pdf') {
          final outputDir = await getTemporaryDirectory();
          final newPath =
              '${outputDir.path}/uploaded_pdf_${DateTime.now().millisecondsSinceEpoch}.pdf';
          await uploadedFile.copy(newPath);
          generatedPdfPaths.add(newPath);
          ScaffoldMessenger.of(context)
              .showSnackBar(SnackBar(content: Text('PDF uploaded: $newPath')));
          setState(() {
            _uploadedFilePath = newPath;
            _isImage = false;
            _importedImage = null;
            _extractedText = null;
          });
        } else if (ext == 'doc' || ext == 'docx') {
          final outputDir = await getTemporaryDirectory();
          final newPath =
              '${outputDir.path}/uploaded_word_${DateTime.now().millisecondsSinceEpoch}.$ext';
          await uploadedFile.copy(newPath);
          generatedPdfPaths.add(newPath);
          ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Word document uploaded: $newPath')));
          setState(() {
            _uploadedFilePath = newPath;
            _isImage = false;
            _importedImage = null;
            _extractedText = null;
          });
        } else {
          // For images, generate a PDF from the image.
          final pdf = pw.Document();
          final imageData = await uploadedFile.readAsBytes();
          final pdfImage = pw.MemoryImage(imageData);
          pdf.addPage(
            pw.Page(
              build: (pw.Context context) {
                return pw.Center(child: pw.Image(pdfImage));
              },
            ),
          );
          final outputDir = await getTemporaryDirectory();
          final pdfFile = File(
              '${outputDir.path}/uploaded_document_${DateTime.now().millisecondsSinceEpoch}.pdf');
          await pdfFile.writeAsBytes(await pdf.save());
          generatedPdfPaths.add(pdfFile.path);
          ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('PDF generated at: ${pdfFile.path}')));
          setState(() {
            _importedImage = uploadedFile;
            _isImage = true;
            _uploadedFilePath = null;
            _extractedText = null;
          });
        }
      }
    }
  }

  Future<void> summarizeAndExplainText(String extractedText) async {
    final String apiKey = dotenv.env['GEMINI_API_KEY'] ?? '';
    if (apiKey.isEmpty) {
      setState(() {
        _extractedText = "API Key is missing. Check your .env file.";
      });
      return;
    }
    String apiUrl =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$apiKey";

    setState(() {
      _extractedText = "Summarizing and simplifying the content... Please wait.";
    });

    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "contents": [
          {
            "parts": [
              {
                "text":
                    "Summarize and explain this legal text in simple terms for a layman. Give what it is ?, why you might need it, what is says, key parts explained, important notes and the summary give all of these explicitly. Also directly start the output dont write any preceeding text also dont bold anything or header. Give the Summary first. Also add a new line after the heading and content of each section eg- after summary leave a line and then give the summary  :\n\n$extractedText"
              }
            ]
          }
        ]
      }),
    );

    print("API Response Code: ${response.statusCode}");
    print("API Response Raw: ${response.body}");

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      setState(() {
        _extractedText = data["candidates"][0]["content"]["parts"][0]["text"];
      });
    } else {
      setState(() {
        _extractedText = "Error generating summary. API Response: ${response.body}";
      });
    }
  }

  // Extract text from current file (image using MLKit or PDF/Word)
  Future<void> _extractTextFromImage() async {
    try {
      if (_selectedSegment == 'Camera' && _isImage && _importedImage != null) {
        final inputImage = InputImage.fromFile(_importedImage!);
        final textRecognizer =
            TextRecognizer(script: TextRecognitionScript.latin);
        final RecognizedText recognizedText =
            await textRecognizer.processImage(inputImage);
        await textRecognizer.close();

        setState(() {
          _extractedText = recognizedText.text;
        });

        // Summarize and explain the extracted text
        await summarizeAndExplainText(_extractedText!);
      } else if (!_isImage && _uploadedFilePath != null) {
        String ext = _uploadedFilePath!.split('.').last.toLowerCase();
        if (ext == 'pdf') {
          await _extractTextFromPdf();
        } else if (ext == 'doc' || ext == 'docx') {
          await _extractTextFromWord();
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Text extraction is not supported for this document type.')),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No file selected for text extraction.')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error extracting text: $e')),
      );
    }
  }

  Future<void> _extractTextFromPdf() async {
    try {
      final bytes = File(_uploadedFilePath!).readAsBytesSync();
      final PdfDocument document = PdfDocument(inputBytes: bytes);
      final String text = PdfTextExtractor(document).extractText();
      document.dispose();

      setState(() {
        _extractedText = text;
      });

      // Call AI to summarize and simplify PDF text
      await summarizeAndExplainText(_extractedText!);
    } catch (e) {
      setState(() {
        _extractedText = "Error extracting text from PDF: $e";
      });
    }
  }

  Future<void> _extractTextFromWord() async {
    try {
      String text = await File(_uploadedFilePath!).readAsString();
      setState(() {
        _extractedText = text;
      });
    } catch (e) {
      setState(() {
        _extractedText = "Error extracting text from Word document: $e";
      });
    }
  }

  // Generate PDF from current image (Camera segment)
  Future<void> _makePdfFromCameraImage() async {
    if (_importedImage == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('No image available to create PDF.')));
      return;
    }
    final pdf = pw.Document();
    final imageData = await _importedImage!.readAsBytes();
    final pdfImage = pw.MemoryImage(imageData);
    pdf.addPage(
      pw.Page(
        build: (pw.Context context) {
          return pw.Center(child: pw.Image(pdfImage));
        },
      ),
    );
    final outputDir = await getTemporaryDirectory();
    final pdfFile = File(
        '${outputDir.path}/camera_document_${DateTime.now().millisecondsSinceEpoch}.pdf');
    await pdfFile.writeAsBytes(await pdf.save());
    generatedPdfPaths.add(pdfFile.path);
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text('PDF generated at: ${pdfFile.path}')));
  }

  // Helper to build top segmented control buttons
  Widget _buildSegmentButton({
    required String text,
    required Color backgroundColor,
    required Color textColor,
  }) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedSegment = text;
          _importedImage = null;
          _uploadedFilePath = null;
          _extractedText = null;
        });
      },
      child: Container(
        height: 40,
        decoration: BoxDecoration(
          color: backgroundColor,
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(
          child: Text(text, style: TextStyle(fontSize: 16, color: textColor)),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;

    // Top preview area: shows the image/file info or a default asset.
    Widget topPreview;
    if (_importedImage != null) {
      topPreview = Image.file(
        _importedImage!,
        fit: BoxFit.cover,
        height: 300,
        width: double.infinity,
      );
    } else if (_uploadedFilePath != null) {
      topPreview = Container(
        height: 300,
        width: double.infinity,
        color: Colors.grey.shade200,
        child: Center(
          child: Text(
            _uploadedFilePath!.split('/').last,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
      );
    } else {
      topPreview = Image.asset(
        'assets/images/img9.jpg',
        fit: BoxFit.cover,
        height: 300,
        width: double.infinity,
      );
    }

    // Extracted text preview container
    Widget extractedTextPreview = Container(
      color: Colors.white,
      padding: const EdgeInsets.all(8.0),
      child: _extractedText != null
          ? SingleChildScrollView(
              child: Text(
                _extractedText!,
                style: const TextStyle(fontSize: 16, color: Colors.black),
              ),
            )
          : const Center(
              child: Text(
                'Preview of the text you captured',
                style: TextStyle(fontSize: 16, color: Colors.black),
              ),
            ),
    );

    return CustomAppBar(
      title: translatedTitle.isNotEmpty ? translatedTitle : widget.title,
      icon: Icons.camera_alt,
      body: Scrollbar(
        thumbVisibility: true,
        thickness: 8.0,
        radius: const Radius.circular(10),
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.05,
            vertical: 20,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Download button placed at the top-right of the content.
              Align(
                alignment: Alignment.topRight,
                child: IconButton(
                  icon: const Icon(Icons.download_rounded),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const PdfDownloadsScreen()),
                    );
                  },
                ),
              ),
              // Segmented control row
              Row(
                children: [
                  Expanded(
                    child: _buildSegmentButton(
                      text: 'Camera',
                      backgroundColor: _selectedSegment == 'Camera'
                          ? Colors.blue.shade100
                          : Colors.grey.shade300,
                      textColor: _selectedSegment == 'Camera'
                          ? Colors.blue
                          : Colors.black,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: _buildSegmentButton(
                      text: 'Upload',
                      backgroundColor: _selectedSegment == 'Upload'
                          ? Colors.blue.shade100
                          : Colors.grey.shade300,
                      textColor: _selectedSegment == 'Upload'
                          ? Colors.blue
                          : Colors.black,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // Top preview area
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: topPreview,
              ),
              const SizedBox(height: 16),
              // Buttons based on selected segment
              if (_selectedSegment == 'Camera') ...[
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () async {
                          final capturedImage = await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const TakePhotoScreen(),
                            ),
                          );
                          if (capturedImage != null && capturedImage is File) {
                            setState(() {
                              _importedImage = capturedImage;
                              _isImage = true;
                            });
                          }
                        },
                        icon: const Icon(Icons.camera_alt, color: Colors.white),
                        label: const Text('Take Photo',
                            style: TextStyle(color: Colors.white)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          shadowColor: Colors.blue,
                          elevation: 6,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          minimumSize: const Size(0, 50),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _importImageFromGallery,
                        icon: const Icon(Icons.photo_library, color: Colors.white),
                        label: const Text('Import from Gallery',
                            style: TextStyle(color: Colors.white)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          shadowColor: Colors.blue,
                          elevation: 6,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          minimumSize: const Size(0, 50),
                        ),
                      ),
                    ),
                  ],
                ),
              ] else if (_selectedSegment == 'Upload') ...[
                ElevatedButton.icon(
                  onPressed: _uploadDocument,
                  icon: const Icon(Icons.upload_file, color: Colors.white),
                  label: const Text('Upload Document',
                      style: TextStyle(color: Colors.white)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    shadowColor: Colors.blue,
                    elevation: 6,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    minimumSize: const Size.fromHeight(50),
                  ),
                ),
              ],
              const SizedBox(height: 16),
              // "Extract Text" button
              ElevatedButton(
                onPressed: _extractTextFromImage,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  shadowColor: Colors.blue,
                  elevation: 6,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  minimumSize: const Size.fromHeight(50),
                ),
                child: const Text(
                  'Extract Text',
                  style: TextStyle(fontSize: 16, color: Colors.white),
                ),
              ),
              const SizedBox(height: 16),
              // Extracted text preview container
              Container(
                height: 200,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.white,
                ),
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(8.0),
                  child: extractedTextPreview,
                ),
              ),
              // Only for Camera: instruction and "Make PDF" button
              if (_selectedSegment == 'Camera') ...[
                const SizedBox(height: 16),
                const Text(
                  "Press the PDF button below to make PDF",
                  style: TextStyle(fontSize: 14, color: Colors.black),
                ),
                const SizedBox(height: 8),
                ElevatedButton.icon(
                  onPressed: _makePdfFromCameraImage,
                  icon: const Icon(Icons.picture_as_pdf, color: Colors.white),
                  label: const Text('Make PDF',
                      style: TextStyle(color: Colors.white)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    shadowColor: Colors.green,
                    elevation: 6,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    minimumSize: const Size.fromHeight(50),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class TakePhotoScreen extends StatefulWidget {
  const TakePhotoScreen({super.key});

  @override
  State<TakePhotoScreen> createState() => _TakePhotoScreenState();
}

class _TakePhotoScreenState extends State<TakePhotoScreen> {
  File? _capturedImage;
  String translatedTitle = "Photo Scanner";

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLanguage = languageProvider.selectedLanguage;
    TranslationService.translate("Photo Scanner", selectedLanguage).then((translated) {
      setState(() {
        translatedTitle = translated;
      });
    }).catchError((e) {
      print("Translation error: $e");
    });
  }

  // Capture a photo and generate a PDF, then return the image to main screen.
  Future<void> captureAndGeneratePDF() async {
    final picker = ImagePicker();
    final XFile? imageFile =
        await picker.pickImage(source: ImageSource.camera);
    if (imageFile != null) {
      _capturedImage = File(imageFile.path);
      final pdf = pw.Document();
      final imageData = await _capturedImage!.readAsBytes();
      final pdfImage = pw.MemoryImage(imageData);
      pdf.addPage(
        pw.Page(
          build: (pw.Context context) {
            return pw.Center(child: pw.Image(pdfImage));
          },
        ),
      );
      final outputDir = await getTemporaryDirectory();
      final pdfFile = File(
          '${outputDir.path}/captured_image_${DateTime.now().millisecondsSinceEpoch}.pdf');
      await pdfFile.writeAsBytes(await pdf.save());
      generatedPdfPaths.add(pdfFile.path);
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('PDF generated at: ${pdfFile.path}')));
      // Return the captured image to the main screen.
      Navigator.pop(context, _capturedImage);
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    return CustomAppBar(
      title: translatedTitle,
      icon: Icons.camera_alt,
      body: Scrollbar(
        thumbVisibility: true,
        thickness: 8.0,
        radius: const Radius.circular(10),
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.05,
            vertical: 20,
          ),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _capturedImage != null
                    ? Container(
                        width: 300,
                        height: 400,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          image: DecorationImage(
                            image: FileImage(_capturedImage!),
                            fit: BoxFit.cover,
                          ),
                        ),
                      )
                    : Container(
                        width: 300,
                        height: 400,
                        decoration: BoxDecoration(
                          color: Colors.black12,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Colors.blue, width: 2),
                        ),
                        child: const Center(
                          child: Text(
                            'Camera / Scanning View',
                            style: TextStyle(fontSize: 18, color: Colors.blue),
                          ),
                        ),
                      ),
                const SizedBox(height: 24),
                ElevatedButton.icon(
                  onPressed: captureAndGeneratePDF,
                  icon: const Icon(Icons.camera_alt, color: Colors.white),
                  label: const Text('Capture & Generate PDF',
                      style: TextStyle(color: Colors.white)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    shadowColor: Colors.blue,
                    elevation: 6,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    minimumSize: const Size(200, 40),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class PdfDownloadsScreen extends StatelessWidget {
  const PdfDownloadsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    return CustomAppBar(
      title: "Downloaded PDFs",
      icon: Icons.picture_as_pdf,
      body: generatedPdfPaths.isNotEmpty
          ? ListView.builder(
              padding: EdgeInsets.symmetric(
                  horizontal: screenWidth * 0.05, vertical: 20),
              itemCount: generatedPdfPaths.length,
              itemBuilder: (context, index) {
                final path = generatedPdfPaths[index];
                final fileName = path.split('/').last;
                return ListTile(
                  leading: const Icon(Icons.picture_as_pdf),
                  title: Text(fileName),
                  subtitle: Text(path),
                  trailing: IconButton(
                    icon: const Icon(Icons.open_in_new),
                    onPressed: () async {
                      await OpenFile.open(path);
                    },
                  ),
                );
              },
            )
          : const Center(
              child: Text(
                'No PDFs generated yet.',
                style: TextStyle(fontSize: 16),
              ),
            ),
    );
  }
}
