import 'package:flutter/material.dart';
import 'package:project/auth/profile_upload.dart';
import 'package:firebase_auth/firebase_auth.dart';

class CompleteProfilePage extends StatefulWidget {
  const CompleteProfilePage({super.key});

  @override
  _CompleteProfilePageState createState() => _CompleteProfilePageState();
}

class _CompleteProfilePageState extends State<CompleteProfilePage> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _birthdayController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();

  String? _selectedProfession;
  String? _selectedGender;

  // Inline error messages for each field
  String? _nameError;
  String? _genderError;
  String? _birthdayError;
  String? _phoneError;
  String? _addressError;
  String? _professionError;

  bool _isLoading = false;

  void _validateAndSubmit() async {
    setState(() {
      _nameError = null;
      _genderError = null;
      _birthdayError = null;
      _phoneError = null;
      _addressError = null;
      _professionError = null;
      _isLoading = true;
    });

    if (_nameController.text.trim().isEmpty) {
      _nameError = 'Name cannot be empty';
    }
    if (_selectedGender == null) {
      _genderError = 'Please select your gender';
    }
    if (_birthdayController.text.isEmpty) {
      _birthdayError = 'Please select your birthday';
    }
    if (!_phoneController.text.trim().contains(RegExp(r'^\d{10}$'))) {
      _phoneError = 'Enter a valid 10-digit Indian phone number';
    }
    if (_addressController.text.trim().isEmpty) {
      _addressError = 'Address cannot be empty';
    }
    if (_selectedProfession == null) {
      _professionError = 'Please select a profession';
    }

    setState(() {}); // Update UI with inline errors

    if (_nameError != null ||
        _genderError != null ||
        _birthdayError != null ||
        _phoneError != null ||
        _addressError != null ||
        _professionError != null) {
      setState(() {
        _isLoading = false;
      });
      return;
    }

    await ProfileUploadService.uploadProfile(
      name: _nameController.text.trim(),
      gender: _selectedGender!,
      birthday: DateTime.parse(_birthdayController.text.split('/').reversed.join('-')),
      phoneNumber: _phoneController.text.trim(),
      address: _addressController.text.trim(),
      profession: _selectedProfession!,
      context: context,
    );

    // After profile is uploaded, send OTP separately
    await ProfileUploadService.sendOTP(
      phoneNumber: _phoneController.text.trim(),
      uid: FirebaseAuth.instance.currentUser!.uid,
      context: context,
    );

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _selectBirthday(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime(2000),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        _birthdayController.text =
            "${picked.day.toString().padLeft(2, '0')}/${picked.month.toString().padLeft(2, '0')}/${picked.year}";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final bool isSmallScreen = size.width < 400;
    final double fieldWidth = size.width * (isSmallScreen ? 0.95 : 0.8);
    final double buttonHeight = isSmallScreen ? 50 : 55;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: size.width * 0.05),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Back Button
                Align(
                  alignment: Alignment.centerLeft,
                  child: IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(Icons.arrow_back, size: 24, color: Colors.grey),
                  ),
                ),
                const SizedBox(height: 20),

                // Title
                const Text(
                  'Complete Profile',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),

                // Subtitle
                const Text(
                  'Make sure your details are accurate',
                  style: TextStyle(color: Colors.grey, fontSize: 14),
                ),
                const SizedBox(height: 30),

                // Name Field
                SizedBox(
                  width: fieldWidth,
                  child: TextField(
                    controller: _nameController,
                    decoration: InputDecoration(
                      labelText: 'Name',
                      errorText: _nameError,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(25),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // Gender Dropdown
                SizedBox(
                  width: fieldWidth,
                  child: DropdownButtonFormField<String>(
                    value: _selectedGender,
                    onChanged: (value) {
                      setState(() {
                        _selectedGender = value;
                      });
                    },
                    items: const [
                      DropdownMenuItem(value: 'Male', child: Text('Male')),
                      DropdownMenuItem(value: 'Female', child: Text('Female')),
                      DropdownMenuItem(value: 'Other', child: Text('Other')),
                    ],
                    decoration: InputDecoration(
                      labelText: 'Gender',
                      errorText: _genderError,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(25),
                      ),
                    ),
                    isExpanded: true,
                  ),
                ),
                const SizedBox(height: 20),

                // Birthday Picker
                SizedBox(
                  width: fieldWidth,
                  child: TextField(
                    controller: _birthdayController,
                    readOnly: true,
                    onTap: () => _selectBirthday(context),
                    decoration: InputDecoration(
                      labelText: 'Birthday',
                      errorText: _birthdayError,
                      suffixIcon: const Icon(Icons.calendar_today, color: Colors.grey),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(25),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // Phone Number Field
                SizedBox(
                  width: fieldWidth,
                  child: TextField(
                    controller: _phoneController,
                    keyboardType: TextInputType.phone,
                    decoration: InputDecoration(
                      prefixText: '+91 ',
                      labelText: 'Phone Number',
                      errorText: _phoneError,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(25),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // Address Field
                SizedBox(
                  width: fieldWidth,
                  child: TextField(
                    controller: _addressController,
                    maxLines: 2,
                    decoration: InputDecoration(
                      labelText: 'Address',
                      errorText: _addressError,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(25),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // Profession Dropdown
                SizedBox(
                  width: fieldWidth,
                  child: DropdownButtonFormField<String>(
                    value: _selectedProfession,
                    onChanged: (value) {
                      setState(() {
                        _selectedProfession = value;
                      });
                    },
                    items: const [
                      DropdownMenuItem(value: 'Student', child: Text('Student')),
                      DropdownMenuItem(value: 'Legal Advisor', child: Text('Legal Advisor')),
                      DropdownMenuItem(value: 'Police Personnel', child: Text('Police Personnel')),
                    ],
                    decoration: InputDecoration(
                      labelText: 'Profession',
                      errorText: _professionError,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(25),
                      ),
                    ),
                    isExpanded: true,
                  ),
                ),
                const SizedBox(height: 20),

                // Continue Button
                SizedBox(
                  width: fieldWidth,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _validateAndSubmit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromARGB(255, 44, 101, 224),
                      padding: EdgeInsets.symmetric(vertical: buttonHeight * 0.2),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25),
                      ),
                    ),
                    child: _isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : const Text('Continue', style: TextStyle(fontSize: 18, color: Colors.white)),
                  ),
                ),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
