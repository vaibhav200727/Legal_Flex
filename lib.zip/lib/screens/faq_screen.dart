import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data/faq_questions.dart'; // Contains: final Map<String, Map<String, String>> faqData = { ... };
import '../widgets/custom_appbar.dart'; // Your custom app bar widget
import '../providers/language_provider.dart';
import '../services/translation_service.dart';

class FAQScreen extends StatefulWidget {
  const FAQScreen({super.key});

  @override
  _FAQScreenState createState() => _FAQScreenState();
}

class _FAQScreenState extends State<FAQScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  // Translation-related variables
  String translatedFaqTitle = "FAQ & Help Center";
  String translatedPopularTopics = "Popular Topics";
  String translatedCommonQuestions = "Common Questions";
  String translatedSearchHint = "Search questions...";
  String selectedLanguage = "en";

  int? _selectedCategoryIndex;
  bool _showAllCategories = false;

  @override
  void initState() {
    super.initState();
    _selectedCategoryIndex = null; // No category chosen => default to Common Questions

    Provider.of<LanguageProvider>(context, listen: false)
        .addListener(_updateTranslations);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  @override
  void dispose() {
    Provider.of<LanguageProvider>(context, listen: false)
        .removeListener(_updateTranslations);
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    selectedLanguage = languageProvider.selectedLanguage;

    try {
      translatedFaqTitle = await TranslationService.translate("FAQ & Help Center", selectedLanguage);
      translatedPopularTopics = await TranslationService.translate("Popular Topics", selectedLanguage);
      translatedCommonQuestions = await TranslationService.translate("Common Questions", selectedLanguage);
      translatedSearchHint = await TranslationService.translate("Search questions...", selectedLanguage);
      if (mounted) setState(() {});
    } catch (e) {
      print("❌ Translation Error: $e");
    }
  }

  // Return the list of category names from faqData
  List<String> get _categoryList => faqData.keys.toList();

  /// Convert the original category name to a shorter display label.
  String _getShortCategoryName(String longName) {
    switch (longName) {
      case "Constitutional & Fundamental Rights":
        return "Fundamental Rights";
      case "Criminal Law & Police Matters":
        return "Criminal & Police";
      case "Civil Law & Property Disputes":
        return "Civil & Property";
      case "Consumer Rights & Protection":
        return "Consumer Rights";
      case "Family Law & Marriage":
        return "Family & Marriage";
      case "Employment & Labour Laws":
        return "Employment & Labour";
      case "Taxation & Financial Matters":
        return "Tax & Financial";
      case "Traffic & Motor Vehicle Laws":
        return "Traffic & Motor";
      case "Digital & Cyber Laws":
        return "Digital & Cyber";
      case "RTI (Right to Information) & Public Rights":
        return "RTI & Public";
      case "Women's Rights & Protection":
        return "Women’s Rights";
      case "Citizenship, Visa & Immigration":
        return "Citizenship & Visa";
      case "Education & Student Rights":
        return "Education & Students";
      case "Environmental & Public Nuisance Laws":
        return "Environment & Public";
      default:
        return longName; // fallback if no match
    }
  }

  /// Generate a map of FAQs based on the selected category or Common Questions if none chosen.
  Map<String, String> get _selectedFaqs {
    final category = (_selectedCategoryIndex == null)
        ? "Common Questions"
        : _categoryList[_selectedCategoryIndex!];

    final allFaqs = faqData[category] ?? {};
    Map<String, String> filteredFaqs;
    if (_searchQuery.isNotEmpty) {
      filteredFaqs = allFaqs.entries
          .where((entry) => entry.key.toLowerCase().contains(_searchQuery))
          .fold<Map<String, String>>({}, (prev, element) {
        prev[element.key] = element.value;
        return prev;
      });
    } else {
      filteredFaqs = Map<String, String>.from(allFaqs);
    }

    // If category is "Common Questions," only show 15
    if (category == "Common Questions" && filteredFaqs.length > 15) {
      return Map.fromEntries(filteredFaqs.entries.take(15));
    }
    return filteredFaqs;
  }

  /// Builds the FAQ list as ExpansionTiles.
  List<Widget> _buildFAQList(double screenWidth) {
    final List<Widget> widgets = [];
    _selectedFaqs.forEach((question, answer) {
      widgets.add(
        Container(
          margin: EdgeInsets.only(bottom: screenWidth * 0.04),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(screenWidth * 0.04),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Theme(
            data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
            child: ExpansionTile(
              tilePadding: EdgeInsets.symmetric(
                horizontal: screenWidth * 0.04,
                vertical: screenWidth * 0.02,
              ),
              title: Text(
                question,
                style: TextStyle(
                  fontSize: screenWidth * 0.045,
                  fontWeight: FontWeight.w600,
                ),
              ),
              trailing: Icon(
                Icons.expand_more,
                size: screenWidth * 0.06,
                color: Colors.blueAccent,
              ),
              children: [
                Container(
                  padding: EdgeInsets.all(screenWidth * 0.04),
                  alignment: Alignment.centerLeft,
                  child: Text(
                    answer,
                    style: TextStyle(
                      fontSize: screenWidth * 0.04,
                      color: Colors.black87,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    });

    if (widgets.isEmpty) {
      widgets.add(
        Center(
          child: Text(
            'No questions found.',
            style: TextStyle(fontSize: screenWidth * 0.045),
          ),
        ),
      );
    }
    return widgets;
  }

  /// Builds a grid of smaller rectangular boxes, with icon on left and short category text on right.
  Widget _buildCategoryGrid(double screenWidth) {
    // Decide how many items to show initially or show all
    final visibleCount = _showAllCategories ? _categoryList.length : 4;

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      // 2 columns, wide rectangular shape
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: screenWidth * 0.02,
        mainAxisSpacing: screenWidth * 0.02,
        childAspectRatio: 2.5,
      ),
      itemCount: visibleCount,
      itemBuilder: (context, index) {
        final longName = _categoryList[index];
        final shortName = _getShortCategoryName(longName);
        final bool selected = (_selectedCategoryIndex == index);

        return GestureDetector(
          onTap: () {
            setState(() {
              _selectedCategoryIndex = index;
            });
          },
          child: Container(
            decoration: BoxDecoration(
              color: selected ? Colors.blueAccent : Colors.white,
              borderRadius: BorderRadius.circular(screenWidth * 0.02),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.3),
                  blurRadius: 6,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  _getIconForCategory(longName),
                  size: screenWidth * 0.07,
                  color: selected
                      ? Colors.white
                      : _getIconColorForCategory(longName),
                ),
                SizedBox(width: screenWidth * 0.02),
                Expanded(
                  child: Text(
                    shortName,
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontSize: screenWidth * 0.04,
                      color: selected ? Colors.white : Colors.black87,
                      fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// Provides a category-specific icon.
  IconData _getIconForCategory(String category) {
    switch (category) {
      case "Constitutional & Fundamental Rights":
        return Icons.gavel;
      case "Criminal Law & Police Matters":
        return Icons.security;
      case "Civil Law & Property Disputes":
        return Icons.home;
      case "Consumer Rights & Protection":
        return Icons.thumb_up;
      case "Family Law & Marriage":
        return Icons.family_restroom;
      case "Employment & Labour Laws":
        return Icons.work;
      case "Taxation & Financial Matters":
        return Icons.attach_money;
      case "Traffic & Motor Vehicle Laws":
        return Icons.directions_car;
      case "Digital & Cyber Laws":
        return Icons.computer;
      case "RTI (Right to Information) & Public Rights":
        return Icons.info;
      case "Women's Rights & Protection":
        return Icons.female;
      case "Citizenship, Visa & Immigration":
        return Icons.public;
      case "Education & Student Rights":
        return Icons.school;
      case "Environmental & Public Nuisance Laws":
        return Icons.eco;
      default:
        return Icons.help;
    }
  }

  /// Provides a category-specific icon color.
  Color _getIconColorForCategory(String category) {
    switch (category) {
      case "Constitutional & Fundamental Rights":
        return Colors.red;
      case "Criminal Law & Police Matters":
        return Colors.deepPurple;
      case "Civil Law & Property Disputes":
        return Colors.green;
      case "Consumer Rights & Protection":
        return Colors.orange;
      case "Family Law & Marriage":
        return Colors.pink;
      case "Employment & Labour Laws":
        return Colors.indigo;
      case "Taxation & Financial Matters":
        return Colors.teal;
      case "Traffic & Motor Vehicle Laws":
        return Colors.amber;
      case "Digital & Cyber Laws":
        return Colors.blue;
      case "RTI (Right to Information) & Public Rights":
        return Colors.brown;
      case "Women's Rights & Protection":
        return Colors.purple;
      case "Citizenship, Visa & Immigration":
        return Colors.cyan;
      case "Education & Student Rights":
        return Colors.lightBlue;
      case "Environmental & Public Nuisance Laws":
        return Colors.lime;
      default:
        return const Color.fromRGBO(237, 174, 236, 1);
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    // If _selectedCategoryIndex is null => Common Questions
    final chosenCategory = (_selectedCategoryIndex == null)
        ? "Common Questions"
        : _categoryList[_selectedCategoryIndex!];

    final String faqHeading = (chosenCategory == "Common Questions")
        ? translatedCommonQuestions
        : chosenCategory;

    return CustomAppBar(
      title: translatedFaqTitle,
      icon: Icons.help_outline,
      body: SingleChildScrollView(
        padding: EdgeInsets.all(screenWidth * 0.04),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Universal Search Bar
            Container(
              height: 48,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 4,
                  ),
                ],
              ),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 1),
              child: TextField(
                controller: _searchController,
                textAlignVertical: TextAlignVertical.center,
                style: const TextStyle(fontWeight: FontWeight.bold),
                onChanged: (value) {
                  setState(() {
                    _searchQuery = value.trim().toLowerCase();
                  });
                },
                decoration: InputDecoration(
                  hintText: translatedSearchHint,
                  hintStyle: const TextStyle(fontWeight: FontWeight.bold),
                  prefixIcon: const Icon(Icons.search, color: Colors.blueAccent),
                  border: InputBorder.none,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                ),
              ),
            ),
            SizedBox(height: screenWidth * 0.06),

            // Popular Topics Heading
            Text(
              translatedPopularTopics,
              style: TextStyle(
                fontSize: screenWidth * 0.06,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: screenWidth * 0.04),
            _buildCategoryGrid(screenWidth),
            SizedBox(height: screenWidth * 0.02),

            // Show More / Show Less
            if (!_showAllCategories && _categoryList.length > 4)
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () {
                    setState(() {
                      _showAllCategories = true;
                    });
                  },
                  child: Text(
                    'Show More',
                    style: TextStyle(
                      fontSize: screenWidth * 0.045,
                      color: Colors.deepOrange,
                    ),
                  ),
                ),
              )
            else if (_showAllCategories && _categoryList.length > 4)
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () {
                    setState(() {
                      _showAllCategories = false;
                    });
                  },
                  child: Text(
                    'Show Less',
                    style: TextStyle(
                      fontSize: screenWidth * 0.045,
                      color: Colors.deepOrange,
                    ),
                  ),
                ),
              ),
            SizedBox(height: screenWidth * 0.04),

            // FAQ List Section
            Text(
              faqHeading,
              style: TextStyle(
                fontSize: screenWidth * 0.06,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: screenWidth * 0.04),
            ..._buildFAQList(screenWidth),
          ],
        ),
     ),
   );
 }
}
