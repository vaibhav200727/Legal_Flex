import 'package:flutter/material.dart';
import 'package:project/screens/chatbot_screen.dart';
import 'package:project/screens/document_screen.dart'; // Update the path if necessary
import 'package:project/widgets/custom_appbar.dart'; // Your custom app bar widget
import 'package:provider/provider.dart';
import 'package:project/providers/language_provider.dart';
import 'package:project/services/translation_service.dart';

class LegalDocsScreen extends StatefulWidget {
  const LegalDocsScreen({super.key});

  @override
  _LegalDocsScreenState createState() => _LegalDocsScreenState();
}

class _LegalDocsScreenState extends State<LegalDocsScreen>
    with SingleTickerProviderStateMixin {
  final int _selectedIndex = 0;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  // Translation-related variables
  String translatedTitle = "LegalDocs";
  String welcomeText = "Welcome to LegalDocs";
  String chooseOptionText = "Choose an option to proceed";
  String legalGeneratorTitle = "Legal Generator";
  String legalGeneratorSubtitle =
      "Create new constitution documents with our intelligent generator";
  String recentDocumentsTitle = "Recent Documents";
  String recentDocumentsSubtitle =
      "View and manage your recently created documents";
  String proTipText =
      "Try our DocGen feature for quick, accurate legal document creation. Save your drafts regularly to prevent losing any important changes";

  String selectedLanguage = "en";
  String? _previousLanguage;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );
    _fadeAnimation =
        Tween<double>(begin: 0, end: 1).animate(_animationController);
    _animationController.forward();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final languageProvider = Provider.of<LanguageProvider>(context);
    if (_previousLanguage != languageProvider.selectedLanguage) {
      _previousLanguage = languageProvider.selectedLanguage;
      _updateTranslations();
    }
  }

  Future<void> _updateTranslations() async {
    final languageProvider =
        Provider.of<LanguageProvider>(context, listen: false);
    selectedLanguage = languageProvider.selectedLanguage;

    try {
      translatedTitle =
          await TranslationService.translate("LegalDocs", selectedLanguage);
      welcomeText =
          await TranslationService.translate("Welcome to LegalDocs", selectedLanguage);
      chooseOptionText =
          await TranslationService.translate("Choose an option to proceed", selectedLanguage);
      legalGeneratorTitle =
          await TranslationService.translate("Legal Generator", selectedLanguage);
      legalGeneratorSubtitle = await TranslationService.translate(
          "Create new constitution documents with our intelligent generator",
          selectedLanguage);
      recentDocumentsTitle =
          await TranslationService.translate("Recent Documents", selectedLanguage);
      recentDocumentsSubtitle = await TranslationService.translate(
          "View and manage your recently created documents",
          selectedLanguage);
      proTipText = await TranslationService.translate(
          "Try our DocGen feature for quick, accurate legal document creation. Save your drafts regularly to prevent losing any important changes",
          selectedLanguage);
      if (mounted) {
        setState(() {});
      }
    } catch (e) {
      print("❌ Translation Error: $e");
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _onLegalGeneratorTap() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => const ChatbotScreen(),
      ),
    );
  }

  void _onRecentDocumentsTap() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => const DocumentsScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDarkMode = theme.brightness == Brightness.dark;
    final backgroundColor = isDarkMode ? Colors.grey[900] : Colors.white;
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 600;

    return Container(
      color: backgroundColor,
      child: CustomAppBar(
        title: translatedTitle,
        icon: Icons.library_books,
        body: SingleChildScrollView(
          padding: EdgeInsets.symmetric(
            horizontal: isSmallScreen ? 16.0 : 24.0,
            vertical: isSmallScreen ? 16.0 : 24.0,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Welcome Section
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 40.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      welcomeText,
                      textAlign: TextAlign.center,
                      style: theme.textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: isDarkMode ? Colors.white : Colors.black,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      chooseOptionText,
                      textAlign: TextAlign.center,
                      style: theme.textTheme.titleMedium?.copyWith(
                        color: isDarkMode ? Colors.white70 : Colors.black54,
                      ),
                    ),
                  ],
                ),
              ),
              // Option Cards Section
              OptionCard(
                title: legalGeneratorTitle,
                subtitle: legalGeneratorSubtitle,
                icon: Icons.description_outlined,
                onTap: _onLegalGeneratorTap,
              ),
              const SizedBox(height: 16),
              OptionCard(
                title: recentDocumentsTitle,
                subtitle: recentDocumentsSubtitle,
                icon: Icons.folder_open_outlined,
                onTap: _onRecentDocumentsTap,
              ),
              // Extra spacing
              const SizedBox(height: 40),
              // Pro Tip Section with Fade-In Animation
              FadeTransition(
                opacity: _fadeAnimation,
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: isDarkMode ? Colors.grey[800] : Colors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(
                        Icons.lightbulb_outline,
                        color: theme.primaryColor,
                        size: 28,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: RichText(
                          text: TextSpan(
                            style: theme.textTheme.bodyMedium?.copyWith(
                              color: isDarkMode ? Colors.white70 : Colors.black87,
                            ),
                            children: [
                              TextSpan(
                                text: 'Pro Tip: ',
                                style: theme.textTheme.bodyMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: isDarkMode ? Colors.white : Colors.black,
                                ),
                              ),
                              TextSpan(
                                text: proTipText,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}

class OptionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;

  const OptionCard({
    super.key,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDarkMode = theme.brightness == Brightness.dark;

    return Card(
      color: isDarkMode ? Colors.grey[800] : Colors.white,
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(
            vertical: 20,
            horizontal: 16,
          ),
          child: Row(
            children: [
              Icon(icon, size: 36, color: theme.primaryColor),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: isDarkMode ? Colors.white : Colors.black,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: isDarkMode ? Colors.white70 : Colors.black54,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Icon(
                Icons.arrow_forward_ios,
                size: 18,
                color: isDarkMode ? Colors.white70 : Colors.grey[400],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
