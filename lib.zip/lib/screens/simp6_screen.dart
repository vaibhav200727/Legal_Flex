import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import '../providers/language_provider.dart';
import '../services/translation_service.dart';
import '../widgets/custom_appbar.dart';

class LegalFrameworkScreen extends StatefulWidget {
  const LegalFrameworkScreen({super.key});

  @override
  _LegalFrameworkScreenState createState() => _LegalFrameworkScreenState();
}

class _LegalFrameworkScreenState extends State<LegalFrameworkScreen> {
  String translatedTitle = "Simplified Laws";
  String selectedLanguage = "en";
  String translatedCitizenship = "Citizenship";
  String translatedCooperativeSocieties = "Cooperative Societies";
  String translatedMiscellaneousProvisions = "Miscellaneous Provisions";
  String translatedTransitionalTemporaryProvisions = "Transitional & Temporary Provisions";
  String translatedTransitionalMiscellaneousProvisions = "Transitional & Miscellaneous Provisions";
  String translatedGovernanceSpecialProvisions = "Governance & Special Provisions";

  // Tracking which category is expanded
  Map<String, bool> isExpanded = {};

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Listen to language changes by using Provider.of without listen: false.
    final languageProvider = Provider.of<LanguageProvider>(context);
    if (selectedLanguage != languageProvider.selectedLanguage) {
      _updateTranslations();
    }
  }

  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    selectedLanguage = languageProvider.selectedLanguage;
    try {
      translatedTitle = await TranslationService.translate("Simplified Laws", selectedLanguage);
      translatedCitizenship = await TranslationService.translate("Citizenship", selectedLanguage);
      translatedCooperativeSocieties = await TranslationService.translate("Cooperative Societies", selectedLanguage);
      translatedMiscellaneousProvisions = await TranslationService.translate("Miscellaneous Provisions", selectedLanguage);
      translatedTransitionalTemporaryProvisions = await TranslationService.translate("Transitional & Temporary Provisions", selectedLanguage);
      translatedTransitionalMiscellaneousProvisions = await TranslationService.translate("Transitional & Miscellaneous Provisions", selectedLanguage);
      translatedGovernanceSpecialProvisions = await TranslationService.translate("Governance & Special Provisions", selectedLanguage);
      if (mounted) setState(() {});
    } catch (e) {
      print("❌ Translation Error: $e");
    }
  }

  /// Fetches an article from Firestore and translates its fields using the current language.
  Future<Map<String, dynamic>?> _fetchAndTranslateArticleContent(String subcategory, String articleId) async {
    try {
      final doc = await FirebaseFirestore.instance.collection(subcategory).doc(articleId).get();
      if (!doc.exists) return null;
      final data = doc.data() ?? {};
      final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
      final currentLang = languageProvider.selectedLanguage;

      final part = data['part'] ?? 'N/A';
      final simplifiedText = data['simplified_text'] ?? 'N/A';
      final exampleText = data['example'] ?? 'N/A';
      final originalText = data['original_text'] ?? 'N/A';

      final translatedPart = await TranslationService.translate(part, currentLang);
      final translatedSimplified = await TranslationService.translate(simplifiedText, currentLang);
      final translatedExample = await TranslationService.translate(exampleText, currentLang);
      final translatedOriginal = await TranslationService.translate(originalText, currentLang);

      return {
        'part': translatedPart,
        'simplified_text': translatedSimplified,
        'example': translatedExample,
        'original_text': translatedOriginal,
      };
    } catch (e) {
      print("❌ Firestore Fetch or Translate Error: $e");
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    return CustomAppBar(
      title: translatedTitle,
      icon: Icons.gavel,
      body: Scrollbar(
        thumbVisibility: true,
        thickness: 8.0,
        radius: const Radius.circular(10),
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildCategoryButton("category_citizenship", translatedCitizenship, Icons.person, Colors.blue),
              _buildCategoryButton("category_cooperative_societies", translatedCooperativeSocieties, Icons.group, Colors.green),
              _buildCategoryButton("category_miscellaneous_provisions", translatedMiscellaneousProvisions, Icons.assignment, Colors.purple),
              _buildCategoryButton("category_transitional_and_temporary_provisions", translatedTransitionalTemporaryProvisions, Icons.update, Colors.redAccent),
              _buildCategoryButton("category_transitional_and_misellaneous_provisions", translatedTransitionalMiscellaneousProvisions, Icons.cached, Colors.teal),
              _buildCategoryButton("category_governance_and_special_provisions", translatedGovernanceSpecialProvisions, Icons.admin_panel_settings, Colors.orange),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryButton(String subcategory, String title, IconData icon, Color color) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 5),
          child: InkWell(
            onTap: () {
              setState(() {
                isExpanded[subcategory] = !(isExpanded[subcategory] ?? false);
              });
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeInOut,
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 15),
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: color.withAlpha(100),
                    blurRadius: 8,
                    spreadRadius: 0.5,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: const BoxDecoration(
                      color: Color.fromARGB(50, 255, 255, 255),
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Icon(icon, color: Colors.white, size: 24),
                    ),
                  ),
                  const SizedBox(width: 15),
                  Expanded(
                    child: Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  Icon(
                    isExpanded[subcategory] == true ? Icons.expand_less : Icons.arrow_forward_ios,
                    color: Colors.white,
                    size: 16,
                  ),
                ],
              ),
            ),
          ),
        ),
        if (isExpanded[subcategory] == true)
          Padding(
            padding: const EdgeInsets.only(left: 20, top: 5, bottom: 5),
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection(subcategory).snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                final docs = snapshot.data!.docs;
                return Column(
                  children: docs.map((doc) => _buildArticleButton(subcategory, doc.id)).toList(),
                );
              },
            ),
          ),
      ],
    );
  }

  Widget _buildArticleButton(String subcategory, String articleId) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 10),
      child: InkWell(
        onTap: () async {
          final articleData = await _fetchAndTranslateArticleContent(subcategory, articleId);
          if (articleData != null) {
            _showArticleDialog(articleId, articleData);
          }
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.blueAccent),
          ),
          child: Row(
            children: [
              const Icon(Icons.article, color: Colors.blueAccent),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  "Article $articleId",
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                ),
              ),
              const Icon(Icons.arrow_forward_ios, color: Colors.blueAccent, size: 16),
            ],
          ),
        ),
      ),
    );
  }

  void _showArticleDialog(String articleId, Map<String, dynamic> articleData) {
    showDialog(
      context: context,
      builder: (context) {
        return FutureBuilder<Map<String, String>>(
          future: _getTranslatedDialogHeadings(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
            final headings = snapshot.data!;
            return AlertDialog(
              title: Text("${headings['article']} $articleId"),
              content: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildDialogSection("📌 ${headings['part']}", articleData['part']),
                    _buildDialogSection("📜 ${headings['simplified']}", articleData['simplified_text']),
                    _buildDialogSection("💡 ${headings['example']}", articleData['example']),
                    _buildDialogSection("📖 ${headings['original']}", articleData['original_text']),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("Close", style: TextStyle(color: Colors.blueAccent)),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<Map<String, String>> _getTranslatedDialogHeadings() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final currentLang = languageProvider.selectedLanguage;
    final headingArticle = await TranslationService.translate("Article", currentLang);
    final headingPart = await TranslationService.translate("Part", currentLang);
    final headingSimplified = await TranslationService.translate("Simplified Text", currentLang);
    final headingExample = await TranslationService.translate("Example/Scenario", currentLang);
    final headingOriginal = await TranslationService.translate("Original Article", currentLang);
    return {
      'article': headingArticle,
      'part': headingPart,
      'simplified': headingSimplified,
      'example': headingExample,
      'original': headingOriginal,
    };
  }

  Widget _buildDialogSection(String title, String? content) {
    return (content != null && content.isNotEmpty)
        ? Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.blueAccent)),
                const SizedBox(height: 5),
                Text(content, style: const TextStyle(fontSize: 14)),
              ],
            ),
          )
        : const SizedBox();
  }
}
