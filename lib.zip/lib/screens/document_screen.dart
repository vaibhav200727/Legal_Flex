import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:path_provider/path_provider.dart';
import 'package:project/widgets/custom_appbar.dart';
import 'pdf_preview.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:uuid/uuid.dart';
import 'package:crypto/crypto.dart' as crypto;
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import 'package:project/services/blockchain_service.dart';

enum ChatState {
  welcome,
  categorySelection,
  documentSelection,
  fillingPlaceholders,
  completed
}

/// Holds the verification result along with the computed and retrieved hashes.
class VerificationResult {
  final bool isVerified;
  final String computedHash;
  final String retrievedHash;

  VerificationResult({
    required this.isVerified,
    required this.computedHash,
    required this.retrievedHash,
  });
}

/// Model class for each document item.
class DocumentItem {
  final String docId;
  final String fileName;
  final String fileType;
  final String dateString;
  final String sizeString;
  final IconData icon;
  final String downloadUrl;
  final String subCategory;
  final DateTime? timestamp;
  final bool isVerified;
  // These fields are still stored internally for verification logic, but will not be shown in the UI.
  final String? computedHash;
  final String? retrievedHash;

  DocumentItem({
    required this.docId,
    required this.fileName,
    required this.fileType,
    required this.dateString,
    required this.sizeString,
    required this.icon,
    required this.downloadUrl,
    required this.subCategory,
    this.timestamp,
    required this.isVerified,
    this.computedHash,
    this.retrievedHash,
  });
}

class DocumentsScreen extends StatefulWidget {
  const DocumentsScreen({super.key});

  @override
  State<DocumentsScreen> createState() => _DocumentsScreenState();
}

class _DocumentsScreenState extends State<DocumentsScreen> {
  String documentsTitle = "Documents";
  String searchHint = "Search documents...";
  String filterButtonText = "Filter";
  String sortButtonText = "Sort";

  final List<String> categories = [
    "All Documents",
    "Essential Legal Affidavits & Declarations",
    "Rental & Property Agreements",
    "Employment & Business Contracts",
    "Police Complaints & Legal Notices",
    "Consumer & Service Complaints",
    "Legal & Financial Agreements",
    "Tenant & Landlord Complaints",
    "Workplace & Labor Complaints",
    "Personal Legal Documents",
  ];

  final Map<String, List<String>> subcategoryMap = {
    "Essential Legal Affidavits & Declarations": [
      "address_proof_affidavit",
      "general_affidavit",
      "lost_document_affidavit",
      "name_change_affidavit",
      "noc",
    ],
    "Rental & Property Agreements": [
      "gift_deed",
      "lease_agreement",
      "property_sale_agreement",
      "rental_agreement",
    ],
    "Employment & Business Contracts": [
      "appointment_letter",
      "freelance_agreement",
      "job_offer_letter",
      "nda",
      "partnership_agreement",
    ],
    "Police Complaints & Legal Notices": [
      "cyber_crime_complaint",
      "domestic_violence_complaint",
      "fraud_complaint",
      "harassment_complaint",
      "lost_document_complaint",
      "theft_complaint",
      "traffic_violation_complaint",
    ],
    "Consumer & Service Complaints": [
      "billing_dispute_complaint",
      "defective_product_complaint",
      "delayed_delivery_complaint",
      "rti_application",
      "service_complaint",
    ],
    "Legal & Financial Agreements": [
      "debt_settlement_agreement",
      "loan_agreement",
      "promissory_note",
    ],
    "Tenant & Landlord Complaints": [
      "illegal_eviction_complaint",
      "maintenance_repairs_complaint",
      "security_deposit_refund_complaint",
    ],
    "Workplace & Labor Complaints": [
      "minimum_wage_complaint",
      "unpaid_wages_complaint",
      "workplace_harassment_complaint",
      "wrongful_termination_complaint",
    ],
    "Personal Legal Documents": [
      "medical_consent_form",
      "power_of_attorney",
      "will_and_testament",
    ],
  };

  int _selectedCategoryIndex = 0;
  List<String> _selectedFilterPrefixes = [];
  List<DocumentItem> _documents = [];
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";
  String _currentSort = "None";
  bool _isLoading = false;

  final BlockchainService _blockchainService = BlockchainService();

  // Log file for debugging blockchain queries stored in the project directory.
  File? _logFile;

  @override
  void initState() {
    super.initState();
    _selectedFilterPrefixes = [];
    _initLogging();
    _initializeAndFetchDocuments();
  }

  /// Asynchronously initialize blockchain service and then fetch documents.
  Future<void> _initializeAndFetchDocuments() async {
    await _blockchainService.init();
    await _fetchUserDocuments();
  }

  /// Initialize the log file inside a 'logs' folder in your project directory.
  Future<void> _initLogging() async {
    try {
      final projectPath = Directory.current.path;
      final logDir = Directory("$projectPath/logs");
      if (!(await logDir.exists())) {
        await logDir.create();
      }
      _logFile = File("${logDir.path}/document_verification_logs.txt");
      _logFile!.writeAsStringSync(
        "=== Document Verification Logs Started at ${DateTime.now()} ===\n",
        mode: FileMode.write,
      );
      print("Log file stored in: ${_logFile!.path}");
    } catch (e) {
      print("Error initializing logging: $e");
    }
  }

  /// Debug log: prints and writes to the log file.
  void _debugLog(String msg) {
    final logMessage = "[DOC_SCREEN_DEBUG] $msg";
    print(logMessage);
    _logFile?.writeAsStringSync("$logMessage\n", mode: FileMode.append);
  }

  /// Fetch all documents for the current uid from Firestore, then for each document:
  /// - Use its docId to retrieve the stored hash from blockchain.
  /// - Download its PDF from Firebase and compute its SHA-256 hash.
  /// - Call the blockchain's verifyDocument function with the computed hash.
  /// - Store the computed hash, retrieved hash, and verification result in the DocumentItem.
  Future<void> _fetchUserDocuments() async {
    setState(() => _isLoading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final uid = prefs.getString('uid') ?? "";
      if (uid.isEmpty) {
        _debugLog("No UID found in SharedPreferences!");
        setState(() => _isLoading = false);
        return;
      }
      _debugLog("Fetching docs for UID=$uid ...");

      final query = await FirebaseFirestore.instance
          .collection("documents_generated")
          .where("uid", isEqualTo: uid)
          .get();

      final List<DocumentItem> tempList = [];
      for (final doc in query.docs) {
        final docId = doc.id;
        final data = doc.data();
        final downloadUrl = data["downloadUrl"] ?? "";
        final subCategory = data["sub_category"] ?? docId.split("_")[0];
        final tsField = data["timestamp"];

        final dateString = _parseDateFromDocId(docId);
        DateTime? tsDate;
        if (tsField != null && tsField is Timestamp) {
          tsDate = tsField.toDate();
        }

        double fileSizeBytes = 0;
        try {
          final storageRef =
              FirebaseStorage.instance.ref().child("documents_generated/$docId.pdf");
          final meta = await storageRef.getMetadata();
          fileSizeBytes = meta.size?.toDouble() ?? 0;
        } catch (e) {
          _debugLog("Error getting file size for $docId: $e");
        }
        final sizeString = fileSizeBytes < 1024 * 1024
            ? "${(fileSizeBytes / 1024).toStringAsFixed(2)} KB"
            : "${(fileSizeBytes / (1024 * 1024)).toStringAsFixed(2)} MB";

        // Retrieve the stored hash from blockchain using the docId.
        String retrievedHash = "";
        try {
          retrievedHash = (await _blockchainService.getStoredHash(docId)).trim();
          _debugLog("docId=$docId => Retrieved Blockchain Hash: '$retrievedHash'");
        } catch (e) {
          _debugLog("Error retrieving blockchain hash for $docId: $e");
        }

        // If there's a downloadUrl, download the PDF, compute its hash, and verify.
        bool isVerified = false;
        String? computedHash;
        if (downloadUrl.isNotEmpty) {
          final result = await _verifyDocument(docId, downloadUrl);
          isVerified = result.isVerified;
          computedHash = result.computedHash;
        } else {
          _debugLog("docId=$docId has no downloadUrl, skipping PDF verification");
        }

        final item = DocumentItem(
          docId: docId,
          fileName: docId,
          fileType: "PDF",
          dateString: tsDate == null
              ? dateString
              : "${tsDate.day} ${DateFormat.MMM().format(tsDate)}, ${tsDate.year}",
          sizeString: sizeString,
          icon: Icons.picture_as_pdf,
          downloadUrl: downloadUrl,
          subCategory: subCategory,
          timestamp: tsDate,
          isVerified: isVerified,
          computedHash: computedHash,
          retrievedHash: retrievedHash,
        );
        tempList.add(item);
      }
      setState(() {
        _documents = tempList;
        _isLoading = false;
      });
    } catch (e) {
      _debugLog("Error in _fetchUserDocuments: $e");
      setState(() => _isLoading = false);
    }
  }

  /// Download the PDF, compute its hash, then call the blockchain's verifyDocument function.
  Future<VerificationResult> _verifyDocument(String docId, String downloadUrl) async {
    final tempDir = await getTemporaryDirectory();
    final tempFilePath = "${tempDir.path}/$docId.pdf";
    final tempFile = File(tempFilePath);

    try {
      _debugLog("Downloading PDF for docId=$docId");
      final response = await http.get(Uri.parse(downloadUrl));
      if (response.statusCode == 200) {
        await tempFile.writeAsBytes(response.bodyBytes);
      } else {
        _debugLog("Download failed for $docId with status ${response.statusCode}");
        return VerificationResult(
          isVerified: false,
          computedHash: "Download Failed",
          retrievedHash: "N/A",
        );
      }
    } catch (e) {
      _debugLog("Error downloading PDF for $docId: $e");
      return VerificationResult(
        isVerified: false,
        computedHash: "Download Error",
        retrievedHash: "N/A",
      );
    }

    if (await tempFile.exists()) {
      final pdfBytes = await tempFile.readAsBytes();
      final computedHash = crypto.sha256.convert(pdfBytes).toString().trim();
      _debugLog("docId=$docId => Computed Hash: '$computedHash'");

      bool isVerified = false;
      try {
        // Use the computed hash to call the on-chain verifyDocument function.
        isVerified = await _blockchainService.verifyDocument(docId, computedHash);
        _debugLog("docId=$docId => On-chain Verification Result: ${isVerified ? "True" : "False"}");
      } catch (e) {
        _debugLog("Error during on-chain verification for $docId: $e");
      }

      return VerificationResult(
        isVerified: isVerified,
        computedHash: computedHash,
        retrievedHash: "", // Already retrieved separately in _fetchUserDocuments.
      );
    } else {
      _debugLog("File for $docId not found after download.");
      return VerificationResult(
        isVerified: false,
        computedHash: "File Missing",
        retrievedHash: "N/A",
      );
    }
  }

  String _parseDateFromDocId(String docId) {
    final parts = docId.split("_");
    if (parts.length >= 2) {
      final ddmmyyyy = parts[1];
      if (ddmmyyyy.length == 8) {
        final dd = ddmmyyyy.substring(0, 2);
        final mm = ddmmyyyy.substring(2, 4);
        final yyyy = ddmmyyyy.substring(4, 8);
        return "$dd/$mm/$yyyy";
      }
    }
    return "Unknown Date";
  }

  void _onSearchChanged(String value) {
    setState(() => _searchQuery = value.trim().toLowerCase());
  }

  void _onFilterPressed() {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return SafeArea(
          child: ListView(
            shrinkWrap: true,
            children: categories.map((displayName) {
              return ListTile(
                title: Text(displayName),
                onTap: () {
                  setState(() {
                    _selectedCategoryIndex = categories.indexOf(displayName);
                    _selectedFilterPrefixes = _selectedCategoryIndex == 0
                        ? []
                        : subcategoryMap[displayName] ?? [];
                  });
                  Navigator.pop(context);
                },
              );
            }).toList(),
          ),
        );
      },
    );
  }

  void _onSortPressed() {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            ListTile(
              title: const Text("Newest First"),
              onTap: () {
                setState(() => _currentSort = "Newest");
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: const Text("Oldest First"),
              onTap: () {
                setState(() => _currentSort = "Oldest");
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: const Text("This Week"),
              onTap: () {
                setState(() => _currentSort = "This Week");
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: const Text("This Month"),
              onTap: () {
                setState(() => _currentSort = "This Month");
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: const Text("This Year"),
              onTap: () {
                setState(() => _currentSort = "This Year");
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: const Text("Clear Sort"),
              onTap: () {
                setState(() => _currentSort = "None");
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  List<DocumentItem> get _filteredDocuments {
    var docs = List<DocumentItem>.from(_documents);
    if (_selectedFilterPrefixes.isNotEmpty) {
      docs = docs.where((doc) {
        final subCat = doc.subCategory.toLowerCase();
        return _selectedFilterPrefixes.map((p) => p.toLowerCase()).contains(subCat);
      }).toList();
    }
    if (_searchQuery.isNotEmpty) {
      docs = docs.where((doc) => doc.fileName.toLowerCase().contains(_searchQuery)).toList();
    }
    if (_currentSort == "Newest") {
      docs.sort((a, b) => (b.timestamp ?? DateTime(0)).compareTo(a.timestamp ?? DateTime(0)));
    } else if (_currentSort == "Oldest") {
      docs.sort((a, b) => (a.timestamp ?? DateTime.now()).compareTo(b.timestamp ?? DateTime.now()));
    } else if (_currentSort == "This Week") {
      final now = DateTime.now();
      final weekStart = now.subtract(Duration(days: now.weekday - 1));
      docs = docs.where((doc) => doc.timestamp != null && doc.timestamp!.isAfter(weekStart)).toList();
      docs.sort((a, b) => (b.timestamp ?? DateTime(0)).compareTo(a.timestamp ?? DateTime(0)));
    } else if (_currentSort == "This Month") {
      final now = DateTime.now();
      final monthStart = DateTime(now.year, now.month, 1);
      docs = docs.where((doc) => doc.timestamp != null && doc.timestamp!.isAfter(monthStart)).toList();
      docs.sort((a, b) => (b.timestamp ?? DateTime(0)).compareTo(a.timestamp ?? DateTime(0)));
    } else if (_currentSort == "This Year") {
      final now = DateTime.now();
      final yearStart = DateTime(now.year, 1, 1);
      docs = docs.where((doc) => doc.timestamp != null && doc.timestamp!.isAfter(yearStart)).toList();
      docs.sort((a, b) => (b.timestamp ?? DateTime(0)).compareTo(a.timestamp ?? DateTime(0)));
    }
    return docs;
  }

  Widget _buildDocumentTile(DocumentItem doc) {
    final verifiedIndicator = doc.isVerified ? "✔️ Blockchain Verified" : "❌ ";
    // Now we show only the essential information in the UI.
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: Colors.blue.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(doc.icon, color: Colors.blue),
        ),
        title: Text(
          doc.fileName,
          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: Colors.black87),
        ),
        subtitle: Text(
          "${doc.fileType} • ${doc.sizeString}   $verifiedIndicator",
          style: TextStyle(fontSize: 13, color: doc.isVerified ? Colors.green : Colors.red),
        ),
        trailing: Text(doc.dateString, style: const TextStyle(fontSize: 13, color: Colors.black54)),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => PdfPreviewScreen(downloadUrl: doc.downloadUrl, fileName: doc.fileName),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bgColor = Theme.of(context).brightness == Brightness.dark ? Colors.black : const Color(0xFFF8F8F8);
    return Container(
      color: bgColor,
      child: CustomAppBar(
        title: "Legal Chatbot",
        icon: Icons.gavel,
        body: Stack(
          children: [
            SingleChildScrollView(
              child: Column(
                children: [
                  // Search Bar
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Container(
                      height: 48,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        children: [
                          const SizedBox(width: 8),
                          const Icon(Icons.search, color: Colors.grey),
                          const SizedBox(width: 4),
                          Expanded(
                            child: TextField(
                              controller: _searchController,
                              onChanged: _onSearchChanged,
                              decoration: const InputDecoration(
                                hintText: "Search documents...",
                                border: InputBorder.none,
                                hintStyle: TextStyle(color: Colors.grey),
                              ),
                              style: const TextStyle(fontSize: 14),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  // Filter & Sort Buttons
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: _onFilterPressed,
                            icon: const Icon(Icons.filter_list),
                            label: Text(filterButtonText),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,
                              foregroundColor: Colors.black87,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                                side: BorderSide(color: Colors.grey.shade300),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: _onSortPressed,
                            icon: const Icon(Icons.sort),
                            label: Text(sortButtonText),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,
                              foregroundColor: Colors.black87,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                                side: BorderSide(color: Colors.grey.shade300),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  // Document List
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Column(
                      children: _filteredDocuments.map(_buildDocumentTile).toList(),
                    ),
                  ),
                ],
              ),
            ),
            if (_isLoading)
              Container(
                color: Colors.black54,
                child: const Center(child: CircularProgressIndicator()),
              ),
          ],
        ),
      ),
    );
  }
}
