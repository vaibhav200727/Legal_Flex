import 'dart:convert';
import 'package:flutter/material.dart';
import '../widgets/custom_appbar.dart';

class SuggestedActsScreen extends StatelessWidget {
  final String caseName;
  final String caseDescription;
  final String priority;
  final String dueDate;
  final Map<String, dynamic> prediction;

  const SuggestedActsScreen({
    super.key,
    required this.caseName,
    required this.caseDescription,
    required this.priority,
    required this.dueDate,
    required this.prediction,
  });

  @override
  Widget build(BuildContext context) {
    // Obtain screen dimensions for responsiveness.
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;

    // Expecting prediction to have a key "best_acts" containing a List.
    List<dynamic> bestActs = prediction["best_acts"] ?? [];

    return CustomAppBar(
      title: "Suggested Legal Acts",
      icon: Icons.gavel,
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.04,
          vertical: screenHeight * 0.015,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildCaseInfoCard(context, screenWidth, screenHeight),
            SizedBox(height: screenHeight * 0.02),
            Text(
              "Recommended Acts:",
              style: TextStyle(
                fontSize: screenWidth * 0.045,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: screenHeight * 0.015),
            ...bestActs.map((act) => _buildActCard(act, screenWidth)),
          ],
        ),
      ),
    );
  }

  Widget _buildCaseInfoCard(BuildContext context, double screenWidth, double screenHeight) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(screenWidth * 0.02)),
      elevation: 2,
      child: Padding(
        padding: EdgeInsets.all(screenWidth * 0.04),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Case Name
            Text(
              caseName,
              style: TextStyle(
                fontSize: screenWidth * 0.05,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: screenHeight * 0.01),
            // Case Description with only the label bold.
            RichText(
              text: TextSpan(
                text: "Case Description: ",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: screenWidth * 0.04,
                  color: Colors.black,
                ),
                children: [
                  TextSpan(
                    text: caseDescription,
                    style: TextStyle(
                      fontWeight: FontWeight.normal,
                      fontSize: screenWidth * 0.04,
                      color: Colors.grey.shade800,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: screenHeight * 0.01),
            // Due Date & Priority
            Row(
              children: [
                Icon(Icons.calendar_today, size: screenWidth * 0.04, color: Colors.blue),
                SizedBox(width: screenWidth * 0.015),
                Text(
                  "Filing Date: $dueDate",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: screenWidth * 0.04),
                ),
                const Spacer(),
                Text(
                  "Priority: $priority",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: screenWidth * 0.04),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActCard(Map<String, dynamic> act, double screenWidth) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: screenWidth * 0.02),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(screenWidth * 0.02)),
      elevation: 2,
      child: Padding(
        padding: EdgeInsets.all(screenWidth * 0.04),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Act Title and Confidence Badge
            Row(
              children: [
                Expanded(
                  child: Text(
                    act["title"] ?? "No Title",
                    style: TextStyle(
                      fontSize: screenWidth * 0.045,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: screenWidth * 0.03,
                    vertical: screenWidth * 0.01,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.green.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(screenWidth * 0.02),
                  ),
                  child: Text(
                    "${act["confidence"]} Match",
                    style: TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.bold,
                      fontSize: screenWidth * 0.04,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: screenWidth * 0.03),
            // Sections: Render using ordered list format.
            if (act["sections"] != null)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("• Sections:", style: TextStyle(fontWeight: FontWeight.bold, fontSize: screenWidth * 0.04)),
                  _buildOrderedListForMap(act["sections"], screenWidth),
                  SizedBox(height: screenWidth * 0.03),
                ],
              ),
            // Penalties: Render using ordered list format.
            if (act["penalties"] != null)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("• Penalties:", style: TextStyle(fontWeight: FontWeight.bold, fontSize: screenWidth * 0.04)),
                  _buildOrderedListForMap(act["penalties"], screenWidth),
                  SizedBox(height: screenWidth * 0.03),
                ],
              ),
            // Categories: Display as comma-separated, placed below penalties.
            if (act["categories"] != null)
              Padding(
                padding: EdgeInsets.only(top: screenWidth * 0.015),
                child: RichText(
                  text: TextSpan(
                    text: "Categories: ",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: screenWidth * 0.04,
                      color: Colors.black,
                    ),
                    children: [
                      TextSpan(
                        text: (act["categories"] as List<dynamic>).join(', '),
                        style: TextStyle(
                          fontWeight: FontWeight.normal,
                          fontSize: screenWidth * 0.04,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            SizedBox(height: screenWidth * 0.03),
            // Description
            Text(
              act["description"] ?? "",
              style: TextStyle(fontSize: screenWidth * 0.04),
            ),
          ],
        ),
      ),
    );
  }

  /// Renders a Map as an ordered list.
  /// Each entry is displayed as "1. key : value" (if value is a string)
  /// or "1. key : value1, value2" (if value is a list)
  Widget _buildOrderedListForMap(Map<String, dynamic> items, double screenWidth) {
    List<Widget> listItems = [];
    int count = 1;
    items.forEach((key, value) {
      String content;
      if (value is List) {
        content = value.join(", ");
      } else if (value is String) {
        content = value;
      } else {
        content = "";
      }
      listItems.add(
        Padding(
          padding: EdgeInsets.only(left: screenWidth * 0.04, top: screenWidth * 0.005),
          child: Text(
            "$count. $key : $content",
            style: TextStyle(fontSize: screenWidth * 0.04),
          ),
        ),
      );
      count++;
    });
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: listItems,
    );
  }
}
