import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:provider/provider.dart';

// Import your custom app bar, language provider, and translation service.
import '../widgets/custom_appbar.dart';
import '../providers/language_provider.dart';
import '../services/translation_service.dart';

class ArticleSimplificationScreen1 extends StatefulWidget {
  const ArticleSimplificationScreen1({super.key});

  @override
  _ArticleSimplificationScreenState1 createState() => _ArticleSimplificationScreenState1();
}

class _ArticleSimplificationScreenState1 extends State<ArticleSimplificationScreen1> {
  final FlutterTts flutterTts = FlutterTts();

  // Local data for tax-related articles (frontend only)
  final List<Map<String, String>> _articles = [
    {
      "title": "Article 265",
      "part": "Part XII",
      "simplifiedText": "Taxes can only be imposed through legislation, ensuring no arbitrary levies.",
      "exampleScenario": "A new tax is introduced only after Parliament debates and passes a law, ensuring it has legal backing.",
      "originalArticle": "Taxes not to be imposed save by authority of law."
    },
    {
      "title": "Article 246A",
      "part": "Part XII",
      "simplifiedText": "Provides a framework for a unified Goods and Services Tax (GST) system across India.",
      "exampleScenario": "Businesses across different states charge GST, streamlining tax collection under a single national framework.",
      "originalArticle": "Special provision with respect to goods and services tax."
    },
    {
      "title": "Article 276",
      "part": "Part XII",
      "simplifiedText": "Allows States and the Union to levy taxes on professions, trades, callings, and employments.",
      "exampleScenario": "A state government imposes a nominal professional tax on salaried employees and small business owners.",
      "originalArticle": "Taxes on professions, trades, callings, and employments."
    },
    {
      "title": "Article 268",
      "part": "Part XII",
      "simplifiedText": "Describes duties levied by the Union but collected by the States.",
      "exampleScenario": "Stamp duty is set by the central government but the revenue is collected by the state where the transaction occurs.",
      "originalArticle": "Duties levied by the Union but collected and appropriated by the States."
    },
    {
      "title": "Article 269",
      "part": "Part XII",
      "simplifiedText": "Details taxes levied and collected by the Union but assigned to the States.",
      "exampleScenario": "A central sales tax on inter-state trade is collected by the Union and fully allocated to the state where the sale happens.",
      "originalArticle": "Taxes levied and collected by the Union but assigned to the States."
    },
    {
      "title": "Article 270",
      "part": "Part XII",
      "simplifiedText": "Specifies the sharing of taxes between the Union and the States.",
      "exampleScenario": "Income tax collected by the central government is partially redistributed to the states according to an agreed formula.",
      "originalArticle": "Taxes levied and collected by the Union and distributed between the Union and the States."
    },
    {
      "title": "Article 271",
      "part": "Part XII",
      "simplifiedText": "Authorizes the imposition of surcharges on certain duties and taxes for Union purposes.",
      "exampleScenario": "A surcharge is added to the income tax to fund national projects, with the extra revenue retained by the central government.",
      "originalArticle": "Surcharge on certain duties and taxes for purposes of the Union."
    }
  ];

  // Translated screen title and articles.
  String _translatedScreenTitle = "Article Simplifications";
  List<Map<String, String>> _translatedArticles = [];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  /// Update translations for the screen title and all article fields.
  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLanguage = languageProvider.selectedLanguage;

    try {
      // Translate the screen title.
      _translatedScreenTitle = await TranslationService.translate(
        "Tax Simplifications",
        selectedLanguage,
      );

      // Translate each article's fields.
      List<Map<String, String>> newArticles = [];
      for (var article in _articles) {
        final tTitle = await TranslationService.translate(article['title']!, selectedLanguage);
        final tPart = await TranslationService.translate(article['part']!, selectedLanguage);
        final tSimplifiedText =
            await TranslationService.translate(article['simplifiedText']!, selectedLanguage);
        final tExampleScenario =
            await TranslationService.translate(article['exampleScenario']!, selectedLanguage);
        final tOriginalArticle =
            await TranslationService.translate(article['originalArticle']!, selectedLanguage);

        newArticles.add({
          "title": tTitle,
          "part": tPart,
          "simplifiedText": tSimplifiedText,
          "exampleScenario": tExampleScenario,
          "originalArticle": tOriginalArticle,
        });
      }

      if (mounted) {
        setState(() {
          _translatedArticles = newArticles;
        });
      }
    } catch (e) {
      debugPrint("❌ Translation error: $e");
    }
  }

  /// Text-to-speech functionality.
  void _speak(String text) async {
    await flutterTts.speak(text);
  }

  @override
  Widget build(BuildContext context) {
    return CustomAppBar(
      title: _translatedScreenTitle,
      icon: Icons.article,
      body: ListView.builder(
        padding: const EdgeInsets.all(12.0),
        itemCount: _translatedArticles.length,
        itemBuilder: (context, index) {
          final article = _translatedArticles[index];
          return Container(
            margin: const EdgeInsets.symmetric(vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.blue),
              borderRadius: BorderRadius.circular(8),
            ),
            child: ListTile(
              leading: const Icon(Icons.article, color: Colors.blue),
              title: Text(
                article["title"] ?? "",
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              trailing: const Icon(Icons.chevron_right, color: Colors.blue),
              onTap: () {
                _showArticleDialog(article);
              },
            ),
          );
        },
      ),
    );
  }

  /// Displays an AlertDialog with detailed article information.
  void _showArticleDialog(Map<String, String> article) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(article["title"] ?? ""),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildDialogSection("📌 Part", article["part"]),
                _buildDialogSection("📜 Simplified Text", article["simplifiedText"]),
                _buildDialogSection("💡 Example/Scenario", article["exampleScenario"]),
                _buildDialogSection("📖 Original Article", article["originalArticle"]),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: () => _speak(article["simplifiedText"] ?? ""),
                  icon: const Icon(Icons.volume_up),
                  label: const Text("Read Aloud"),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Close", style: TextStyle(color: Colors.blueAccent)),
            )
          ],
        );
      },
    );
  }

  /// Helper widget for formatting dialog sections.
  Widget _buildDialogSection(String title, String? content) {
    if (content == null || content.isEmpty) return const SizedBox();
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.blueAccent,
            ),
          ),
          const SizedBox(height: 5),
          Text(content, style: const TextStyle(fontSize: 14)),
        ],
      ),
    );
  }
}
