import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:provider/provider.dart';
import '../widgets/custom_appbar.dart';
import '../providers/language_provider.dart';
import '../providers/save_provider.dart';
import '../services/translation_service.dart';

class CulturalRightsScreen extends StatefulWidget {
  const CulturalRightsScreen({super.key});

  @override
  _CulturalRightsScreenState createState() => _CulturalRightsScreenState();
}

class _CulturalRightsScreenState extends State<CulturalRightsScreen> {
  final FlutterTts flutterTts = FlutterTts();

  String headerText = "Know Your Rights";
  List<String> translatedTitles = culturalRights.map((e) => e['title'] as String).toList();
  List<String> translatedDescriptions =
      culturalRights.map((e) => e['description'] as String).toList();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLanguage = languageProvider.selectedLanguage;

    try {
      String newHeader = await TranslationService.translate("Know Your Rights", selectedLanguage);
      if (mounted) {
        setState(() {
          headerText = newHeader;
        });
      }
    } catch (e) {
      print("❌ Translation error for header: $e");
    }

    List<String> newTitles = [];
    List<String> newDescriptions = [];
    for (var item in culturalRights) {
      try {
        String tTitle = await TranslationService.translate(item['title'], selectedLanguage);
        String tDesc = await TranslationService.translate(item['description'], selectedLanguage);
        newTitles.add(tTitle);
        newDescriptions.add(tDesc);
      } catch (e) {
        print("❌ Translation error for ${item['title']}: $e");
        newTitles.add(item['title']);
        newDescriptions.add(item['description']);
      }
    }
    if (mounted) {
      setState(() {
        translatedTitles = newTitles;
        translatedDescriptions = newDescriptions;
      });
    }
  }

  void _speak(String text) async {
    await flutterTts.speak(text);
  }

  // Toggle saved status using SaveProvider
  void toggleSaveItem(BuildContext context, String item) {
    final saveProvider = Provider.of<SaveProvider>(context, listen: false);
    if (saveProvider.savedItems.contains(item)) {
      saveProvider.removeItem(item);
    } else {
      saveProvider.addItem(item);
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isSmallScreen = screenWidth < 600;
    final saveProvider = Provider.of<SaveProvider>(context);

    return CustomAppBar(
      title: "Know Your Rights",
      icon: Icons.museum,
      body: Padding(
        padding: EdgeInsets.all(isSmallScreen ? 8.0 : 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            Text(
              headerText,
              style: TextStyle(fontSize: isSmallScreen ? 16 : 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: culturalRights.length,
                itemBuilder: (context, index) {
                  final title = translatedTitles[index];
                  final description = translatedDescriptions[index];
                  final isSaved = saveProvider.savedItems.contains(title);
                  return Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    margin: EdgeInsets.symmetric(vertical: isSmallScreen ? 4 : 6),
                    child: Padding(
                      padding: EdgeInsets.all(isSmallScreen ? 8 : 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                culturalRights[index]['icon'],
                                color: culturalRights[index]['color'],
                                size: isSmallScreen ? 28 : 32,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  title,
                                  style: TextStyle(
                                    fontSize: isSmallScreen ? 14 : 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: Icon(Icons.volume_up, color: Colors.blue, size: isSmallScreen ? 22 : 26),
                                onPressed: () => _speak(description),
                              ),
                              IconButton(
                                icon: Icon(
                                  isSaved ? Icons.bookmark : Icons.bookmark_border,
                                  color: isSaved ? Colors.blue : Colors.grey,
                                  size: isSmallScreen ? 22 : 26,
                                ),
                                onPressed: () {
                                  toggleSaveItem(context, title);
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text(
                            description,
                            style: TextStyle(fontSize: isSmallScreen ? 15 : 20, color: Colors.grey),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

final List<Map<String, dynamic>> culturalRights = [
  {"title": "Right to Practice One’s Culture", "icon": Icons.language, "color": Colors.blue, "description": "Everyone has the right to express and celebrate their culture."},
  {"title": "Right to Protect Cultural Heritage", "icon": Icons.museum, "color": Colors.green, "description": "Cultural heritage must be preserved for future generations."},
  {"title": "Right to Access Cultural Institutions", "icon": Icons.account_balance, "color": Colors.orange, "description": "Libraries, museums, and heritage sites should be accessible to all."},
  {"title": "Right to Minority Representation", "icon": Icons.people, "color": Colors.red, "description": "Minorities must have fair representation in cultural policies."},
  {"title": "Right to Learn and Speak One’s Language", "icon": Icons.translate, "color": Colors.purple, "description": "Everyone has the right to education in their native language."},
  {"title": "Right to Indigenous Knowledge Protection", "icon": Icons.book, "color": Colors.teal, "description": "Traditional knowledge should be recognized and respected."},
  {"title": "Right to Freedom from Cultural Discrimination", "icon": Icons.equalizer, "color": Colors.cyan, "description": "No one should face discrimination based on cultural identity."},
  {"title": "Right to Cultural Exchange", "icon": Icons.swap_horiz, "color": Colors.amber, "description": "People should have opportunities to learn about other cultures."},
  {"title": "Right to Artistic Freedom", "icon": Icons.palette, "color": Colors.brown, "description": "Artists should be free to create without censorship."},
  {"title": "Right to Intellectual Property of Cultural Works", "icon": Icons.lightbulb, "color": Colors.indigo, "description": "Cultural inventions and traditions should be legally protected."}
];
