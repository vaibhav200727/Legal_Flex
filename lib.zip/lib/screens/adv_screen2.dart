import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:project/services/lawyers_service.dart'; // Your backend service
import 'package:project/widgets/custom_appbar.dart';
import 'package:project/screens/adv_screen3.dart'; // LawyerDetailScreen placeholder
import 'package:project/screens/adv_screen5.dart'; // PaymentSuccessfulScreen placeholder
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../providers/language_provider.dart';
import '../../providers/theme_provider.dart';
import '../../services/translation_service.dart';

class LawyersScreen extends StatefulWidget {
  const LawyersScreen({super.key});

  @override
  State<LawyersScreen> createState() => _LawyersScreenState();
}

class _LawyersScreenState extends State<LawyersScreen> {
  // --- Tab selection ---
  final int _selectedTabIndex = 0;

  // --- Translation variables ---
  String translatedTitle = "Lawyers";
  String selectedLanguage = "en";
  String translatedStateLabel = "State";
  String translatedCityLabel = "City";
  String translatedPracticeLabel = "Practice";

  // --- Filter variables ---
  String selectedState = 'State';
  String selectedCity = 'City';
  String selectedPractice = 'Practice';
  String searchQuery = "";

  // --- Lists for states and cities ---
  final List<String> statesOfIndia = [
    "Andhra Pradesh",
    "Arunachal Pradesh",
    "Assam",
    "Bihar",
    "Chhattisgarh",
    "Goa",
    "Gujarat",
    "Haryana",
    "Himachal Pradesh",
    "Jharkhand",
    "Karnataka",
    "Kerala",
    "Madhya Pradesh",
    "Maharashtra",
    "Manipur",
    "Meghalaya",
    "Mizoram",
    "Nagaland",
    "Odisha",
    "Punjab",
    "Rajasthan",
    "Sikkim",
    "Tamil Nadu",
    "Telangana",
    "Tripura",
    "Uttar Pradesh",
    "Uttarakhand",
    "West Bengal",
    "Andaman and Nicobar Islands",
    "Chandigarh",
    "Dadra and Nagar Haveli and Daman and Diu",
    "Lakshadweep",
    "Delhi",
    "Puducherry",
    "Jammu and Kashmir",
    "Ladakh"
  ];

  final List<String> citiesOfIndia = [
    "Mumbai",
    "Delhi",
    "Bengaluru",
    "Ahmedabad",
    "Hyderabad",
    "Chennai",
    "Kolkata",
    "Pune",
    "Jaipur",
    "Surat",
  ];

  // --- Current user UID for call filtering ---
  String? _currentUserUid;

  // --- Whereby API Key ---
  final String _wherebyApiKey =
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmFwcGVhci5pbiIsImF1ZCI6Imh0dHBzOi8vYXBpLmFwcGVhci5pbi92MSIsImV4cCI6OTAwNzE5OTI1NDc0MDk5MSwiaWF0IjoxNzQ0MTQzODIwLCJvcmdhbml6YXRpb25JZCI6MzEzNzYxLCJqdGkiOiI2MWE0MjY3Zi03MzNjLTQ1NjAtOTE0NS03MjE3NWMzMWE4YTIifQ.E_WD2GSQAQoaq0gdAyy1JXR8py9k8qLGD8fTDtq7oNE";

  @override
  void initState() {
    super.initState();
    _loadCurrentUserUid();
    _initializePermissions();
  }

  Future<void> _loadCurrentUserUid() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _currentUserUid = prefs.getString('uid') ?? "";
    });
  }

  Future<void> _initializePermissions() async {
    await [Permission.camera, Permission.microphone].request();
  }

  Future<void> _joinWherebyMeeting(String meetingId, String userName) async {
    try {
      print("Attempting to join Whereby meeting with ID: $meetingId");
      final docSnapshot = await FirebaseFirestore.instance
          .collection('advoconnect_calls')
          .doc(meetingId)
          .get();
      String roomUrl = docSnapshot.data()?['roomUrl'] as String? ?? '';

      if (roomUrl.isEmpty) {
        print("No existing roomUrl found, creating new one for meeting ID: $meetingId");
        final now = DateTime.now().toUtc();
        final endTime = now.add(const Duration(minutes: 60));
        final response = await http.post(
          Uri.parse('https://api.whereby.dev/v1/meetings'),
          headers: {
            'Authorization': 'Bearer $_wherebyApiKey',
            'Content-Type': 'application/json',
          },
          body: jsonEncode({
            'startDate': now.toIso8601String(),
            'endDate': endTime.toIso8601String(),
          }),
        );

        if (response.statusCode == 201) {
          final data = jsonDecode(response.body);
          roomUrl = data['roomUrl'];
          print("Created and saved room URL: $roomUrl");
          await FirebaseFirestore.instance
              .collection('advoconnect_calls')
              .doc(meetingId)
              .set({'roomUrl': roomUrl}, SetOptions(merge: true));
          await Future.delayed(const Duration(milliseconds: 500));
        } else {
          print("Error response: Status ${response.statusCode}, Full response: ${response.body}");
          throw 'Failed to create Whereby room: ${response.body}';
        }
      } else {
        print("Using existing roomUrl: $roomUrl");
      }

      if (await canLaunch(roomUrl)) {
        await launch(roomUrl);
        print("Launched Whereby meeting at: $roomUrl");
      } else {
        throw 'Could not launch $roomUrl';
      }
    } catch (error) {
      print("Error joining Whereby meeting: $error");
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Failed to join meeting: $error")),
        );
      }
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    selectedLanguage = languageProvider.selectedLanguage;
    try {
      translatedTitle = await TranslationService.translate("Lawyers", selectedLanguage);
      translatedStateLabel = await TranslationService.translate("State", selectedLanguage);
      translatedCityLabel = await TranslationService.translate("City", selectedLanguage);
      translatedPracticeLabel = await TranslationService.translate("Practice", selectedLanguage);
      if (mounted) setState(() {});
    } catch (e) {
      debugPrint("Translation Error: $e");
    }
  }

  Future<void> _selectState() async {
    String localQuery = "";
    await showModalBottomSheet(
      context: context,
      builder: (context) {
        return StatefulBuilder(builder: (context, setModalState) {
          final filteredStates = statesOfIndia.where((s) => s.toLowerCase().contains(localQuery.toLowerCase())).toList();
          return Container(
            height: 400,
            padding: const EdgeInsets.all(12),
            color: Colors.white,
            child: Column(
              children: [
                TextField(
                  decoration: InputDecoration(
                    hintText: "Search states...",
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                  ),
                  onChanged: (value) {
                    setModalState(() {
                      localQuery = value;
                    });
                  },
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: ListView.builder(
                    itemCount: filteredStates.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(filteredStates[index]),
                        onTap: () {
                          setState(() {
                            selectedState = filteredStates[index];
                          });
                          Navigator.pop(context);
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        });
      },
    );
  }

  Future<void> _selectCity() async {
    if (selectedState == 'State') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please select your state first")),
      );
      return;
    }
    String localQuery = "";
    await showModalBottomSheet(
      context: context,
      builder: (context) {
        return StatefulBuilder(builder: (context, setModalState) {
          final filteredCities = citiesOfIndia.where((c) => c.toLowerCase().contains(localQuery.toLowerCase())).toList();
          return Container(
            height: 400,
            padding: const EdgeInsets.all(12),
            color: Colors.white,
            child: Column(
              children: [
                TextField(
                  decoration: InputDecoration(
                    hintText: "Search cities...",
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                  ),
                  onChanged: (value) {
                    setModalState(() {
                      localQuery = value;
                    });
                  },
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: ListView.builder(
                    itemCount: filteredCities.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(filteredCities[index]),
                        onTap: () {
                          setState(() {
                            selectedCity = filteredCities[index];
                          });
                          Navigator.pop(context);
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        });
      },
    );
  }

  Future<void> _selectPractice() async {
    String localQuery = "";
    final List<String> practices = [
      "Corporate",
      "Criminal",
      "Family",
      "Civil",
      translatedPracticeLabel,
    ];
    await showModalBottomSheet(
      context: context,
      builder: (context) {
        return StatefulBuilder(builder: (context, setModalState) {
          final filteredPractices = practices.where((p) => p.toLowerCase().contains(localQuery.toLowerCase())).toList();
          return Container(
            height: 400,
            padding: const EdgeInsets.all(12),
            color: Colors.white,
            child: Column(
              children: [
                TextField(
                  decoration: InputDecoration(
                    hintText: "Search practice...",
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                  ),
                  onChanged: (value) {
                    setModalState(() {
                      localQuery = value;
                    });
                  },
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: ListView.builder(
                    itemCount: filteredPractices.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(filteredPractices[index]),
                        onTap: () {
                          setState(() {
                            selectedPractice = filteredPractices[index];
                          });
                          Navigator.pop(context);
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        });
      },
    );
  }

  Widget _buildFilterButton(String selectedValue, String defaultLabel, Function() onPressed) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        side: const BorderSide(color: Colors.blue),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        minimumSize: const Size(90, 36),
      ),
      child: Text(
        selectedValue == defaultLabel ? defaultLabel : selectedValue,
        style: const TextStyle(color: Colors.blue, fontSize: 14),
      ),
    );
  }

  List<Map<String, dynamic>> _applyFilters(List<Map<String, dynamic>> lawyers) {
    return lawyers.where((lawyer) {
      bool matchesName = searchQuery.isEmpty ||
          (lawyer.containsKey('name') && lawyer['name'].toString().toLowerCase().contains(searchQuery.toLowerCase()));
      bool matchesState = selectedState == 'State' ||
          (lawyer.containsKey('state') && lawyer['state'].toString().toLowerCase().contains(selectedState.toLowerCase()));
      bool matchesCity = selectedCity == 'City' ||
          (lawyer.containsKey('city') && lawyer['city'].toString().toLowerCase().contains(selectedCity.toLowerCase()));
      bool matchesPractice = selectedPractice == 'Practice' ||
          (lawyer.containsKey('lawyerType') && lawyer['lawyerType'].toString().toLowerCase().contains(selectedPractice.toLowerCase()));
      return matchesName && matchesState && matchesCity && matchesPractice;
    }).toList();
  }

  // --- Video Call Card Widget (for Upcoming & Past Calls) ---
  Widget _buildCallCard({
    required String date,
    required String timeSlot,
    required String callId,
    required String lawyerName,
    required String lawyerType,
    required String profileImageUrl,
    required int feesPerHour,
    required bool isUpcoming,
    required bool isActive,
  }) {
    final callDate = DateTime.tryParse(date) ?? DateTime.now();
    final formattedDate = DateFormat('dd MMM, yyyy').format(callDate);
    final formattedTime = DateFormat('hh:mm a').format(DateFormat('HH:mm').parse(timeSlot));

    return FutureBuilder<DocumentSnapshot>(
      future: FirebaseFirestore.instance.collection('advoconnect_calls').doc(callId).get(),
      builder: (context, callSnapshot) {
        if (callSnapshot.hasError) {
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade800),
            ),
            child: Text("Error loading call details: ${callSnapshot.error}"),
          );
        }
        if (!callSnapshot.hasData) {
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade800),
            ),
            child: const Text("No call data available"),
          );
        }

        final callData = callSnapshot.data!.data() as Map<String, dynamic>? ?? {};
        final userId = callData['userId'] ?? '';
        final sessionDuration = callData['sessionDuration'] ?? 60;

        return FutureBuilder<DocumentSnapshot>(
          future: FirebaseFirestore.instance.collection('users').doc(userId).get(),
          builder: (context, userSnapshot) {
            if (userSnapshot.hasError) {
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade800),
                ),
                child: Text("Error loading user details: ${userSnapshot.error}"),
              );
            }
            if (!userSnapshot.hasData) {
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade800),
                ),
                child: const Text("No user data available"),
              );
            }

            final userData = userSnapshot.data!.data() as Map<String, dynamic>? ?? {};
            final userName = userData['name'] ?? 'Unknown';
            final userPhotoUrl = userData['photoURL'] ?? '';
            final userProfession = userData['profession'] ?? 'Unknown';
            final userBackgroundImage = userPhotoUrl.isNotEmpty
                ? NetworkImage(userPhotoUrl) as ImageProvider
                : const AssetImage('assets/default_avatar.png') as ImageProvider;

            // Check call activity with session duration
            final isCallActive = _isCallActive(date, timeSlot, sessionDuration);
            print("Debug - isUpcoming: $isUpcoming, isCallActive: $isCallActive, isActive: $isActive");

            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.shade800),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          CircleAvatar(
                            radius: 20,
                            backgroundImage: userBackgroundImage,
                            child: userPhotoUrl.isEmpty
                                ? Text(userName.isNotEmpty ? userName[0].toUpperCase() : 'U',
                                    style: const TextStyle(fontSize: 20))
                                : null,
                          ),
                          const SizedBox(width: 8),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                userName,
                                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                              Text(
                                userProfession,
                                style: const TextStyle(fontSize: 14, color: Colors.grey),
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                            ],
                          ),
                        ],
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                lawyerName,
                                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                              Text(
                                lawyerType,
                                style: const TextStyle(fontSize: 14, color: Colors.grey),
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                              Text(
                                '₹$feesPerHour / session',
                                style: const TextStyle(fontSize: 14, color: Colors.green),
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                            ],
                          ),
                          const SizedBox(width: 8),
                          CircleAvatar(
                            radius: 20,
                            backgroundImage: profileImageUrl.isNotEmpty
                                ? NetworkImage(profileImageUrl)
                                : const AssetImage('assets/default_avatar.png'),
                            child: profileImageUrl.isEmpty
                                ? Text(lawyerName.isNotEmpty ? lawyerName[0].toUpperCase() : 'L',
                                    style: const TextStyle(fontSize: 20))
                                : null,
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.calendar_today, color: Colors.blue),
                                const SizedBox(width: 4),
                                Text('Date: $formattedDate',
                                    style: const TextStyle(fontSize: 14, color: Colors.blue)),
                              ],
                            ),
                          ),
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.access_time, color: Colors.blue),
                                const SizedBox(width: 4),
                                Text('Time: $formattedTime',
                                    style: const TextStyle(fontSize: 14, color: Colors.blue)),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.timer, color: Colors.blue),
                                const SizedBox(width: 4),
                                Text(
                                  'Duration: $sessionDuration minutes',
                                  style: const TextStyle(fontSize: 14, color: Colors.blue),
                                ),
                              ],
                            ),
                          ),
                          Expanded(
                            child: isUpcoming && isCallActive
                                ? ElevatedButton(
                                    onPressed: () async {
                                      print("Joining meeting for callId: $callId, user: $userName");
                                      try {
                                        await _joinWherebyMeeting(callId, userName);
                                        print("Meeting joined successfully");
                                      } catch (e) {
                                        print("Error joining meeting: $e");
                                      }
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.blue,
                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                    ),
                                    child: const Text(
                                      "JOIN",
                                      style: TextStyle(
                                          fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white),
                                    ),
                                  )
                                : isUpcoming
                                    ? ElevatedButton(
                                        onPressed: null,
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.black,
                                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                        ),
                                        child: const Text(
                                          "JOIN",
                                          style: TextStyle(
                                              fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white),
                                        ),
                                      )
                                    : const Text(
                                        'Call Completed',
                                        style: TextStyle(
                                            fontSize: 14, fontWeight: FontWeight.w600, color: Colors.grey),
                                      ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  // --- Lawyers Tab ---
  Widget _buildLawyersTab() {
    return Column(
      children: [
        Container(
          height: MediaQuery.of(context).size.height * 0.055,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(4),
            border: Border.all(color: Colors.blue),
          ),
          child: Row(
            children: [
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 8),
                child: Icon(Icons.search, color: Colors.blue, size: 20),
              ),
              Expanded(
                child: TextField(
                  style: const TextStyle(color: Colors.blue, fontSize: 14),
                  decoration: const InputDecoration(
                    hintText: 'Search by name...',
                    hintStyle: TextStyle(color: Colors.blue, fontSize: 14),
                    border: InputBorder.none,
                  ),
                  onChanged: (value) {
                    setState(() {
                      searchQuery = value;
                    });
                  },
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildFilterButton(selectedState, translatedStateLabel, _selectState),
              _buildFilterButton(selectedCity, translatedCityLabel, _selectCity),
              _buildFilterButton(selectedPractice, translatedPracticeLabel, _selectPractice),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Expanded(
          child: FutureBuilder<List<Map<String, dynamic>>>(
            future: fetchAvailableLawyers(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Center(child: Text("Error: ${snapshot.error}"));
              } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                return const Center(child: Text("No lawyers found."));
              } else {
                final lawyers = _applyFilters(snapshot.data!);
                return ListView.builder(
                  itemCount: lawyers.length,
                  itemBuilder: (context, index) => _buildLawyerCard(lawyers[index]),
                );
              }
            },
          ),
        ),
      ],
    );
  }

  // --- Upcoming Calls Tab ---
  Widget _buildUpcomingCallsTab() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('advoconnect_calls')
          .where('userId', isEqualTo: _currentUserUid)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text("Error: ${snapshot.error}"));
        }
        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Center(child: Text("No upcoming calls."));
        }
        final calls = snapshot.data!.docs.where((doc) {
          final data = doc.data() as Map<String, dynamic>;
          final date = data['date'] ?? "";
          final timeSlot = data['timeSlot'] ?? "";
          final sessionDuration = data['sessionDuration'] ?? 60;
          final callEndTime = _calculateCallEndTime(date, timeSlot, sessionDuration);
          return callEndTime.isAfter(DateTime.now());
        }).toList();
        if (calls.isEmpty) {
          return const Center(child: Text("No upcoming calls."));
        }
        return FutureBuilder<DocumentSnapshot>(
          future: FirebaseFirestore.instance.collection('advoconnect_lawyers').doc(calls[0]['lawyerId']).get(),
          builder: (context, lawyerSnapshot) {
            if (lawyerSnapshot.hasError || !lawyerSnapshot.hasData) {
              return Center(child: Text("Error loading lawyer info: ${lawyerSnapshot.error}"));
            }
            final lawyerData = lawyerSnapshot.data!.data() as Map<String, dynamic>? ?? {};
            final lawyerName = lawyerData['name'] ?? "Lawyer";
            final lawyerType = lawyerData['lawyerType'] ?? "Unknown";
            final profileImageUrl = lawyerData['profileImageUrl'] ?? "";
            final feesPerHour = lawyerData['feesPerHour'] ?? 0;

            return ListView.builder(
              itemCount: calls.length,
              itemBuilder: (context, index) {
                final data = calls[index].data() as Map<String, dynamic>;
                final callId = calls[index].id;
                final date = data['date'] ?? "";
                final timeSlot = data['timeSlot'] ?? "";
                final sessionDuration = data['sessionDuration'] ?? 60;
                final isActive = _isCallActive(date, timeSlot, sessionDuration);

                return _buildCallCard(
                  date: date,
                  timeSlot: timeSlot,
                  callId: callId,
                  lawyerName: lawyerName,
                  lawyerType: lawyerType,
                  profileImageUrl: profileImageUrl,
                  feesPerHour: feesPerHour,
                  isUpcoming: true,
                  isActive: isActive,
                );
              },
            );
          },
        );
      },
    );
  }

  // --- Past Calls Tab ---
  Widget _buildPastCallsTab() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('advoconnect_calls')
          .where('userId', isEqualTo: _currentUserUid)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text("Error: ${snapshot.error}"));
        }
        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Center(child: Text("No past calls."));
        }
        final calls = snapshot.data!.docs.where((doc) {
          final data = doc.data() as Map<String, dynamic>;
          final date = data['date'] ?? "";
          final timeSlot = data['timeSlot'] ?? "";
          final sessionDuration = data['sessionDuration'] ?? 60;
          final callEndTime = _calculateCallEndTime(date, timeSlot, sessionDuration);
          return callEndTime.isBefore(DateTime.now());
        }).toList();
        if (calls.isEmpty) {
          return const Center(child: Text("No past calls."));
        }
        return FutureBuilder<DocumentSnapshot>(
          future: FirebaseFirestore.instance.collection('advoconnect_lawyers').doc(calls[0]['lawyerId']).get(),
          builder: (context, lawyerSnapshot) {
            if (lawyerSnapshot.hasError || !lawyerSnapshot.hasData) {
              return Center(child: Text("Error loading lawyer info: ${lawyerSnapshot.error}"));
            }
            final lawyerData = lawyerSnapshot.data!.data() as Map<String, dynamic>? ?? {};
            final lawyerName = lawyerData['name'] ?? "Lawyer";
            final lawyerType = lawyerData['lawyerType'] ?? "Unknown";
            final profileImageUrl = lawyerData['profileImageUrl'] ?? "";
            final feesPerHour = lawyerData['feesPerHour'] ?? 0;

            return ListView.builder(
              itemCount: calls.length,
              itemBuilder: (context, index) {
                final data = calls[index].data() as Map<String, dynamic>;
                final callId = calls[index].id;
                final date = data['date'] ?? "";
                final timeSlot = data['timeSlot'] ?? "";
                final sessionDuration = data['sessionDuration'] ?? 60;

                return _buildCallCard(
                  date: date,
                  timeSlot: timeSlot,
                  callId: callId,
                  lawyerName: lawyerName,
                  lawyerType: lawyerType,
                  profileImageUrl: profileImageUrl,
                  feesPerHour: feesPerHour,
                  isUpcoming: false,
                  isActive: false,
                );
              },
            );
          },
        );
      },
    );
  }

  // --- Lawyer Card Widget (for Lawyers Tab) ---
  Widget _buildLawyerCard(Map<String, dynamic> lawyer) {
    final String name = lawyer['name'] ?? 'Unknown';
    final String degree = lawyer['degree'] ?? 'Not Listed';
    final String lawyerType = lawyer['lawyerType'] ?? 'Unknown Law Type';
    final String state = lawyer['state'] ?? '';
    final String city = lawyer['city'] ?? '';
    final int? fees = lawyer['feesPerHour'];
    final String profileUrl = lawyer['profileImageUrl'] ?? '';

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.blue, width: 1.2),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: const Color(0xFFE5E7EB),
                backgroundImage: profileUrl.isNotEmpty ? NetworkImage(profileUrl) : null,
                child: profileUrl.isEmpty ? const Icon(Icons.person, color: Color(0xFF9CA3AF), size: 28) : null,
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: Color(0xFF111827)),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "Degree: $degree",
                    style: const TextStyle(fontSize: 14, color: Color(0xFF6B7280)),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text(
                'Type of Law Practiced: ',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFF111827)),
              ),
              Flexible(
                child: Text(
                  lawyerType,
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.normal, color: Color(0xFF374151)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              const Icon(Icons.location_on, size: 16, color: Color(0xFF9CA3AF)),
              const SizedBox(width: 4),
              Text(
                '$state, $city',
                style: const TextStyle(fontSize: 13, color: Color(0xFF6B7280)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                fees != null ? '₹${fees.toString()}/session per hour' : 'Not Listed',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: Colors.black),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => LawyerDetailScreen(lawyerData: lawyer)),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF3B82F6),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                ),
                child: const Text('Book Consultation', style: TextStyle(fontSize: 12, color: Colors.white)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // --- Helper method to check if a call is active ---
  bool _isCallActive(String dateStr, String timeSlot, int sessionDuration) {
    final now = DateTime.now();
    try {
      final callDate = DateTime.parse(dateStr);
      final callTime = DateFormat('HH:mm').parse(timeSlot); // Parse as 24-hour format
      final callStartTime = DateTime(callDate.year, callDate.month, callDate.day, callTime.hour, callTime.minute);
      final callEndTime = callStartTime.add(Duration(minutes: sessionDuration));
      final isTimeMatched = now.isAfter(callStartTime) && now.isBefore(callEndTime);
      return isTimeMatched;
    } catch (e) {
      print("Error in _isCallActive: $e");
      return false;
    }
  }

  // --- Helper to calculate call end time ---
  DateTime _calculateCallEndTime(String dateStr, String timeSlot, int sessionDuration) {
    final callDate = DateTime.parse(dateStr);
    final callTime = DateFormat('HH:mm').parse(timeSlot);
    final callStartTime = DateTime(callDate.year, callDate.month, callDate.day, callTime.hour, callTime.minute);
    final effectiveSessionDuration = sessionDuration > 0 ? sessionDuration : 60;
    return callStartTime.add(Duration(minutes: effectiveSessionDuration));
  }

  // --- Main Build ---
  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    return DefaultTabController(
      length: 3,
      child: CustomAppBar(
        title: translatedTitle,
        icon: Icons.how_to_vote,
        body: Scaffold(
          backgroundColor: const Color(0xFFF9FAFB),
          appBar: TabBar(
            tabs: const [
              Tab(text: "Lawyers"),
              Tab(text: "Upcoming Calls"),
              Tab(text: "Past Calls"),
            ],
            labelColor: Colors.blue.shade900,
            unselectedLabelColor: Colors.blue.shade300,
            indicatorColor: Colors.blue,
          ),
          body: TabBarView(
            children: [
              _buildLawyersTab(),
              _buildUpcomingCallsTab(),
              _buildPastCallsTab(),
            ],
          ),
        ),
      ),
    );
  }
}