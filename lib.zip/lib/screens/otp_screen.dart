import 'package:flutter/material.dart';
import 'package:project/screens/confetti_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:project/auth/profile_upload.dart';

class OTPVerificationPage extends StatefulWidget {
  final String phoneNumber;
  final String uid; // ✅ Store UID to associate the phone verification with the correct user
  String verificationId; // ✅ Remove 'final' so it can be updated

  OTPVerificationPage({required this.phoneNumber, required this.uid, required this.verificationId, super.key});


  @override
  _OTPVerificationPageState createState() => _OTPVerificationPageState();
}

class _OTPVerificationPageState extends State<OTPVerificationPage> {
  bool _isResendEnabled = false;


  final List<TextEditingController> _otpControllers =
      List.generate(6, (_) => TextEditingController());

  String _timerText = "180";

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  void _startTimer() {
    int timeRemaining = 180;
    setState(() {
      _isResendEnabled = false;
    });

    Future.delayed(const Duration(seconds: 1), () async {
      while (timeRemaining > 0) {
        await Future.delayed(const Duration(seconds: 1));
        if (mounted) {
          setState(() {
            timeRemaining--;
            _timerText = timeRemaining.toString();
          });
        }
      }

      if (mounted) {
        setState(() {
          _isResendEnabled = true;
        });
      }
    });
  }

  /// ✅ **Verifies OTP & Updates Firestore**
void _verifyOTP() async {
  String otp = _otpControllers.map((controller) => controller.text).join();

  if (otp.length != 6) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Invalid OTP. Please enter a 6-digit code.'),
        backgroundColor: Colors.red,
      ),
    );
    return;
  }

  try {
    // ✅ Authenticate user with OTP
    PhoneAuthCredential credential = PhoneAuthProvider.credential(
      verificationId: widget.verificationId, 
      smsCode: otp,
    );

    UserCredential userCredential =
        await FirebaseAuth.instance.signInWithCredential(credential);

    // ✅ Ensure the user UID matches Firestore document
    String userUid = widget.uid; // Get UID from constructor

    // ✅ Update Firestore: Mark phone as verified & profile as complete
    await FirebaseFirestore.instance.collection('users').doc(userUid).update({
      "isPhoneVerified": true,
      "isProfileComplete": true,
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("✅ Phone Verified Successfully!"), backgroundColor: Colors.green),
    );

    // ✅ Navigate to profile completion screen
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => ProfileCreatedPage(),
      ),
    );
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("❌ OTP Verification Failed: $e")),
    );
  }
}

void _resendOTP() async {
  try {
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: widget.phoneNumber,
      forceResendingToken: ProfileUploadService.resendToken, // ✅ Use saved token to avoid reCAPTCHA
      verificationCompleted: (PhoneAuthCredential credential) async {
        await FirebaseAuth.instance.signInWithCredential(credential);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("✅ Auto-verification complete!")),
        );
      },
      verificationFailed: (FirebaseAuthException e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("❌ Failed to resend OTP: ${e.message}")),
        );
      },
      codeSent: (String verificationId, int? resendToken) {
        setState(() {
          widget.verificationId = verificationId; // ✅ Updates verification ID
          _isResendEnabled = false;
          _startTimer();
        });

        // ✅ Save new resendToken in backend for future resends
        ProfileUploadService.resendToken = resendToken;

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("📩 OTP Resent Successfully!"), backgroundColor: Colors.orange),
        );
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        print("⏳ Auto retrieval timeout.");
      },
    );
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("❌ Error while resending OTP: $e")),
    );
  }
}

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final bool isSmallScreen = size.width < 400;
    final double fieldWidth = size.width * (isSmallScreen ? 0.9 : 0.8);
    final double otpBoxWidth = size.width * 0.12;
    final double buttonHeight = isSmallScreen ? 50 : 60;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: size.width * 0.05),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: IconButton(
                      icon: const Icon(Icons.arrow_back, color: Colors.grey),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  ),
                  const SizedBox(height: 30),
                  Text(
                    'OTP Verification',
                    style: TextStyle(
                      fontSize: isSmallScreen ? 26 : 32,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 15),
                  Text(
                    'We have sent a code to ${widget.phoneNumber}',
                    style: TextStyle(
                      fontSize: isSmallScreen ? 16 : 18,
                      color: Colors.grey,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 5),
                  Text(
                    'Expires in: $_timerText seconds',
                    style: TextStyle(
                      fontSize: isSmallScreen ? 16 : 18,
                      color: const Color.fromARGB(255, 44, 101, 224),
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 40),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: List.generate(
                      6,
                      (index) => SizedBox(
                        width: isSmallScreen ? 40 : otpBoxWidth,
                        child: TextField(
                          controller: _otpControllers[index],
                          keyboardType: TextInputType.number,
                          textAlign: TextAlign.center,
                          maxLength: 1,
                          style: TextStyle(
                            fontSize: isSmallScreen ? 18 : 24,
                            fontWeight: FontWeight.bold,
                          ),
                          decoration: InputDecoration(
                            counterText: '',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          onChanged: (value) {
                            if (value.isNotEmpty && index < 5) {
                              FocusScope.of(context).nextFocus();
                            } else if (value.isEmpty && index > 0) {
                              FocusScope.of(context).previousFocus();
                            }
                          },
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 40),
                  SizedBox(
                    width: fieldWidth,
                    child: ElevatedButton(
                      onPressed: _verifyOTP,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color.fromARGB(255, 44, 101, 224),
                        padding: EdgeInsets.symmetric(vertical: buttonHeight * 0.2),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                        minimumSize: Size.fromHeight(buttonHeight),
                      ),
                      child: Text(
                        'Verify OTP',
                        style: TextStyle(fontSize: isSmallScreen ? 18 : 20, color: Colors.white),
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),
                  TextButton(
                    onPressed: _isResendEnabled ? _resendOTP : null,
                    child: Text(
                      'Resend OTP',
                      style: TextStyle(
                        fontSize: isSmallScreen ? 16 : 18,
                        color: _isResendEnabled ? Colors.blue : Colors.grey,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
