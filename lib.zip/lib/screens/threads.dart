import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:project/models/post.dart';
import 'package:project/services/comment_service.dart';
import 'package:project/widgets/post_card.dart';
import 'package:project/widgets/comment_card.dart';
import 'package:project/widgets/custom_appbar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:project/services/translation_service.dart';
import 'package:project/providers/language_provider.dart';
import 'package:provider/provider.dart';

class ThreadScreen extends StatefulWidget {
  final Post post;
  const ThreadScreen({super.key, required this.post});

  @override
  State<ThreadScreen> createState() => _ThreadScreenState();
}

class _ThreadScreenState extends State<ThreadScreen> {
  final TextEditingController _textController = TextEditingController();

  // For replying to a top-level comment.
  String replyToCommentId = "";
  String replyToUserName = "";

  // Current user ID from SharedPreferences.
  String currentUserId = "";

  // Translation variables.
  String translatedAppBarTitle = "Thread";
  String translatedNoComments = "No comments yet.";
  String translatedReplyHint = "Add a comment...";

  @override
  void initState() {
    super.initState();
    _loadCurrentUser();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLanguage = languageProvider.selectedLanguage;
    try {
      translatedAppBarTitle = await TranslationService.translate("Thread", selectedLanguage);
      translatedNoComments = await TranslationService.translate("No comments yet.", selectedLanguage);
      translatedReplyHint = await TranslationService.translate("Add a comment...", selectedLanguage);
      if (mounted) setState(() {});
    } catch (e) {
      print("Translation error in ThreadScreen: $e");
    }
  }

  Future<void> _loadCurrentUser() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      currentUserId = prefs.getString('uid') ?? "";
    });
  }

  /// Posts text as a new comment or as a reply.
  Future<void> _postText() async {
    final text = _textController.text.trim();
    if (text.isEmpty) return;

    final prefs = await SharedPreferences.getInstance();
    final uid = prefs.getString('uid') ?? "";
    final name = prefs.getString('name') ?? "";
    final photoURL = prefs.getString('photoURL') ?? "";

    if (replyToCommentId.isEmpty) {
      // Post a top-level comment.
      await CommentService().createComment(
        postId: widget.post.id,
        uid: uid,
        name: name,
        photoUrl: photoURL,
        commentText: text,
        repliedTo: "",
        repliedContext: "post",
      );
    } else {
      // Post a reply to the specified top-level comment.
      await CommentService().createReply(
        postId: widget.post.id,
        commentId: replyToCommentId,
        uid: uid,
        name: name,
        photoUrl: photoURL,
        replyText: text,
        repliedTo: replyToUserName,
        repliedContext: "comment",
      );
      // Clear reply mode.
      setState(() {
        replyToCommentId = "";
        replyToUserName = "";
      });
    }
    _textController.clear();
  }

  /// Toggle reaction for a top-level comment.
  Future<void> _toggleCommentReaction(String postId, String commentId, String reaction, String currentUserId) async {
    await CommentService().toggleCommentReaction(
      postId: postId,
      commentId: commentId,
      reaction: reaction,
      uid: currentUserId,
    );
  }

  /// Toggle reaction for a reply.
  Future<void> _toggleReplyReaction(String postId, String parentCommentId, String replyId, String reaction, String currentUserId) async {
    await CommentService().toggleReplyReaction(
      postId: postId,
      commentId: parentCommentId,
      replyId: replyId,
      reaction: reaction,
      uid: currentUserId,
    );
  }

  /// Sets the reply target (for top-level comments).
  void _setReplyTarget(String commentId, String userName) {
    setState(() {
      replyToCommentId = commentId;
      replyToUserName = userName;
    });
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    return CustomAppBar(
      title: translatedAppBarTitle,
      icon: Icons.arrow_back,
      // Pass the full body as a parameter.
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Scrollbar(
                thumbVisibility: true,
                child: SingleChildScrollView(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05, vertical: 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // The post details at the top.
                        PostCard(post: widget.post),
                        const Divider(thickness: 1, color: Color.fromARGB(255, 7, 7, 7)),
                        // Real-time top-level comment list.
                        StreamBuilder<QuerySnapshot>(
                          stream: FirebaseFirestore.instance
                              .collection('forum_posts')
                              .doc(widget.post.id)
                              .collection('comments')
                              .orderBy('timestamp', descending: true)
                              .snapshots(),
                          builder: (context, snapshot) {
                            if (!snapshot.hasData) {
                              return const SizedBox.shrink();
                            }
                            final docs = snapshot.data!.docs;
                            if (docs.isEmpty) {
                              return Center(child: Text(translatedNoComments));
                            }
                            return Column(
                              children: docs.map((doc) {
                                final data = doc.data() as Map<String, dynamic>;
                                if (data['timestamp'] == null) {
                                  return const SizedBox.shrink();
                                }
                                return Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    // Top-level comment.
                                    CommentCard(
                                      postId: widget.post.id,
                                      commentId: doc.id,
                                      commenterName: data['name'] ?? '',
                                      commenterPhotoUrl: data['photoURL'] ?? '',
                                      commentText: data['commentText'] ?? '',
                                      repliedTo: "",
                                      repliedContext: "post",
                                      postAuthorName: widget.post.name,
                                      timestamp: data['timestamp'] is Timestamp
                                          ? data['timestamp'] as Timestamp
                                          : Timestamp.now(),
                                      likeCount: data['likes'] ?? 0,
                                      dislikeCount: data['dislikes'] ?? 0,
                                      currentUserId: currentUserId,
                                      parentCommentId: "",
                                      isReply: false,
                                      onToggleReaction: _toggleCommentReaction,
                                      onReply: () {
                                        _setReplyTarget(doc.id, data['name'] ?? '');
                                      },
                                    ),
                                    // One-level replies.
                                    StreamBuilder<QuerySnapshot>(
                                      stream: FirebaseFirestore.instance
                                          .collection('forum_posts')
                                          .doc(widget.post.id)
                                          .collection('comments')
                                          .doc(doc.id)
                                          .collection('replies')
                                          .orderBy('timestamp', descending: true)
                                          .snapshots(),
                                      builder: (context, replySnapshot) {
                                        if (!replySnapshot.hasData) {
                                          return const SizedBox.shrink();
                                        }
                                        final replyDocs = replySnapshot.data!.docs;
                                        if (replyDocs.isEmpty) {
                                          return const SizedBox.shrink();
                                        }
                                        return Column(
                                          children: replyDocs.map((replyDoc) {
                                            final replyData = replyDoc.data() as Map<String, dynamic>;
                                            if (replyData['timestamp'] == null) {
                                              return const SizedBox.shrink();
                                            }
                                            return Padding(
                                              padding: const EdgeInsets.only(left: 16.0),
                                              child: CommentCard(
                                                postId: widget.post.id,
                                                commentId: replyDoc.id,
                                                commenterName: replyData['name'] ?? '',
                                                commenterPhotoUrl: replyData['photoURL'] ?? '',
                                                commentText: replyData['commentText'] ?? '',
                                                repliedTo: replyData['repliedTo'] ?? '',
                                                repliedContext: replyData['repliedContext'] ?? 'comment',
                                                postAuthorName: "",
                                                timestamp: replyData['timestamp'] is Timestamp
                                                    ? replyData['timestamp'] as Timestamp
                                                    : Timestamp.now(),
                                                likeCount: replyData['likes'] ?? 0,
                                                dislikeCount: replyData['dislikes'] ?? 0,
                                                currentUserId: currentUserId,
                                                parentCommentId: doc.id,
                                                isReply: true,
                                                onToggleReaction: (postId, commentId, reaction, currentUserId) async {
                                                  await _toggleReplyReaction(
                                                    widget.post.id,
                                                    doc.id,
                                                    replyDoc.id,
                                                    reaction,
                                                    currentUserId,
                                                  );
                                                },
                                                onReply: () {},
                                              ),
                                            );
                                          }).toList(),
                                        );
                                      },
                                    ),
                                    const Divider(height: 1, color: Colors.grey),
                                  ],
                                );
                              }).toList(),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            // Fixed comment input at the bottom.
            Container(
              color: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _textController,
                      decoration: InputDecoration(
                        hintText: replyToCommentId.isNotEmpty
                            ? "Replying to @$replyToUserName..."
                            : translatedReplyHint,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30),
                          borderSide: const BorderSide(color: Colors.grey),
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.send),
                    onPressed: _postText,
                  ),
                  if (replyToCommentId.isNotEmpty)
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () {
                        setState(() {
                          replyToCommentId = "";
                          replyToUserName = "";
                        });
                      },
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
