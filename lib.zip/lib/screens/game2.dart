import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../data/game2_data.dart'; // Ensure this file defines chooseYourFateDataset properly
import 'factsydk_game.dart'; // For the Exit button navigation

class ChooseYourFateGame extends StatefulWidget {
  const ChooseYourFateGame({super.key});

  @override
  State<ChooseYourFateGame> createState() => _ChooseYourFateGameState();
}

class _ChooseYourFateGameState extends State<ChooseYourFateGame> {
  List<Map<String, dynamic>> _selectedQuestions = [];
  int currentQuestionIndex = 0;
  int selectedOptionIndex = 0;
  int score = 0;
  int timeLeft = 45;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    _loadRandomQuestions();
    _startTimer();
  }

  void _loadRandomQuestions() {
    // Shuffle and select 10 random questions
    final shuffled = List<Map<String, dynamic>>.from(chooseYourFateDataset)..shuffle();
    _selectedQuestions = shuffled.take(10).toList();
    setState(() {
      currentQuestionIndex = 0;
      selectedOptionIndex = 0;
      score = 0;
      timeLeft = 45;
    });
  }

  // Timer countdown
  void _startTimer() {
    timer?.cancel();
    timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (timeLeft == 0) {
        timer.cancel();
        _submitAnswer(null);
      } else {
        setState(() {
          timeLeft--;
        });
      }
    });
  }

  // Swipe up to move to the next option
  void _onSwipeUp() {
    final options = _selectedQuestions[currentQuestionIndex]['options'] as List<String>;
    if (selectedOptionIndex < options.length - 1) {
      setState(() {
        selectedOptionIndex++;
      });
    }
  }

  // Swipe down to move to the previous option
  void _onSwipeDown() {
    if (selectedOptionIndex > 0) {
      setState(() {
        selectedOptionIndex--;
      });
    }
  }

  // Submit answer when the Lock In button is tapped.
  void _submitAnswer(int? tappedIndex) {
    final correct = _selectedQuestions[currentQuestionIndex]['correctOption'] as int;
    final isCorrect = tappedIndex != null && tappedIndex == correct;

    setState(() {
      if (isCorrect) {
        score += 50;
      } else {
        score -= 20;
      }
    });

    _showResultDialog(isCorrect);
  }

  // Show a dialog with feedback for the current question.
  void _showResultDialog(bool isCorrect) {
    final isLast = currentQuestionIndex == _selectedQuestions.length - 1;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(isCorrect ? 'Correct!' : 'Wrong!'),
        content: Text(
          isCorrect
              ? 'Great job! Your score is now $score.'
              : 'That wasn’t the best move. Your score is now $score.',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 18),
        ),
        actions: [
          if (!isLast)
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                _nextQuestion();
              },
              child: const Text("Next"),
            ),
          if (isLast)
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                _showFinalScore();
              },
              child: const Text("Finish"),
            ),
        ],
      ),
    );
  }

  void _nextQuestion() {
    setState(() {
      currentQuestionIndex++;
      selectedOptionIndex = 0;
      timeLeft = 45;
    });
    _startTimer();
  }

  // Final score dialog with Try Again and Exit options.
  void _showFinalScore() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text("Game Over"),
        content: Text("Your final score is $score"),
        actions: [
          ElevatedButton.icon(
            icon: const Icon(Icons.refresh),
            label: const Text("Try Again"),
            onPressed: () {
              Navigator.pop(context);
              _loadRandomQuestions();
              _startTimer();
            },
          ),
          TextButton.icon(
            icon: const Icon(Icons.exit_to_app),
            label: const Text("Exit"),
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => const LegalGamesScreen()),
              );
            },
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_selectedQuestions.isEmpty) return const SizedBox();

    final current = _selectedQuestions[currentQuestionIndex];
    final options = current['options'] as List<String>;
    final media = MediaQuery.of(context);
    final screenWidth = media.size.width;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Score and Timer at the top
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Score: $score",
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  Row(
                    children: [
                      const Icon(Icons.timer, color: Colors.indigo),
                      const SizedBox(width: 5),
                      Text(
                        "${(timeLeft ~/ 60).toString().padLeft(1, '0')}:${(timeLeft % 60).toString().padLeft(2, '0')}",
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // Question Box
              Container(
                width: screenWidth,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.indigo.shade50,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  current['scenario'] as String,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 10),
              // Option hint text
              const Center(
                child: Text(
                  "Swipe up/down to choose an option",
                  style: TextStyle(fontSize: 14, fontStyle: FontStyle.italic),
                ),
              ),
              const SizedBox(height: 20),

              // Centered Swipeable Option Card
              Expanded(
                child: Center(
                  child: GestureDetector(
                    onVerticalDragEnd: (details) {
                      if (details.primaryVelocity != null && details.primaryVelocity! < 0) {
                        _onSwipeUp();
                      } else if (details.primaryVelocity != null && details.primaryVelocity! > 0) {
                        _onSwipeDown();
                      }
                    },
                    child: _colorfulOptionCard(options[selectedOptionIndex], screenWidth),
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Confirm Button
              Center(
                child: ElevatedButton.icon(
                  onPressed: () => _submitAnswer(selectedOptionIndex),
                  icon: const Icon(Icons.check_circle),
                  label: const Text("Lock In"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.indigo,
                    foregroundColor: Colors.white,
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  // Builds an attractive option card with a gradient border and uses MediaQuery for width.
  Widget _colorfulOptionCard(String optionText, double screenWidth) {
    // Generate random gradient colors for extra visual appeal
    final random = Random();
    final color1 = Color.fromARGB(255, random.nextInt(156) + 100, random.nextInt(156) + 100, random.nextInt(156) + 100);
    final color2 = Color.fromARGB(255, random.nextInt(156) + 100, random.nextInt(156) + 100, random.nextInt(156) + 100);

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: screenWidth * 0.8,
      padding: const EdgeInsets.all(20),
      margin: const EdgeInsets.symmetric(vertical: 20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color1, color2],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade400,
            blurRadius: 6,
            offset: const Offset(2, 2),
          ),
        ],
      ),
      child: Container(
        height: 320,
        alignment: Alignment.center,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: Colors.indigo,
            width: 2,
          ),
        ),
        child: Center(
          child: Text(
            optionText,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
