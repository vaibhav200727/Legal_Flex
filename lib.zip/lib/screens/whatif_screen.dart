import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_chat_ui/flutter_chat_ui.dart';
import 'package:flutter_chat_types/flutter_chat_types.dart' as types;
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:provider/provider.dart';

import '../providers/language_provider.dart';
import '../services/translation_service.dart';
import '../widgets/custom_appbar.dart';

class IndianConstitutionChatScreen extends StatefulWidget {
  const IndianConstitutionChatScreen({super.key});

  @override
  State<IndianConstitutionChatScreen> createState() =>
      _IndianConstitutionChatScreenState();
}

class _IndianConstitutionChatScreenState
    extends State<IndianConstitutionChatScreen> {
  // ---------------------------------------------------------------------------
  // Chat-related fields
  // ---------------------------------------------------------------------------
  final types.User _user = const types.User(id: 'user-id');
  final types.User _assistant = const types.User(id: 'assistant-id');
  final List<types.Message> _messages = [];
  final TextEditingController _textController = TextEditingController();
  bool _isLoadingResponse = false;

  // ---------------------------------------------------------------------------
  // Translation-related fields
  // ---------------------------------------------------------------------------
  String translatedAppBarTitle = "Indian Constitution 'What If' Chat";
  String translatedPlaceholder = "Ask about Indian Constitution...";
  String translatedInitialGreeting = '''
Welcome to the Indian Constitution "What If" Chat!

I specialize in hypothetical and explanatory questions related to the laws and articles of the Indian Constitution. Ask me anything—just remember that I'm not an official legal advisor.
''';
  String selectedLanguage = "en";

  @override
  void initState() {
    super.initState();
    // Listen for language changes so we can re-translate
    Provider.of<LanguageProvider>(context, listen: false)
        .addListener(_updateTranslations);

    // Insert the initial greeting message once the widget is ready
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadInitialMessages());
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // On the first build or subsequent changes, refresh translations
    _updateTranslations();
  }

  @override
  void dispose() {
    // Remove the listener to avoid memory leaks
    Provider.of<LanguageProvider>(context, listen: false)
        .removeListener(_updateTranslations);
    super.dispose();
  }

  // ---------------------------------------------------------------------------
  // Translation logic
  // ---------------------------------------------------------------------------
  Future<void> _updateTranslations() async {
    final languageProvider =
        Provider.of<LanguageProvider>(context, listen: false);
    selectedLanguage = languageProvider.selectedLanguage;

    try {
      translatedAppBarTitle = await TranslationService.translate(
        "Indian Constitution 'What If' Chat",
        selectedLanguage,
      );
      translatedPlaceholder = await TranslationService.translate(
        "Ask about Indian Constitution...",
        selectedLanguage,
      );
      translatedInitialGreeting = await TranslationService.translate(
        '''
Welcome to the Indian Constitution "What If" Chat!

I specialize in hypothetical and explanatory questions related to the laws and articles of the Indian Constitution. Ask me anything—just remember that I'm not an official legal advisor.
''',
        selectedLanguage,
      );

      if (mounted) {
        setState(() {
          // Trigger a rebuild with updated text
        });
      }
    } catch (e) {
      debugPrint("❌ Translation Error: $e");
    }
  }

  // ---------------------------------------------------------------------------
  // Initial greeting
  // ---------------------------------------------------------------------------
  void _loadInitialMessages() {
    final greeting = types.TextMessage(
      id: 'init-1',
      author: _assistant,
      text: translatedInitialGreeting,
      createdAt: DateTime.now().millisecondsSinceEpoch,
    );

    setState(() {
      _messages.insert(0, greeting);
    });
  }

  // ---------------------------------------------------------------------------
  // Handling user input & LLM calls
  // ---------------------------------------------------------------------------
  Future<void> _handleSendPressed() async {
    final text = _textController.text.trim();
    if (text.isEmpty) return;

    // 1) Display user's message
    final userMessage = types.TextMessage(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      author: _user,
      text: text,
      createdAt: DateTime.now().millisecondsSinceEpoch,
    );
    setState(() {
      _messages.insert(0, userMessage);
      _textController.clear();
    });

    // 2) Call your LLM or Google API
    try {
      setState(() {
        _isLoadingResponse = true;
      });

      final conversationText = _buildConversationHistory(text);
      final assistantReply = await _sendPromptToGemini(conversationText);

      // 3) Insert the assistant's reply
      final assistantMessage = types.TextMessage(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        author: _assistant,
        text: assistantReply,
        createdAt: DateTime.now().millisecondsSinceEpoch,
      );
      setState(() {
        _messages.insert(0, assistantMessage);
      });
    } catch (e) {
      final errorMsg = types.TextMessage(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        author: _assistant,
        text: 'Error: $e',
        createdAt: DateTime.now().millisecondsSinceEpoch,
      );
      setState(() {
        _messages.insert(0, errorMsg);
      });
    } finally {
      setState(() {
        _isLoadingResponse = false;
      });
    }
  }

  /// Build a single text prompt from conversation
  String _buildConversationHistory(String newestUserInput) {
    final reversed = _messages.reversed.toList();
    final buffer = StringBuffer();

    for (final msg in reversed) {
      if (msg is types.TextMessage) {
        if (msg.author.id == _user.id) {
          buffer.writeln('User: ${msg.text}');
        } else if (msg.author.id == _assistant.id) {
          buffer.writeln('Assistant: ${msg.text}');
        }
      }
    }

    buffer.writeln('User: $newestUserInput');
    buffer.writeln('Assistant:');

    return buffer.toString();
  }

  /// Helper function to map language code to language name.
  String _getLanguageName(String code) {
    switch (code) {
      case "hi":
        return "Hindi";
      case "mr":
        return "Marathi";
      case "ta":
        return "Tamil";
      case "te":
        return "Telugu";
      case "bn":
        return "Bengali";
      // Add other mappings as needed.
      default:
        return "English";
    }
  }

  /// Call the Gemini (Google) API with an instruction to respond in the selected language.
  Future<String> _sendPromptToGemini(String conversationText) async {
    final String apiKey = dotenv.env['GEMINI_API_KEY'] ?? '';
    if (apiKey.isEmpty) {
      throw Exception('Missing GEMINI_API_KEY in .env');
    }

    // Append instruction to the prompt to ask the AI to answer in the selected language.
    final languageName = _getLanguageName(selectedLanguage);
    final modifiedConversationText = "$conversationText\n\nPlease answer in $languageName.";

    final String apiUrl =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$apiKey";

    final body = {
      "contents": [
        {
          "parts": [
            {"text": modifiedConversationText}
          ]
        }
      ]
    };

    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode(body),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data["candidates"][0]["content"]["parts"][0]["text"]?.trim() ?? '';
    } else {
      throw Exception(
          "API returned status ${response.statusCode}: ${response.body}");
    }
  }

  // ---------------------------------------------------------------------------
  // Chat UI overrides
  // ---------------------------------------------------------------------------
  void _noOpOnSendPressed(types.PartialText message) {
    // We handle sending ourselves, so no-op here
  }

  // ---------------------------------------------------------------------------
  // Main build method
  // ---------------------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    return CustomAppBar(
      title: translatedAppBarTitle,
      icon: Icons.library_books, // if you want an icon
      body: SafeArea(
        child: Column(
          children: [
            // The Chat area
            Expanded(
              child: Chat(
                messages: _messages,
                user: _user,
                onSendPressed: _noOpOnSendPressed,
                customBottomWidget: const SizedBox.shrink(),
              ),
            ),
            // The text input row
            Container(
              color: Colors.white,
              padding: const EdgeInsets.fromLTRB(8, 8, 8, 16),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.grey[100],
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: TextField(
                        controller: _textController,
                        style: const TextStyle(fontSize: 14),
                        decoration: InputDecoration(
                          isDense: true,
                          border: InputBorder.none,
                          hintText: translatedPlaceholder,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  InkWell(
                    onTap: _isLoadingResponse ? null : _handleSendPressed,
                    borderRadius: BorderRadius.circular(24),
                    child: Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: _isLoadingResponse
                            ? Colors.grey
                            : Colors.blueAccent,
                        borderRadius: BorderRadius.circular(21),
                      ),
                      child: _isLoadingResponse
                          ? const Center(
                              child: SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              ),
                            )
                          : const Icon(
                              Icons.send,
                              size: 20,
                              color: Colors.white,
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
