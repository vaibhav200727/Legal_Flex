import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:project/screens/login_screen.dart';

class NyaySetuScreen extends StatefulWidget {
  const NyaySetuScreen({super.key});

  @override
  State<NyaySetuScreen> createState() => _NyaySetuScreenState();
}

class _NyaySetuScreenState extends State<NyaySetuScreen> {
  final PageController _pageController = PageController();

  @override
  Widget build(BuildContext context) {
    // Get screen width and height
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    // Determine image size based on screen dimensions
    final imageHeight = screenHeight * 0.5; // 40% of screen height
    final imageWidth = screenWidth * 0.9;   // 80% of screen width

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Add padding above the heading
              SizedBox(height: screenHeight * 0.05),
              // Heading
              RichText(
                textAlign: TextAlign.center,
                text: const TextSpan(
                  children: [
                    TextSpan(
                      text: 'Nyay',
                      style: TextStyle(
                        fontSize: 42,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 44, 101, 224),
                      ),
                    ),
                    TextSpan(
                      text: 'Setu',
                      style: TextStyle(
                        fontSize: 42,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8.0),
              const Text(
                'Justice due is justice denied',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.grey,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 6.0),
              // Slideshow with page indicators
              Expanded(
                child: Column(
                  children: [
                    Expanded(
                      child: PageView(
                        controller: _pageController,
                        children: [
                          Center(
                            child: Image.asset(
                              'assets/images/LawBook.png',
                              height: imageHeight,
                              width: imageWidth,
                              fit: BoxFit.contain,
                            ),
                          ),
                          Center(
                            child: Image.asset(
                              'assets/images/LaptopScroll.png',
                              height: imageHeight,
                              width: imageWidth,
                              fit: BoxFit.contain,
                            ),
                          ),
                          Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                                children: [
                                Image.asset(
                                  'assets/images/Justicelogowithbook.png',
                                  height: imageHeight,
                                  width: imageWidth,
                                  fit: BoxFit.contain,
                                ),
                                const SizedBox(height: 16.0),
                                ElevatedButton(
                                  onPressed: () {
                                   Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => const LoginPage(), 
                                      ),
                                    );
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color.fromARGB(255, 44, 101, 224),
                                    minimumSize: const Size(double.infinity, 50),
                                  ),
                                  child: const Text(
                                    'Continue',
                                    style: TextStyle(color: Colors.white, fontSize: 18.0),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16.0),
                    SmoothPageIndicator(
                      controller: _pageController,
                      count: 3,
                      effect: ExpandingDotsEffect(
                        dotHeight: 8,
                        dotWidth: 8,
                        activeDotColor: const Color.fromARGB(255, 44, 101, 224),
                        dotColor: Colors.grey.shade400,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }
}
