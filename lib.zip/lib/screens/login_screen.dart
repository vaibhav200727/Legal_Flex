import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:project/screens/forgotpass_screen.dart';
import 'package:project/screens/register_screen.dart';
import 'package:project/screens/home_screen.dart'; // Import HomeScreen
import 'package:project/auth/auth_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  bool _rememberMe = false;
  String? _emailError;
  String? _passwordError;
  bool _passwordVisible = false; // Toggle state for password visibility

  @override
  void initState() {
    super.initState();
    _checkRememberMe();
  }

  /// ✅ **Check "Remember Me" Preference & Auto-login If Needed**
  Future<void> _checkRememberMe() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final bool rememberMe = prefs.getBool('rememberMe') ?? false;
    final User? user = FirebaseAuth.instance.currentUser;

    setState(() {
      _rememberMe = rememberMe;
    });

    if (rememberMe && user != null) {
      _onLoginSuccess(user);
    }
  }

  /// ✅ **Save "Remember Me" Preference**
  Future<void> _setRememberMe(bool value) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('rememberMe', value);
  }

  void _validateFields() {
    setState(() {
      _emailError = null;
      _passwordError = null;

      if (_emailController.text.isEmpty) {
        _emailError = 'Email cannot be empty';
      } else if (!_emailController.text.contains('@')) {
        _emailError = 'Invalid email format';
      }

      if (_passwordController.text.isEmpty) {
        _passwordError = 'Password cannot be empty';
      } else if (_passwordController.text.length < 8) {
        _passwordError = 'Password must be at least 8 characters long';
      }
    });

    // ✅ Move this inside `_validateFields`
    if (_emailError == null && _passwordError == null) {
      _loginWithEmail();
    }
  }

  /// ✅ **Email Login with "Remember Me" Handling**
  Future<void> _loginWithEmail() async {
    try {
      User? user = await AuthService.loginWithEmail(
        _emailController.text.trim(),
        _passwordController.text.trim(),
        rememberMe: _rememberMe,
      );

      if (user != null) {
        await _setRememberMe(_rememberMe);
        _onLoginSuccess(user);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Login failed. Please check your credentials.')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Login error: $e')),
      );
    }
  }

  /// ✅ **Google Login with "Remember Me" Handling**
  Future<void> _loginWithGoogle() async {
    try {
      bool rememberMe = _rememberMe;
      User? user = await AuthService.loginWithGoogle(rememberMe: rememberMe);

      if (user != null) {
        await _setRememberMe(rememberMe);
        _onLoginSuccess(user);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Google login failed. Please try again.')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Google login failed: $e')),
      );
    }
  }

  /// Handle post-login actions (Navigate to Home)
  void _onLoginSuccess(User user) {
    print("User successfully logged in: ${user.email}");
    
    // Navigate directly to the HomeScreen widget.
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => const HomeScreen(),
      ),
    );
  }

  /// ✅ **Logout User & Clear "Remember Me"**
  Future<void> _logout() async {
    await AuthService.logout();

    // ✅ **Clear Remember Me State**
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('rememberMe', false);

    Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final bool isSmallScreen = size.width < 400;

    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: size.width * 0.08),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Align(
                alignment: Alignment.center,
                child: Padding(
                  padding: const EdgeInsets.only(top: 20.0),
                  child: Text(
                    '',
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: isSmallScreen ? 20 : 24,
                    ),
                  ),
                ),
              ),
              SizedBox(height: isSmallScreen ? 30 : 40),
              Align(
                alignment: Alignment.center,
                child: Text(
                  'Welcome Back',
                  style: TextStyle(
                    fontSize: isSmallScreen ? 28 : 32,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              SizedBox(height: isSmallScreen ? 10 : 15),
              Align(
                alignment: Alignment.center,
                child: Text(
                  'Sign in with your email and password\nor login with any social media',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: isSmallScreen ? 15 : 17,
                    color: Colors.grey,
                  ),
                ),
              ),
              SizedBox(height: isSmallScreen ? 30 : 40),
              TextField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  labelStyle: TextStyle(
                    color: Colors.grey,
                    fontSize: isSmallScreen ? 15 : 17,
                  ),
                  suffixIcon: const Icon(Icons.email, color: Colors.grey),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(25),
                  ),
                  errorText: _emailError,
                ),
              ),
              const SizedBox(height: 20),
              // Password Field with Toggle Visibility
              TextField(
                controller: _passwordController,
                obscureText: !_passwordVisible,
                decoration: InputDecoration(
                  labelText: 'Password',
                  labelStyle: TextStyle(
                    color: Colors.grey,
                    fontSize: isSmallScreen ? 15 : 17,
                  ),
                  suffixIcon: IconButton(
                    icon: Icon(
                      _passwordVisible ? Icons.visibility : Icons.visibility_off,
                      color: Colors.grey,
                    ),
                    onPressed: () {
                      setState(() {
                        _passwordVisible = !_passwordVisible;
                      });
                    },
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(25),
                  ),
                  errorText: _passwordError,
                ),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Checkbox(
                        value: _rememberMe,
                        onChanged: (bool? value) {
                          setState(() {
                            _rememberMe = value ?? false;
                          });
                        },
                      ),
                      Text(
                        'Remember me',
                        style: TextStyle(fontSize: isSmallScreen ? 15 : 17),
                      ),
                    ],
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const ForgotPassword(),
                        ),
                      );
                    },
                    child: Text(
                      'Forgot Password?',
                      style: TextStyle(
                        color: const Color.fromARGB(255, 60, 159, 240),
                        decoration: TextDecoration.underline,
                        fontSize: isSmallScreen ? 15 : 17,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: _validateFields,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color.fromARGB(255, 44, 101, 224),
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25),
                  ),
                ),
                child: Center(
                  child: Text(
                    'Continue',
                    style: TextStyle(
                      fontSize: isSmallScreen ? 16 : 19,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              SizedBox(height: isSmallScreen ? 20 : 30),
              Center(
                child: IconButton(
                  icon: Image.asset('assets/icons/google.png'),
                  iconSize: isSmallScreen ? 25 : 30,
                  onPressed: () async {
                    try {
                      bool rememberMe = _rememberMe; // Get checkbox value
                      User? user = await AuthService.loginWithGoogle(rememberMe: rememberMe);

                      if (user != null) {
                        print("Google login successful: ${user.email}");
                        _onLoginSuccess(user);
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Google login failed. Please try again.')),
                        );
                      }
                    } catch (e) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Google login failed: $e')),
                      );
                    }
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Don\'t have an account? ',
                    style: TextStyle(fontSize: isSmallScreen ? 15 : 17),
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const RegisterPage(),
                        ),
                      );
                    },
                    child: Text(
                      'Sign Up',
                      style: TextStyle(
                        color: Colors.blue,
                        decoration: TextDecoration.underline,
                        fontSize: isSmallScreen ? 15 : 17,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
