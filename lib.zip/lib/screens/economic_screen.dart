import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:provider/provider.dart';
import '../widgets/custom_appbar.dart';
import '../providers/language_provider.dart';
import '../providers/save_provider.dart';
import '../services/translation_service.dart';

class EconomicRightsScreen extends StatefulWidget {
  const EconomicRightsScreen({super.key});

  @override
  _EconomicRightsScreenState createState() => _EconomicRightsScreenState();
}

class _EconomicRightsScreenState extends State<EconomicRightsScreen> {
  final FlutterTts flutterTts = FlutterTts();

  String headerText = "Know Your Rights";
  List<String> translatedTitles = economicRights.map((e) => e['title'] as String).toList();
  List<String> translatedDescriptions = economicRights.map((e) => e['description'] as String).toList();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLanguage = languageProvider.selectedLanguage;

    try {
      String newHeader = await TranslationService.translate("Know Your Rights", selectedLanguage);
      if (mounted) {
        setState(() {
          headerText = newHeader;
        });
      }
    } catch (e) {
      print("❌ Translation error for header: $e");
    }

    List<String> newTitles = [];
    List<String> newDescriptions = [];
    for (var item in economicRights) {
      try {
        String tTitle = await TranslationService.translate(item['title'], selectedLanguage);
        String tDesc = await TranslationService.translate(item['description'], selectedLanguage);
        newTitles.add(tTitle);
        newDescriptions.add(tDesc);
      } catch (e) {
        print("❌ Translation error for ${item['title']}: $e");
        newTitles.add(item['title']);
        newDescriptions.add(item['description']);
      }
    }
    if (mounted) {
      setState(() {
        translatedTitles = newTitles;
        translatedDescriptions = newDescriptions;
      });
    }
  }

  void _speak(String text) async {
    await flutterTts.speak(text);
  }

  /// Toggle saved status using SaveProvider.
  void toggleSaveItem(BuildContext context, String item) {
    final saveProvider = Provider.of<SaveProvider>(context, listen: false);
    if (saveProvider.savedItems.contains(item)) {
      saveProvider.removeItem(item);
    } else {
      saveProvider.addItem(item);
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isSmallScreen = screenWidth < 600;
    final saveProvider = Provider.of<SaveProvider>(context);

    return CustomAppBar(
      title: "Know Your Rights",
      icon: Icons.work,
      body: Padding(
        padding: EdgeInsets.all(isSmallScreen ? 8.0 : 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            Text(
              headerText,
              style: TextStyle(
                fontSize: isSmallScreen ? 16 : 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: economicRights.length,
                itemBuilder: (context, index) {
                  final title = translatedTitles[index];
                  final description = translatedDescriptions[index];
                  final isSaved = saveProvider.savedItems.contains(title);
                  return Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    margin: EdgeInsets.symmetric(vertical: isSmallScreen ? 4 : 6),
                    child: Padding(
                      padding: EdgeInsets.all(isSmallScreen ? 8 : 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                economicRights[index]['icon'],
                                color: economicRights[index]['color'],
                                size: isSmallScreen ? 28 : 32,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  title,
                                  style: TextStyle(
                                    fontSize: isSmallScreen ? 14 : 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: Icon(
                                  Icons.volume_up,
                                  color: Colors.blue,
                                  size: isSmallScreen ? 22 : 26,
                                ),
                                onPressed: () => _speak(description),
                              ),
                              IconButton(
                                icon: Icon(
                                  isSaved ? Icons.bookmark : Icons.bookmark_border,
                                  color: isSaved ? Colors.blue : Colors.grey,
                                  size: isSmallScreen ? 22 : 26,
                                ),
                                onPressed: () {
                                  toggleSaveItem(context, title);
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text(
                            description,
                            style: TextStyle(
                              fontSize: isSmallScreen ? 15 : 20,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

final List<Map<String, dynamic>> economicRights = [
  {
    "title": "Right to Work & Fair Wages",
    "icon": Icons.work,
    "color": Colors.blue,
    "description": "Everyone has the right to employment and fair pay."
  },
  {
    "title": "Right to Own Property",
    "icon": Icons.home,
    "color": Colors.green,
    "description": "Individuals have the right to buy, own, and sell property."
  },
  {
    "title": "Right to Form Trade Unions",
    "icon": Icons.groups,
    "color": Colors.orange,
    "description": "Workers can join unions to protect their interests."
  },
  {
    "title": "Right to Financial Security & Social Welfare",
    "icon": Icons.account_balance,
    "color": Colors.purple,
    "description": "Governments should provide financial aid and social security."
  },
  {
    "title": "Right to Equal Pay",
    "icon": Icons.monetization_on,
    "color": Colors.cyan,
    "description": "Men and women must receive equal pay for equal work."
  },
  {
    "title": "Right to Safe Working Conditions",
    "icon": Icons.health_and_safety,
    "color": Colors.red,
    "description": "Workers should be protected from hazardous environments."
  },
  {
    "title": "Right to Unemployment Benefits",
    "icon": Icons.money,
    "color": Colors.brown,
    "description": "Financial aid should be provided to the jobless."
  },
  {
    "title": "Right to Social Security",
    "icon": Icons.security,
    "color": Colors.indigo,
    "description": "Pensions, disability support, and healthcare benefits for all."
  },
  {
    "title": "Right to Free Choice of Employment",
    "icon": Icons.how_to_vote,
    "color": Colors.amber,
    "description": "Everyone should have the freedom to choose their profession."
  },
  {
    "title": "Right to Protection Against Forced Labor",
    "icon": Icons.gavel,
    "color": Colors.teal,
    "description": "No one should be forced to work against their will."
  }
];
