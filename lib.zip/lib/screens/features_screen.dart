import 'package:flutter/material.dart';


class FeaturesScreen1 extends StatelessWidget {
  const FeaturesScreen1({super.key});

  final List<String> features = const [
  'ActWise', // Case-To-Act
  'Know Your Rights', // Acknowledge Your Right
  'DocuLegis', // Legal Document Generator
  'LexiLaw', // Glossary
  'LawLite', // Simplification
  'AdvoConnect', // Video Call
  'NyayVaani', // E-Library
  'LawChat', // Chat
  'Nyay Queries', // FAQs
  'LawFacts', // Facts You Didn’t Know
  'LawScenarios', // What If
  'ScanLaw', // OCR
  'LegiQuiz', // Quizzes
  'NyayManch', // Community Forum
];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("All Features")),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: features.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              leading: const Icon(Icons.check_circle, color: Colors.blue),
              title: Text(features[index]),
            ),
          );
        },
      ),
    );
  }
}
