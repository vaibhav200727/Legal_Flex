import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../widgets/custom_appbar.dart';
import '../providers/language_provider.dart';
import '../providers/save_provider.dart';
import '../services/translation_service.dart';
import 'civil_screen.dart';
import 'economic_screen.dart';
import 'social_screen.dart';
import 'cultural_screen.dart';
import 'cyber_screen.dart';
import 'consumer_screen.dart';
import 'privacy_screen.dart';
import 'employee_screen.dart';
import 'education_screen.dart';
import 'health_screen.dart';

/// Updated color palette:
/// - Lighter Blue (background): #E2F0FF
/// - Navy Blue (cards): #0A1E3E
/// - Icons: Blue (#1E40AF or just Colors.blue)
/// - White text on navy cards.
const kLighterBlue = Color(0xFFE2F0FF);
const kNavyBlue = Color(0xFF0A1E3E);
const kWhite = Colors.white;
const kIconBlue = Colors.blue; // or any shade of blue you like

class KnowYourRightsScreen extends StatefulWidget {
  const KnowYourRightsScreen({super.key});

  @override
  _KnowYourRightsScreenState createState() => _KnowYourRightsScreenState();
}

class _KnowYourRightsScreenState extends State<KnowYourRightsScreen> {
  // Translated texts
  String translatedTitle = "Know Your Rights";
  String translatedSearchHint = "Search rights and laws...";
  String translatedAllCategories = "All Categories";
  String translatedCivilAndPoliticalRights = "Civil and Political Rights";
  String translatedEconomicRights = "Economic Rights";
  String translatedSocialRights = "Social Rights";
  String translatedCulturalRights = "Cultural Rights";
  String translatedCyberRights = "Cyber Rights";
  String translatedConsumerRights = "Consumer Rights";
  String translatedPrivacyRights = "Privacy Rights";
  String translatedEmploymentRights = "Employment Rights";
  String translatedEducationRights = "Education Rights";
  String translatedHealthcareRights = "Healthcare Rights";
  String translatedRights = "rights"; // This will be translated

  String selectedLanguage = "en";
  String? _previousLanguage;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final languageProvider = Provider.of<LanguageProvider>(context);
    if (_previousLanguage != languageProvider.selectedLanguage) {
      _previousLanguage = languageProvider.selectedLanguage;
      _updateTranslations();
    }
  }

  Future<void> _updateTranslations() async {
    final languageProvider =
        Provider.of<LanguageProvider>(context, listen: false);
    selectedLanguage = languageProvider.selectedLanguage;

    try {
      translatedTitle = await TranslationService.translate("Know Your Rights", selectedLanguage);
      translatedSearchHint = await TranslationService.translate("Search rights and laws...", selectedLanguage);
      translatedAllCategories = await TranslationService.translate("All Categories", selectedLanguage);
      translatedCivilAndPoliticalRights = await TranslationService.translate("Civil and Political Rights", selectedLanguage);
      translatedEconomicRights = await TranslationService.translate("Economic Rights", selectedLanguage);
      translatedSocialRights = await TranslationService.translate("Social Rights", selectedLanguage);
      translatedCulturalRights = await TranslationService.translate("Cultural Rights", selectedLanguage);
      translatedCyberRights = await TranslationService.translate("Cyber Rights", selectedLanguage);
      translatedConsumerRights = await TranslationService.translate("Consumer Rights", selectedLanguage);
      translatedPrivacyRights = await TranslationService.translate("Privacy Rights", selectedLanguage);
      translatedEmploymentRights = await TranslationService.translate("Employment Rights", selectedLanguage);
      translatedEducationRights = await TranslationService.translate("Education Rights", selectedLanguage);
      translatedHealthcareRights = await TranslationService.translate("Healthcare Rights", selectedLanguage);
      translatedRights = await TranslationService.translate("rights", selectedLanguage);
      if (mounted) {
        setState(() {});
      }
    } catch (e) {
      debugPrint("❌ Translation Error: $e");
    }
  }

  void _navigateToCategory(BuildContext context, Widget screen) {
    Navigator.push(context, MaterialPageRoute(builder: (context) => screen));
  }

  @override
  Widget build(BuildContext context) {
    // Retrieve saved items from SaveProvider.
    final savedItems = Provider.of<SaveProvider>(context).savedItems;

    return CustomAppBar(
      title: translatedTitle,
      icon: Icons.library_books,
      body: Container(
        // Lighter blue background
        color: kLighterBlue,
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 10),
              // Search Bar
              _buildSearchBar(),
              const SizedBox(height: 20),
              // Categories Section
              Text(
                translatedAllCategories,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black, // Dark text on light background
                ),
              ),
              const SizedBox(height: 10),
              // Category Tiles (navy background, white text)
              CategoryTile(
                title: translatedCivilAndPoliticalRights,
                count: 6,
                icon: Icons.gavel,
                translatedRights: translatedRights,
                onTap: () => _navigateToCategory(context, const CivilPoliticalRightsScreen()),
              ),
              CategoryTile(
                title: translatedEconomicRights,
                count: 10,
                icon: Icons.attach_money,
                translatedRights: translatedRights,
                onTap: () => _navigateToCategory(context, const EconomicRightsScreen()),
              ),
              CategoryTile(
                title: translatedSocialRights,
                count: 10,
                icon: Icons.groups,
                translatedRights: translatedRights,
                onTap: () => _navigateToCategory(context, const SocialRightsScreen()),
              ),
              CategoryTile(
                title: translatedCulturalRights,
                count: 10,
                icon: Icons.museum,
                translatedRights: translatedRights,
                onTap: () => _navigateToCategory(context, const CulturalRightsScreen()),
              ),
              CategoryTile(
                title: translatedCyberRights,
                count: 10,
                icon: Icons.security,
                translatedRights: translatedRights,
                onTap: () => _navigateToCategory(context, const CyberRightsScreen()),
              ),
              CategoryTile(
                title: translatedConsumerRights,
                count: 10,
                icon: Icons.shopping_cart,
                translatedRights: translatedRights,
                onTap: () => _navigateToCategory(context, const ConsumerRightsScreen()),
              ),
              CategoryTile(
                title: translatedPrivacyRights,
                count: 10,
                icon: Icons.privacy_tip,
                translatedRights: translatedRights,
                onTap: () => _navigateToCategory(context, const PrivacyRightsScreen()),
              ),
              CategoryTile(
                title: translatedEmploymentRights,
                count: 10,
                icon: Icons.work,
                translatedRights: translatedRights,
                onTap: () => _navigateToCategory(context, const EmploymentRightsScreen()),
              ),
              CategoryTile(
                title: translatedEducationRights,
                count: 10,
                icon: Icons.school,
                translatedRights: translatedRights,
                onTap: () => _navigateToCategory(context, const EducationRightsScreen()),
              ),
              CategoryTile(
                title: translatedHealthcareRights,
                count: 10,
                icon: Icons.local_hospital,
                translatedRights: translatedRights,
                onTap: () => _navigateToCategory(context, const HealthcareRightsScreen()),
              ),
              const SizedBox(height: 20),
              // Saved Items Section
              const Text(
                "Saved Items",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black, // dark text
                ),
              ),
              const SizedBox(height: 10),
              savedItems.isNotEmpty
                  ? Column(
                      children: savedItems
                          .map((item) => Container(
                                margin: const EdgeInsets.only(bottom: 8),
                                decoration: BoxDecoration(
                                  color: kNavyBlue,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: ListTile(
                                  title: Text(
                                    item,
                                    style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: kWhite,
                                    ),
                                  ),
                                ),
                              ))
                          .toList(),
                    )
                  : const Text(
                      "No items saved yet.",
                      style: TextStyle(color: Colors.black),
                    ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  /// Search bar: a white-filled text field on lighter blue background, with a bigger curve (25)
  Widget _buildSearchBar() {
    return TextField(
      style: const TextStyle(color: Colors.black),
      decoration: InputDecoration(
        hintText: translatedSearchHint,
        hintStyle: const TextStyle(color: Colors.black54),
        prefixIcon: Icon(Icons.search, color: kIconBlue),
        filled: true,
        fillColor: kWhite,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(25),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}

/// A tile with a navy background, white text, and a blue icon
class CategoryTile extends StatelessWidget {
  final String title;
  final int count;
  final IconData icon;
  final String translatedRights;
  final VoidCallback onTap;

  const CategoryTile({
    super.key,
    required this.title,
    required this.count,
    required this.icon,
    required this.translatedRights,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      // Navy card with slight corner rounding
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: const Color.fromARGB(142, 6, 23, 51),
        borderRadius: BorderRadius.circular(8),
      ),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: kIconBlue.withOpacity(0.1),
          child: Icon(icon, color: kIconBlue),
        ),
        title: Text(
          title,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: kWhite),
        ),
        subtitle: Text(
          "$count $translatedRights",
          style: const TextStyle(color: kWhite),
        ),
        trailing: Icon(Icons.arrow_forward_ios, size: 16, color: kIconBlue.withOpacity(0.8)),
        onTap: onTap,
      ),
    );
  }
}
