import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:provider/provider.dart';
import '../widgets/custom_appbar.dart';
import '../providers/language_provider.dart';
import '../providers/save_provider.dart';
import '../services/translation_service.dart';

class CivilPoliticalRightsScreen extends StatefulWidget {
  const CivilPoliticalRightsScreen({super.key});

  @override
  _CivilPoliticalRightsScreenState createState() => _CivilPoliticalRightsScreenState();
}

class _CivilPoliticalRightsScreenState extends State<CivilPoliticalRightsScreen> {
  final FlutterTts flutterTts = FlutterTts();

  String headerText = "Know Your Rights";
  List<String> translatedTitles = civilPoliticalRights.map((e) => e['title'] as String).toList();
  List<String> translatedDescriptions =
      civilPoliticalRights.map((e) => e['description'] as String).toList();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLanguage = languageProvider.selectedLanguage;

    try {
      String newHeader = await TranslationService.translate("Know Your Rights", selectedLanguage);
      if (mounted) {
        setState(() {
          headerText = newHeader;
        });
      }
    } catch (e) {
      print("❌ Translation error for header: $e");
    }

    List<String> newTitles = [];
    List<String> newDescriptions = [];
    for (var item in civilPoliticalRights) {
      try {
        String tTitle = await TranslationService.translate(item['title'], selectedLanguage);
        String tDesc = await TranslationService.translate(item['description'], selectedLanguage);
        newTitles.add(tTitle);
        newDescriptions.add(tDesc);
      } catch (e) {
        print("❌ Translation error for ${item['title']}: $e");
        newTitles.add(item['title']);
        newDescriptions.add(item['description']);
      }
    }
    if (mounted) {
      setState(() {
        translatedTitles = newTitles;
        translatedDescriptions = newDescriptions;
      });
    }
  }

  void _speak(String text) async {
    await flutterTts.speak(text);
  }

  // Toggle the saved state using SaveProvider.
  void toggleSaveItem(BuildContext context, String item) {
    final saveProvider = Provider.of<SaveProvider>(context, listen: false);
    if (saveProvider.savedItems.contains(item)) {
      saveProvider.removeItem(item);
    } else {
      saveProvider.addItem(item);
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isSmallScreen = screenWidth < 600;
    final saveProvider = Provider.of<SaveProvider>(context);

    return CustomAppBar(
      title: "Know Your Rights",
      icon: Icons.gavel,
      body: Padding(
        padding: EdgeInsets.all(isSmallScreen ? 8.0 : 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            Text(
              headerText,
              style: TextStyle(fontSize: isSmallScreen ? 16 : 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: civilPoliticalRights.length,
                itemBuilder: (context, index) {
                  final title = translatedTitles[index];
                  final description = translatedDescriptions[index];
                  final isSaved = saveProvider.savedItems.contains(title);
                  return Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    margin: EdgeInsets.symmetric(vertical: isSmallScreen ? 4 : 6),
                    child: Padding(
                      padding: EdgeInsets.all(isSmallScreen ? 8 : 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                civilPoliticalRights[index]['icon'],
                                color: civilPoliticalRights[index]['color'],
                                size: isSmallScreen ? 28 : 32,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  title,
                                  style: TextStyle(
                                    fontSize: isSmallScreen ? 14 : 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: Icon(Icons.volume_up, color: Colors.blue, size: isSmallScreen ? 22 : 26),
                                onPressed: () => _speak(description),
                              ),
                              IconButton(
                                icon: Icon(
                                  isSaved ? Icons.bookmark : Icons.bookmark_border,
                                  color: isSaved ? Colors.blue : Colors.grey,
                                  size: isSmallScreen ? 22 : 26,
                                ),
                                onPressed: () {
                                  toggleSaveItem(context, title);
                                },
                              ),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text(
                            description,
                            style: TextStyle(fontSize: isSmallScreen ? 15 : 20, color: Colors.grey),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

final List<Map<String, dynamic>> civilPoliticalRights = [
  {"title": "Right to Life & Liberty", "icon": Icons.security, "color": Colors.teal, "description": "Protection of life and personal freedom (Article 21)."},
  {"title": "Right to Freedom of Speech", "icon": Icons.mic, "color": Colors.blue, "description": "Freedom of expression and communication without censorship."},
  {"title": "Right to Vote", "icon": Icons.how_to_vote, "color": Colors.orange, "description": "Right to participate in free and fair elections."},
  {"title": "Right to Privacy", "icon": Icons.privacy_tip, "color": Colors.purple, "description": "Protection against unauthorized surveillance and data collection."},
  {"title": "Right Against Discrimination", "icon": Icons.people, "color": Colors.red, "description": "Equal treatment and prohibition of discrimination based on caste, religion, gender, etc."},
  {"title": "Right Against Arbitrary Arrest & Torture", "icon": Icons.gavel, "color": Colors.green, "description": "Protection from unlawful detention and mistreatment."},
];
