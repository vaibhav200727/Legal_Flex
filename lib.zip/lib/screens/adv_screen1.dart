import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:project/services/lawyer_upload.dart';
import '../widgets/custom_appbar.dart';
import '../providers/theme_provider.dart';
import '../providers/language_provider.dart';
import '../services/translation_service.dart';
// Import your advanced screen (update path as needed)
import '../screens/adv_screen4.dart';

class LawyerProfileScreen extends StatefulWidget {
  const LawyerProfileScreen({super.key});

  @override
  _LawyerProfileScreenState createState() => _LawyerProfileScreenState();
}

class _LawyerProfileScreenState extends State<LawyerProfileScreen> {
  // Translated title and language selection.
  String translatedTitle = "Lawyer Profile";
  String selectedLanguage = "en";

  // Form fields and controllers.
  String? _selectedState;
  String? _selectedCity;
  String? _selectedLawType;
  File? _profileImage;
  final _formKey = GlobalKey<FormState>();
  final _fullNameController = TextEditingController();
  final _lawDegreeController = TextEditingController();
  final _feesController = TextEditingController();

  // List of all Indian states and union territories.
  final List<String> _states = [
    'Select your state/UT',
    'Andhra Pradesh',
    'Arunachal Pradesh',
    'Assam',
    'Bihar',
    'Chhattisgarh',
    'Goa',
    'Gujarat',
    'Haryana',
    'Himachal Pradesh',
    'Jharkhand',
    'Karnataka',
    'Kerala',
    'Madhya Pradesh',
    'Maharashtra',
    'Manipur',
    'Meghalaya',
    'Mizoram',
    'Nagaland',
    'Odisha',
    'Punjab',
    'Rajasthan',
    'Sikkim',
    'Tamil Nadu',
    'Telangana',
    'Tripura',
    'Uttar Pradesh',
    'Uttarakhand',
    'West Bengal',
    'Andaman and Nicobar Islands',
    'Chandigarh',
    'Dadra and Nagar Haveli and Daman and Diu',
    'Delhi',
    'Jammu and Kashmir',
    'Ladakh',
    'Lakshadweep',
    'Puducherry',
  ];

  // Map of states/UTs to their respective cities.
  final Map<String, List<String>> _stateToCities = {
    'Andhra Pradesh': [
      'Amaravati',
      'Visakhapatnam',
      'Vijayawada',
      'Guntur',
      'Nellore',
      'Tirupati',
    ],
    'Arunachal Pradesh': [
      'Itanagar',
      'Naharlagun',
      'Pasighat',
      'Tawang',
      'Ziro',
    ],
    'Assam': [
      'Dispur',
      'Guwahati',
      'Silchar',
      'Dibrugarh',
      'Jorhat',
      'Nagaon'
    ],
    'Bihar': [
      'Patna',
      'Gaya',
      'Bhagalpur',
      'Muzaffarpur',
      'Darbhanga',
      'Purnia'
    ],
    'Chhattisgarh': [
      'Raipur',
      'Bhilai',
      'Bilaspur',
      'Korba',
      'Durg',
      'Rajnandgaon'
    ],
    'Goa': ['Panaji', 'Margao', 'Vasco da Gama', 'Mapusa', 'Ponda'],
    'Gujarat': [
      'Gandhinagar',
      'Ahmedabad',
      'Surat',
      'Vadodara',
      'Rajkot',
      'Bhavnagar'
    ],
    'Haryana': [
      'Chandigarh',
      'Faridabad',
      'Gurgaon',
      'Hisar',
      'Panipat',
      'Karnal'
    ],
    'Himachal Pradesh': [
      'Shimla',
      'Dharamshala',
      'Mandi',
      'Solan',
      'Kullu',
      'Manali'
    ],
    'Jharkhand': [
      'Ranchi',
      'Jamshedpur',
      'Dhanbad',
      'Bokaro',
      'Deoghar',
      'Hazaribagh'
    ],
    'Karnataka': [
      'Bangalore',
      'Mysore',
      'Hubli',
      'Mangalore',
      'Belgaum',
      'Davanagere'
    ],
    'Kerala': [
      'Thiruvananthapuram',
      'Kochi',
      'Kozhikode',
      'Thrissur',
      'Kollam',
      'Kannur'
    ],
    'Madhya Pradesh': [
      'Bhopal',
      'Indore',
      'Jabalpur',
      'Gwalior',
      'Ujjain',
      'Sagar'
    ],
    'Maharashtra': [
      'Mumbai',
      'Pune',
      'Nagpur',
      'Nashik',
      'Aurangabad',
      'Thane'
    ],
    'Manipur': ['Imphal', 'Thoubal', 'Bishnupur', 'Churachandpur', 'Kakching'],
    'Meghalaya': [
      'Shillong',
      'Tura',
      'Nongstoin',
      'Jowai',
      'Williamnagar'
    ],
    'Mizoram': ['Aizawl', 'Lunglei', 'Saiha', 'Champhai', 'Kolasib'],
    'Nagaland': [
      'Kohima',
      'Dimapur',
      'Mokokchung',
      'Tuensang',
      'Wokha'
    ],
    'Odisha': [
      'Bhubaneswar',
      'Cuttack',
      'Rourkela',
      'Berhampur',
      'Sambalpur',
      'Puri'
    ],
    'Punjab': [
      'Chandigarh',
      'Ludhiana',
      'Amritsar',
      'Jalandhar',
      'Patiala',
      'Bathinda'
    ],
    'Rajasthan': [
      'Jaipur',
      'Jodhpur',
      'Udaipur',
      'Kota',
      'Ajmer',
      'Bikaner'
    ],
    'Sikkim': ['Gangtok', 'Namchi', 'Gyalshing', 'Mangan', 'Ravangla'],
    'Tamil Nadu': [
      'Chennai',
      'Coimbatore',
      'Madurai',
      'Salem',
      'Tiruchirappalli',
      'Erode'
    ],
    'Telangana': [
      'Hyderabad',
      'Warangal',
      'Nizamabad',
      'Khammam',
      'Karimnagar',
      'Ramagundam'
    ],
    'Tripura': [
      'Agartala',
      'Udaipur',
      'Dharmanagar',
      'Kailasahar',
      'Belonia'
    ],
    'Uttar Pradesh': [
      'Lucknow',
      'Kanpur',
      'Agra',
      'Varanasi',
      'Noida',
      'Meerut'
    ],
    'Uttarakhand': [
      'Dehradun',
      'Haridwar',
      'Rishikesh',
      'Nainital',
      'Haldwani',
      'Roorkee'
    ],
    'West Bengal': [
      'Kolkata',
      'Howrah',
      'Durgapur',
      'Asansol',
      'Siliguri',
      'Darjeeling'
    ],
    'Andaman and Nicobar Islands': [
      'Port Blair',
      'Car Nicobar',
      'Mayabunder',
      'Diglipur'
    ],
    'Chandigarh': ['Chandigarh'],
    'Dadra and Nagar Haveli and Daman and Diu': [
      'Daman',
      'Diu',
      'Silvassa'
    ],
    'Delhi': [
      'New Delhi',
      'Delhi',
      'Noida',
      'Gurgaon',
      'Faridabad'
    ],
    'Jammu and Kashmir': [
      'Srinagar',
      'Jammu',
      'Anantnag',
      'Baramulla',
      'Kathua'
    ],
    'Ladakh': ['Leh', 'Kargil'],
    'Lakshadweep': ['Kavaratti', 'Minicoy', 'Andrott', 'Agatti'],
    'Puducherry': ['Pondicherry', 'Karaikal', 'Mahe', 'Yanam'],
  };

  // List of cities based on the selected state/UT.
  List<String> _cities = ['Select your city'];

  // List of law types.
  final List<String> _lawTypes = [
    "Select law type",
    "Corporate",
    "Criminal",
    "Family",
    "Civil",
    "Other",
  ];

  // Full list of cities (if no state is selected) – truncated for brevity.
  final List<String> citiesOfIndia = [
    "Mumbai",
    "Delhi",
    "Bengaluru",
    "Ahmedabad",
    "Hyderabad",
    "Chennai",
    "Kolkata",
    "Pune",
    "Jaipur",
    "Surat",
    // Add more as needed...
  ];

  // Image picker instance.
  final ImagePicker _picker = ImagePicker();

  // Consistent input decoration for text fields.
  InputDecoration _buildInputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(color: Colors.grey, fontSize: 14),
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey[300]!),
      ),
    );
  }

  // Function to pick a profile image from the gallery.
  Future<void> _pickProfileImage() async {
    final image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() {
        _profileImage = File(image.path);
      });
    }
  }

  // Update cities based on the selected state.
  void _updateCities(String? selectedState) {
    setState(() {
      _selectedState = selectedState;
      _selectedCity = null; // Reset city when state changes.
      if (selectedState != null && selectedState != 'Select your state/UT') {
        _cities = ['Select your city', ..._stateToCities[selectedState]!];
      } else {
        _cities = ['Select your city'];
      }
    });
  }

  // Bottom sheet for state selection.
  Future<void> _selectStateBottomSheet() async {
    String searchQuery = "";
    await showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(builder: (context, setModalState) {
          final availableStates =
              _states.where((s) => s != 'Select your state/UT').toList();
          final filteredStates = availableStates
              .where((state) =>
                  state.toLowerCase().contains(searchQuery.toLowerCase()))
              .toList();
          return Container(
            height: 400,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey[300]!),
              borderRadius: BorderRadius.circular(12),
              color: Colors.white,
            ),
            child: Column(
              children: [
                TextField(
                  decoration: InputDecoration(
                    hintText: "Search states...",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                  onChanged: (value) {
                    setModalState(() {
                      searchQuery = value;
                    });
                  },
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: ListView.builder(
                    itemCount: filteredStates.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(filteredStates[index]),
                        onTap: () {
                          setState(() {
                            _selectedState = filteredStates[index];
                            _updateCities(filteredStates[index]);
                          });
                          Navigator.pop(context);
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        });
      },
    );
  }

  // Bottom sheet for city selection.
  Future<void> _selectCityBottomSheet() async {
    if (_selectedState == null || _selectedState == 'Select your state/UT') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please select your state of practice first")),
      );
      return;
    }
    String searchQuery = "";
    await showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(builder: (context, setModalState) {
          // Use cities corresponding to the selected state.
          List<String> availableCities =
              _cities.where((c) => c != 'Select your city').toList();
          final filteredCities = availableCities
              .where((city) =>
                  city.toLowerCase().contains(searchQuery.toLowerCase()))
              .toList();
          return Container(
            height: 400,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey[300]!),
              borderRadius: BorderRadius.circular(12),
              color: Colors.white,
            ),
            child: Column(
              children: [
                TextField(
                  decoration: InputDecoration(
                    hintText: "Search cities...",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                  onChanged: (value) {
                    setModalState(() {
                      searchQuery = value;
                    });
                  },
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: ListView.builder(
                    itemCount: filteredCities.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(filteredCities[index]),
                        onTap: () {
                          setState(() {
                            _selectedCity = filteredCities[index];
                          });
                          Navigator.pop(context);
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        });
      },
    );
  }

  // Bottom sheet for law type selection.
  Future<void> _selectLawTypeBottomSheet() async {
    String searchQuery = "";
    await showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(builder: (context, setModalState) {
          final availableLawTypes =
              _lawTypes.where((s) => s != "Select law type").toList();
          final filteredTypes = availableLawTypes
              .where((type) =>
                  type.toLowerCase().contains(searchQuery.toLowerCase()))
              .toList();
          return Container(
            height: 400,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey[300]!),
              borderRadius: BorderRadius.circular(12),
              color: Colors.white,
            ),
            child: Column(
              children: [
                TextField(
                  decoration: InputDecoration(
                    hintText: "Search law types...",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                  onChanged: (value) {
                    setModalState(() {
                      searchQuery = value;
                    });
                  },
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: ListView.builder(
                    itemCount: filteredTypes.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(filteredTypes[index]),
                        onTap: () {
                          setState(() {
                            _selectedLawType = filteredTypes[index];
                          });
                          Navigator.pop(context);
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        });
      },
    );
  }

  // Validate form and proceed.
  void _onContinue() async {
    if (_formKey.currentState!.validate() &&
        _profileImage != null &&
        _selectedState != null &&
        _selectedState != 'Select your state/UT' &&
        _selectedLawType != null &&
        _selectedLawType != "Select law type" &&
        _feesController.text.isNotEmpty) {
      try {
        final prefs = await SharedPreferences.getInstance();
        final uid = prefs.getString('uid'); // From SharedPreferences

        if (uid == null) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("User ID not found in SharedPreferences.")),
          );
          return;
        }

        await saveLawyerProfile(
          profileImage: _profileImage!,
          fullName: _fullNameController.text.trim(),
          lawDegree: _lawDegreeController.text.trim(),
          state: _selectedState!,
          city: _selectedCity ?? '',
          lawType: _selectedLawType!,
          feesPerHour: int.parse(_feesController.text.trim()),
          uidFromPrefs: uid,
        );

        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => CallManagementScreen()),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Something went wrong: $e")),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please fill all required fields and upload a profile photo.'),
        ),
      );
    }
  }


  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  // Update translations using TranslationService.
  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    if (selectedLanguage != languageProvider.selectedLanguage) {
      selectedLanguage = languageProvider.selectedLanguage;
    }
    try {
      translatedTitle = await TranslationService.translate("Lawyer Profile", selectedLanguage);
      if (mounted) {
        setState(() {});
      }
    } catch (e) {
      print("Translation Error: $e");
    }
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _lawDegreeController.dispose();
    _feesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    return CustomAppBar(
      title: translatedTitle,
      icon: Icons.person,
      body: Container(
        color: Colors.white,
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.05,
            vertical: screenHeight * 0.02,
          ),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Profile Photo Section.
                Center(
                  child: GestureDetector(
                    onTap: _pickProfileImage,
                    child: Stack(
                      alignment: Alignment.bottomRight,
                      children: [
                        CircleAvatar(
                          radius: screenWidth * 0.15,
                          backgroundColor: Colors.grey[200],
                          backgroundImage: _profileImage != null
                              ? FileImage(_profileImage!)
                              : null,
                          child: _profileImage == null
                              ? Icon(
                                  Icons.camera_alt,
                                  size: screenWidth * 0.1,
                                  color: Colors.grey,
                                )
                              : null,
                        ),
                        Positioned(
                          child: CircleAvatar(
                            radius: screenWidth * 0.04,
                            backgroundColor: Colors.blue,
                            child: Icon(
                              Icons.camera_alt,
                              size: screenWidth * 0.05,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Center(
                  child: const Text(
                    'Add Profile Photo',
                    style: TextStyle(color: Colors.grey, fontSize: 14),
                  ),
                ),
                SizedBox(height: screenHeight * 0.03),
                // Full Legal Name.
                const Text(
                  'Full Legal Name',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: screenHeight * 0.01),
                TextFormField(
                  controller: _fullNameController,
                  decoration: _buildInputDecoration('Enter your full name'),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your full name';
                    }
                    return null;
                  },
                ),
                SizedBox(height: screenHeight * 0.02),
                // State of Practice.
                const Text(
                  'State of Practice',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: screenHeight * 0.01),
                InkWell(
                  onTap: _selectStateBottomSheet,
                  child: Container(
                    height: 50,
                    padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: Colors.grey[300]!),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          _selectedState ?? 'Select your state/UT',
                          style: TextStyle(
                            color: _selectedState != null ? Colors.black : Colors.grey,
                            fontSize: 14,
                          ),
                        ),
                        const Icon(Icons.arrow_drop_down, color: Colors.grey),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: screenHeight * 0.02),
                // City.
                const Text(
                  'City',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: screenHeight * 0.01),
                InkWell(
                  onTap: _selectCityBottomSheet,
                  child: Container(
                    height: 50,
                    padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: Colors.grey[300]!),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          _selectedCity ?? 'Select your city',
                          style: TextStyle(
                            color: _selectedCity != null ? Colors.black : Colors.grey,
                            fontSize: 14,
                          ),
                        ),
                        const Icon(Icons.arrow_drop_down, color: Colors.grey),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: screenHeight * 0.02),
                // Law Degree.
                const Text(
                  'Law Degree',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: screenHeight * 0.01),
                TextFormField(
                  controller: _lawDegreeController,
                  decoration: _buildInputDecoration('Enter your degree details'),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your law degree details';
                    }
                    return null;
                  },
                ),
                SizedBox(height: screenHeight * 0.02),
                // License Number.
                
        
                const Text(
                  'Fees',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: screenHeight * 0.01),
                TextFormField(
                  controller: _feesController,
                  decoration: _buildInputDecoration('Enter your fees'),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your fees';
                    }
                    return null;
                  },
                ),
                // Type of Law Practiced.
                SizedBox(height: screenHeight * 0.02),
                const Text(
                  'Type of Law Practiced',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: screenHeight * 0.01),
                InkWell(
                  onTap: _selectLawTypeBottomSheet,
                  child: Container(
                    height: 50,
                    padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: Colors.grey[300]!),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          _selectedLawType ?? 'Select law type',
                          style: TextStyle(
                            color: _selectedLawType != null ? Colors.black : Colors.grey,
                            fontSize: 14,
                          ),
                        ),
                        const Icon(Icons.arrow_drop_down, color: Colors.grey),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: screenHeight * 0.03),
                // Continue Button.
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _onContinue,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'Continue',
                      style: TextStyle(fontSize: 16, color: Colors.white),
                    ),
                  ),
                ),
                SizedBox(height: screenHeight * 0.02),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
