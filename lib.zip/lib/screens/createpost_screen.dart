import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/post_service.dart';
import '../widgets/custom_appbar.dart';
import 'package:provider/provider.dart';
import '../providers/language_provider.dart';
import '../services/translation_service.dart';

class CreateNewPostScreen extends StatefulWidget {
  const CreateNewPostScreen({super.key});

  @override
  State<CreateNewPostScreen> createState() => _CreateNewPostScreenState();
}

class _CreateNewPostScreenState extends State<CreateNewPostScreen> {
  final List<String> _categories = [
    'Corporate Law',
    'Family Law',
    'Criminal Law',
    'Copyright Law',
  ];

  // Controllers for title and post body.
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _postController = TextEditingController();

  // Scroll controller for the post body text field.
  late final ScrollController _postBodyScrollController;

  // Default selected category.
  String _selectedCategory = 'Corporate Law';

  // Holds the chosen image (if any).
  File? _selectedImage;

  // Track character count for title.
  int _titleCharCount = 0;

  // Translation variables.
  String translatedAppBarTitle = "Create New Post";
  String translatedPostTitleHeading = "Post Title";
  String translatedPostBodyHeading = "Post Body";
  String translatedTitlePlaceholder = "Title your post...";
  String translatedPostPlaceholder = "Share your legal question or thoughts...";
  String translatedSelectCategory = "Select Category";
  String translatedAddImages = "Add Images";
  String translatedGuidelines = "Guidelines";
  String translatedGuidelinesDesc =
      "Please ensure your post follows community guidelines.";
  String translatedPostButton = "Post";

  @override
  void initState() {
    super.initState();
    _postBodyScrollController = ScrollController();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _postController.dispose();
    _postBodyScrollController.dispose();
    super.dispose();
  }

  Future<void> _updateTranslations() async {
     final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    String selectedLanguage = languageProvider.selectedLanguage;
    try {
      translatedAppBarTitle =
          await TranslationService.translate("Create New Post", selectedLanguage);
      translatedPostTitleHeading =
          await TranslationService.translate("Post Title", selectedLanguage);
      translatedPostBodyHeading =
          await TranslationService.translate("Post Body", selectedLanguage);
      translatedTitlePlaceholder =
          await TranslationService.translate("Title your post...", selectedLanguage);
      translatedPostPlaceholder =
          await TranslationService.translate("Share your legal question or thoughts...", selectedLanguage);
      translatedSelectCategory =
          await TranslationService.translate("Select Category", selectedLanguage);
      translatedAddImages =
          await TranslationService.translate("Add Images", selectedLanguage);
      translatedGuidelines =
          await TranslationService.translate("Guidelines", selectedLanguage);
      translatedGuidelinesDesc =
          await TranslationService.translate("Please ensure your post follows community guidelines.", selectedLanguage);
      translatedPostButton =
          await TranslationService.translate("Post", selectedLanguage);
      if (mounted) setState(() {});
    } catch (e) {
      print("Translation Error: $e");
    }
  }

  // Picks an image from the user's gallery.
  Future<void> _pickImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? pickedFile =
        await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
      });
    }
  }

  // Called when the user taps "Post". Integrates with the PostService.
  Future<void> _onPost() async {
    try {
      await PostService().createPost(
        postTitle: _titleController.text.trim(),
        postBody: _postController.text.trim(),
        category: _selectedCategory,
        imageFile: _selectedImage,
      );
      Navigator.pop(context);
    } catch (e) {
      print("Error creating post: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to create post: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    return CustomAppBar(
      title: translatedAppBarTitle,
      icon: Icons.close,
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Post Title Heading.
            Text(
              translatedPostTitleHeading,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(8),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextField(
                controller: _titleController,
                maxLines: 1,
                maxLength: 50,
                onChanged: (value) {
                  setState(() {
                    _titleCharCount = value.length;
                  });
                },
                decoration: InputDecoration(
                  hintText: translatedTitlePlaceholder,
                  border: InputBorder.none,
                  counterText: '',
                  suffix: Text(
                    '$_titleCharCount/50',
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            // Post Body Heading.
            Text(
              translatedPostBodyHeading,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(8),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: TextField(
                controller: _postController,
                maxLines: 5,
                maxLength: 300,
                scrollController: _postBodyScrollController,
                decoration: InputDecoration(
                  hintText: translatedPostPlaceholder,
                  border: InputBorder.none,
                  counter: Align(
                    alignment: Alignment.bottomRight,
                    child: Text(
                      '${_postController.text.length}/300',
                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                  ),
                ),
                onChanged: (_) {
                  setState(() {});
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    if (_postBodyScrollController.hasClients) {
                      _postBodyScrollController.jumpTo(
                        _postBodyScrollController.position.maxScrollExtent,
                      );
                    }
                  });
                },
              ),
            ),
            const SizedBox(height: 16),
            // Select Category Heading.
            Text(
              translatedSelectCategory,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: Colors.grey[50],
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: _selectedCategory,
                  items: _categories
                      .map((cat) => DropdownMenuItem<String>(
                            value: cat,
                            child: Text(cat),
                          ))
                      .toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _selectedCategory = value;
                      });
                    }
                  },
                ),
              ),
            ),
            const SizedBox(height: 16),
            // Image Upload Heading.
            Text(
              translatedAddImages,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _pickImage,
                icon: const Icon(Icons.photo),
                label: Text(translatedAddImages),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            if (_selectedImage != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.file(
                  _selectedImage!,
                  height: 180,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
            if (_selectedImage != null) const SizedBox(height: 16),
            // Guidelines Heading.
            Text(
              translatedGuidelines,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 8),
            Text(
              translatedGuidelinesDesc,
              style: const TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _onPost,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: Text(translatedPostButton),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
