import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:project/services/availability_service.dart';
import 'package:project/widgets/custom_appbar.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CallManagementScreen extends StatefulWidget {
  const CallManagementScreen({super.key});

  @override
  State<CallManagementScreen> createState() => _CallManagementScreenState();
}

class _CallManagementScreenState extends State<CallManagementScreen> {
  // --- Tab Selection ---
  int _selectedTabIndex = 0;

  // --- Firestore: Lawyer UID ---
  String _lawyerUid = "";

  // --- Availability Variables ---
  DateTime? _selectedAvailabilityDate;
  late List<DateTime> _availabilityDates;
  final List<String> _selectedTimeSlots = [];
  final Map<DateTime, ({List<String> slots, String duration})> _individualAvailability = {};
  final List<String> _sessionDurations = ['30 Minutes', '1 Hour', '2 Hours', '3 Hours'];
  final String _defaultSessionDuration = '1 Hour';
  final Map<DateTime, String> _dateSpecificDurations = {};
  List<String> _timeSlotsList = [];

  final List<String> _scheduleTypes = ['Individual', 'Weekdays', 'Weekends', 'All Days'];
  String _selectedScheduleType = 'Individual';
  List<DateTime> _autoSelectedDates = [];

  final TextEditingController _notesController = TextEditingController();

  // Variables for locking availability
  List<String> _lockedDates = [];
  Map<String, ({List<String> slots, int duration})> _existingSlots = {};

  // Hardcoded Whereby API key
  final String _wherebyApiKey =
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmFwcGVhci5pbiIsImF1ZCI6Imh0dHBzOi8vYXBpLmFwcGVhci5pbi92MSIsImV4cCI6OTAwNzE5OTI1NDc0MDk5MSwiaWF0IjoxNzQ0MTQzODIwLCJvcmdhbml6YXRpb25JZCI6MzEzNzYxLCJqdGkiOiI2MWE0MjY3Zi03MzNjLTQ1NjAtOTE0NS03MjE3NWMzMWE4YTIifQ.E_WD2GSQAQoaq0gdAyy1JXR8py9k8qLGD8fTDtq7oNE";

  @override
  void initState() {
    super.initState();
    _loadLawyerUid();
    _availabilityDates = List.generate(7, (index) => DateTime.now().add(Duration(days: index + 1)));
    _selectedAvailabilityDate = _availabilityDates[0];
    _timeSlotsList = _generateTimeSlotsAvailability(_defaultSessionDuration);
    _updateAutoSelectedDatesAvailability();
    _loadLockedDatesAndSlots();
    _initializePermissions();
  }

  Future<void> _loadLawyerUid() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _lawyerUid = prefs.getString('uid') ?? "";
    });
  }

  Future<void> _loadLockedDatesAndSlots() async {
    if (_lawyerUid.isEmpty) return;
    final doc = await FirebaseFirestore.instance
        .collection('advoconnect_availability')
        .doc(_lawyerUid)
        .get();
    if (doc.exists) {
      final data = doc.data();
      setState(() {
        _lockedDates = List<String>.from(data?['lockedDates'] ?? []);
        _existingSlots = (data?['slots'] as Map<String, dynamic>?)?.map(
              (key, value) => MapEntry(
                key,
                (
                  slots: List<String>.from(value['slots'] ?? []),
                  duration: value['duration'] != null ? (value['duration'] as int) : 60 // Default to 60 minutes
                ),
              ),
            ) ?? {};
      });
    }
  }

  int _getDurationInMinutes(String duration) {
    if (duration.contains('30')) return 30;
    if (duration.contains('2')) return 120;
    if (duration.contains('3')) return 180;
    return 60; // Default to 1 Hour
  }

  List<String> _generateTimeSlotsAvailability(String duration) {
    int step = _getDurationInMinutes(duration);
    List<String> slots = [];
    DateTime base = DateTime(2020, 1, 1, 0, 0);
    DateTime current = base;
    while (current.day == base.day) {
      slots.add(DateFormat('HH:mm').format(current));
      current = current.add(Duration(minutes: step));
    }
    return slots;
  }

  void _updateAutoSelectedDatesAvailability() {
    if (_selectedScheduleType == 'Weekdays') {
      _autoSelectedDates = _availabilityDates
          .where((d) => d.weekday >= DateTime.monday && d.weekday <= DateTime.friday)
          .toList();
    } else if (_selectedScheduleType == 'Weekends') {
      _autoSelectedDates = _availabilityDates
          .where((d) => d.weekday == DateTime.saturday || d.weekday == DateTime.sunday)
          .toList();
    } else if (_selectedScheduleType == 'All Days') {
      _autoSelectedDates = List.from(_availabilityDates);
    } else {
      _autoSelectedDates = [];
    }
  }

  void _showAvailabilitySummaryDialog(
      Map<String, ({List<String> slots, int duration})> newlySavedSlots,
      Map<String, String> lockedReasons) {
    String message = "";
    if (newlySavedSlots.isNotEmpty) {
      message += "New timings added for the following dates:\n\n";
      newlySavedSlots.forEach((dateStr, data) {
        final parsedDate = DateTime.parse('$dateStr 00:00:00');
        final displayDuration = _getDisplayDuration(data.duration);
        message += "${DateFormat('EEE, dd MMM').format(parsedDate)}: ${data.slots.join(', ')} "
            "($displayDuration)\n";
      });
      message += "\n";
    }
    if (lockedReasons.isNotEmpty) {
      message += "For the following dates, new timings were not added because timings were already set up:\n\n";
      lockedReasons.forEach((date, reason) {
        final parsedDate = DateTime.parse('$date 00:00:00');
        message += "${DateFormat('EEE, dd MMM').format(parsedDate)}: $reason\n";
      });
    }
    if (message.isEmpty) {
      message = "No changes were made.";
    }
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Availability Summary"),
        content: SingleChildScrollView(child: Text(message)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("OK")),
        ],
      ),
    );
  }

  String _getDisplayDuration(int minutes) {
    if (minutes == 30) return '30 Minutes';
    if (minutes == 120) return '2 Hours';
    if (minutes == 180) return '3 Hours';
    return '1 Hour'; // Default
  }

  Future<void> _confirmAvailability() async {
    // Prepare slotsToSave as Map<String, ({List<String> slots, int duration})>
    Map<String, ({List<String> slots, int duration})> slotsToSave = {};
    if (_selectedScheduleType != 'Individual') {
      for (var date in _autoSelectedDates) {
        String dateKey = DateFormat('yyyy-MM-dd').format(date);
        int durationInMinutes = _getDurationInMinutes(_dateSpecificDurations[date] ?? _defaultSessionDuration);
        slotsToSave[dateKey] = (
          slots: List.from(_selectedTimeSlots),
          duration: durationInMinutes
        );
      }
    } else {
      _individualAvailability.forEach((date, data) {
        String dateKey = DateFormat('yyyy-MM-dd').format(date);
        int durationInMinutes = _getDurationInMinutes(data.duration);
        slotsToSave[dateKey] = (slots: data.slots, duration: durationInMinutes);
      });
    }

    try {
      final result = await saveAvailability(
        uid: _lawyerUid,
        slotsToSave: slotsToSave,
      );
      await _loadLockedDatesAndSlots();
      _showAvailabilitySummaryDialog(result.newlySavedSlots, result.lockedReasons);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error saving availability: $e")),
      );
    }
  }

  Future<void> _initializePermissions() async {
    await [Permission.camera, Permission.microphone].request();
  }

  Future<void> _joinWherebyMeeting(String meetingId, String userName) async {
    try {
      print("Attempting to join Whereby meeting with ID: $meetingId");
      // Fetch the roomUrl from Firestore
      final docSnapshot = await FirebaseFirestore.instance
          .collection('advoconnect_calls')
          .doc(meetingId)
          .get();
      String roomUrl = docSnapshot.data()?['roomUrl'] as String? ?? '';

      if (roomUrl.isEmpty) {
        print("No existing roomUrl found, creating new one for meeting ID: $meetingId");
        final now = DateTime.now().toUtc();
        final endTime = now.add(Duration(minutes: 60)); // Set meeting duration
        final response = await http.post(
          Uri.parse('https://api.whereby.dev/v1/meetings'),
          headers: {
            'Authorization': 'Bearer $_wherebyApiKey',
            'Content-Type': 'application/json',
          },
          body: jsonEncode({
            'startDate': now.toIso8601String(),
            'endDate': endTime.toIso8601String(),
          }),
        );

        if (response.statusCode == 201) {
          final data = jsonDecode(response.body);
          roomUrl = data['roomUrl'];
          print("Created and saved room URL: $roomUrl");
          await FirebaseFirestore.instance
              .collection('advoconnect_calls')
              .doc(meetingId)
              .set({'roomUrl': roomUrl}, SetOptions(merge: true));
          // Small delay to ensure Firestore sync
          await Future.delayed(const Duration(milliseconds: 500));
        } else {
          print("Error response: Status ${response.statusCode}, Full response: ${response.body}");
          throw 'Failed to create Whereby room: ${response.body}';
        }
      } else {
        print("Using existing roomUrl: $roomUrl");
      }

      if (await canLaunch(roomUrl)) {
        await launch(roomUrl);
        print("Launched Whereby meeting at: $roomUrl");
      } else {
        throw 'Could not launch $roomUrl';
      }
    } catch (error) {
      print("Error joining Whereby meeting: $error");
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Failed to join meeting: $error")),
        );
      }
    }
  }

  bool _isCallActive(String dateStr, String timeSlot, int sessionDuration) {
    try {
      final now = DateTime.now();
      final callDate = DateTime.parse(dateStr);
      final callTime = DateFormat('HH:mm').parse(timeSlot);
      final callStartTime = DateTime(callDate.year, callDate.month, callDate.day, callTime.hour, callTime.minute);
      final effectiveSessionDuration = sessionDuration > 0 ? sessionDuration : 60; // Default to 60 if invalid
      final callEndTime = callStartTime.add(Duration(minutes: effectiveSessionDuration));

      // Call is active (visible) on the day from 00:00 until end time
      final isDayActive = now.isAfter(DateTime(callDate.year, callDate.month, callDate.day)) &&
          now.isBefore(callEndTime);
      // Call is clickable only within the session duration window (±5 minutes for buffer)
      final isTimeMatched = now.isAfter(callStartTime.subtract(const Duration(minutes: 5))) &&
          now.isBefore(callEndTime.add(const Duration(minutes: 5)));

      return isDayActive && isTimeMatched;
    } catch (e) {
      print("Error in _isCallActive: $e");
      return false;
    }
  }

  // Helper to calculate call end time
  DateTime _calculateCallEndTime(String dateStr, String timeSlot, int sessionDuration) {
    final callDate = DateTime.parse(dateStr);
    final callTime = DateFormat('HH:mm').parse(timeSlot);
    final callStartTime = DateTime(callDate.year, callDate.month, callDate.day, callTime.hour, callTime.minute);
    final effectiveSessionDuration = sessionDuration > 0 ? sessionDuration : 60; // Default to 60 if invalid
    return callStartTime.add(Duration(minutes: effectiveSessionDuration));
  }

  Stream<QuerySnapshot> _upcomingCallsStream() {
    final now = DateTime.now();
    return FirebaseFirestore.instance
        .collection('advoconnect_calls')
        .where('lawyerId', isEqualTo: _lawyerUid)
        .snapshots();
  }

  Stream<QuerySnapshot> _pastCallsStream() {
    final now = DateTime.now();
    return FirebaseFirestore.instance
        .collection('advoconnect_calls')
        .where('lawyerId', isEqualTo: _lawyerUid)
        .snapshots();
  }

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return CustomAppBar(
      title: "Call Management",
      icon: Icons.phone,
      body: Container(
        width: size.width,
        height: size.height,
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _selectedTabIndex = 0),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          "Upcoming Calls",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: _selectedTabIndex == 0 ? Colors.blue.shade900 : Colors.blue.shade300,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Container(
                          height: 2,
                          color: _selectedTabIndex == 0 ? Colors.blue : Colors.transparent,
                        ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _selectedTabIndex = 1),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          "Past Calls",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: _selectedTabIndex == 1 ? Colors.blue.shade900 : Colors.blue.shade300,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Container(
                          height: 2,
                          color: _selectedTabIndex == 1 ? Colors.blue : Colors.transparent,
                        ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _selectedTabIndex = 2),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          "Set Availability",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: _selectedTabIndex == 2 ? Colors.blue.shade900 : Colors.blue.shade300,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Container(
                          height: 2,
                          color: _selectedTabIndex == 2 ? Colors.blue : Colors.transparent,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: _lawyerUid.isEmpty
                  ? const Center(child: CircularProgressIndicator())
                  : _selectedTabIndex == 0
                      ? _buildUpcomingCallsTab()
                      : _selectedTabIndex == 1
                          ? _buildPastCallsTab()
                          : _buildSetAvailabilityTab(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUpcomingCallsTab() {
    return StreamBuilder<QuerySnapshot>(
      stream: _upcomingCallsStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text("Error: ${snapshot.error}"));
        }
        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Center(child: Text("No upcoming calls."));
        }
        final calls = snapshot.data!.docs.where((doc) {
          final data = doc.data() as Map<String, dynamic>;
          final date = data['date'] ?? "";
          final timeSlot = data['timeSlot'] ?? "";
          final sessionDuration = data['sessionDuration'] ?? 60;
          final callEndTime = _calculateCallEndTime(date, timeSlot, sessionDuration);
          return callEndTime.isAfter(DateTime.now());
        }).toList();
        if (calls.isEmpty) {
          return const Center(child: Text("No upcoming calls."));
        }
        return FutureBuilder<DocumentSnapshot>(
          future: FirebaseFirestore.instance
              .collection('advoconnect_lawyers')
              .doc(_lawyerUid)
              .get(),
          builder: (context, lawyerSnapshot) {
            if (lawyerSnapshot.hasError || !lawyerSnapshot.hasData) {
              return Center(child: Text("Error loading lawyer info: ${lawyerSnapshot.error}"));
            }
            final lawyerData = lawyerSnapshot.data!.data() as Map<String, dynamic>? ?? {};
            final lawyerName = lawyerData['name'] ?? "Lawyer";
            final lawyerType = lawyerData['lawyerType'] ?? "Unknown";
            final profileImageUrl = lawyerData['profileImageUrl'] ?? "";
            final feesPerHour = lawyerData['feesPerHour'] ?? 0;

            return ListView.builder(
              itemCount: calls.length,
              itemBuilder: (context, index) {
                final data = calls[index].data() as Map<String, dynamic>;
                final callId = calls[index].id;
                final date = data['date'] ?? "";
                final timeSlot = data['timeSlot'] ?? "";
                final sessionDuration = data['sessionDuration'] ?? 60; // Fetch session duration
                final isActive = _isCallActive(date, timeSlot, sessionDuration);

                return _buildCallCard(
                  date: date,
                  timeSlot: timeSlot,
                  callId: callId,
                  lawyerName: lawyerName,
                  lawyerType: lawyerType,
                  profileImageUrl: profileImageUrl,
                  feesPerHour: feesPerHour,
                  isUpcoming: true,
                  isActive: isActive,
                );
              },
            );
          },
        );
      },
    );
  }

  Widget _buildPastCallsTab() {
    return StreamBuilder<QuerySnapshot>(
      stream: _pastCallsStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text("Error: ${snapshot.error}"));
        }
        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Center(child: Text("No past calls."));
        }
        final calls = snapshot.data!.docs.where((doc) {
          final data = doc.data() as Map<String, dynamic>;
          final date = data['date'] ?? "";
          final timeSlot = data['timeSlot'] ?? "";
          final sessionDuration = data['sessionDuration'] ?? 60;
          final callEndTime = _calculateCallEndTime(date, timeSlot, sessionDuration);
          return callEndTime.isBefore(DateTime.now());
        }).toList();
        if (calls.isEmpty) {
          return const Center(child: Text("No past calls."));
        }
        return FutureBuilder<DocumentSnapshot>(
          future: FirebaseFirestore.instance
              .collection('advoconnect_lawyers')
              .doc(_lawyerUid)
              .get(),
          builder: (context, lawyerSnapshot) {
            if (lawyerSnapshot.hasError || !lawyerSnapshot.hasData) {
              return Center(child: Text("Error loading lawyer info: ${lawyerSnapshot.error}"));
            }
            final lawyerData = lawyerSnapshot.data!.data() as Map<String, dynamic>? ?? {};
            final lawyerName = lawyerData['name'] ?? "Lawyer";
            final lawyerType = lawyerData['lawyerType'] ?? "Unknown";
            final profileImageUrl = lawyerData['profileImageUrl'] ?? "";
            final feesPerHour = lawyerData['feesPerHour'] ?? 0;

            return ListView.builder(
              itemCount: calls.length,
              itemBuilder: (context, index) {
                final data = calls[index].data() as Map<String, dynamic>;
                final callId = calls[index].id;
                final date = data['date'] ?? "";
                final timeSlot = data['timeSlot'] ?? "";
                final sessionDuration = data['sessionDuration'] ?? 60; // Fetch session duration

                return _buildCallCard(
                  date: date,
                  timeSlot: timeSlot,
                  callId: callId,
                  lawyerName: lawyerName,
                  lawyerType: lawyerType,
                  profileImageUrl: profileImageUrl,
                  feesPerHour: feesPerHour,
                  isUpcoming: false,
                  isActive: false,
                );
              },
            );
          },
        );
      },
    );
  }

  Widget _buildCallCard({
    required String date,
    required String timeSlot,
    required String callId,
    required String lawyerName,
    required String lawyerType,
    required String profileImageUrl,
    required int feesPerHour,
    required bool isUpcoming,
    required bool isActive,
  }) {
    final callDate = DateTime.tryParse(date) ?? DateTime.now();
    final formattedDate = DateFormat('dd MMM, yyyy').format(callDate);
    final formattedTime = DateFormat('hh:mm a').format(DateFormat('HH:mm').parse(timeSlot));

    return FutureBuilder<DocumentSnapshot>(
      future: FirebaseFirestore.instance
          .collection('advoconnect_calls')
          .doc(callId)
          .get(),
      builder: (context, callSnapshot) {
        if (callSnapshot.hasError) {
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade800),
            ),
            child: const Text("Error loading call details"),
          );
        }
        if (!callSnapshot.hasData) {
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade800),
            ),
            child: const Text("No call data available"),
          );
        }

        final callData = callSnapshot.data!.data() as Map<String, dynamic>? ?? {};
        final userId = callData['userId'] ?? '';
        final sessionDuration = callData['sessionDuration'] ?? 60; // Default to 60 if missing

        return FutureBuilder<DocumentSnapshot>(
          future: FirebaseFirestore.instance
              .collection('users')
              .doc(userId)
              .get(),
          builder: (context, userSnapshot) {
            if (userSnapshot.hasError) {
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade800),
                ),
                child: const Text("Error loading user details"),
              );
            }
            if (!userSnapshot.hasData) {
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade800),
                ),
                child: const Text("No user data available"),
              );
            }

            final userData = userSnapshot.data!.data() as Map<String, dynamic>? ?? {};
            final userName = userData['name'] ?? 'Unknown';
            final userPhotoUrl = userData['photoURL'] ?? '';
            final userProfession = userData['profession'] ?? 'Unknown';
            final userBackgroundImage = userPhotoUrl.isNotEmpty
                ? NetworkImage(userPhotoUrl) as ImageProvider
                : const AssetImage('assets/default_avatar.png') as ImageProvider;

            // Check call activity with session duration
            final isCallActive = _isCallActive(date, timeSlot, sessionDuration);

            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.shade800),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      CircleAvatar(
                        radius: 20,
                        backgroundImage: profileImageUrl.isNotEmpty
                            ? NetworkImage(profileImageUrl)
                            : const AssetImage('assets/default_avatar.png'),
                        child: profileImageUrl.isEmpty
                            ? Text(lawyerName.isNotEmpty ? lawyerName[0].toUpperCase() : 'L',
                                style: const TextStyle(fontSize: 20))
                            : null,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              lawyerName,
                              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                            Text(
                              lawyerType,
                              style: const TextStyle(fontSize: 14, color: Colors.grey),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                            Text(
                              '₹$feesPerHour / session',
                              style: const TextStyle(fontSize: 14, color: Colors.green),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                          ],
                        ),
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                userName,
                                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                              Text(
                                userProfession,
                                style: const TextStyle(fontSize: 14, color: Colors.grey),
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                            ],
                          ),
                          const SizedBox(width: 4),
                          CircleAvatar(
                            radius: 20,
                            backgroundImage: userBackgroundImage,
                            child: userPhotoUrl.isEmpty
                                ? Text(userName.isNotEmpty ? userName[0].toUpperCase() : 'U',
                                    style: const TextStyle(fontSize: 20))
                                : null,
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.calendar_today, color: Colors.blue),
                                const SizedBox(width: 4),
                                Text('Date: $formattedDate',
                                    style: const TextStyle(fontSize: 14, color: Colors.blue)),
                              ],
                            ),
                          ),
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.access_time, color: Colors.blue),
                                const SizedBox(width: 4),
                                Text('Time: $formattedTime',
                                    style: const TextStyle(fontSize: 14, color: Colors.blue)),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.timer, color: Colors.blue),
                                const SizedBox(width: 4),
                                Text(
                                  'Duration: $sessionDuration minutes',
                                  style: const TextStyle(fontSize: 14, color: Colors.blue),
                                ),
                              ],
                            ),
                          ),
                          Expanded(
                            child: isUpcoming && isCallActive
                                ? ElevatedButton(
                                    onPressed: () async {
                                      await _joinWherebyMeeting(callId, lawyerName);
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.blue,
                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                    ),
                                    child: const Text(
                                      "JOIN",
                                      style: TextStyle(
                                          fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white),
                                    ),
                                  )
                                : isUpcoming
                                    ? ElevatedButton(
                                        onPressed: null, // Non-clickable
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.black,
                                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                        ),
                                        child: const Text(
                                          "JOIN",
                                          style: TextStyle(
                                              fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white),
                                        ),
                                      )
                                    : Text(
                                        'Call Completed',
                                        style: const TextStyle(
                                            fontSize: 14, fontWeight: FontWeight.w600, color: Colors.grey),
                                      ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildSetAvailabilityTab() {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(
        horizontal: screenWidth * 0.05,
        vertical: screenHeight * 0.02,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Set Your Availability',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black),
          ),
          SizedBox(height: screenHeight * 0.005),
          const Text(
            'Schedule your online consultation slots',
            style: TextStyle(fontSize: 14, color: Colors.grey),
          ),
          SizedBox(height: screenHeight * 0.03),
          _buildScheduleTypeBar(),
          SizedBox(height: screenHeight * 0.02),
          const Text(
            'Choose available days:',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black),
          ),
          SizedBox(height: screenHeight * 0.01),
          _buildAvailabilityDateRow(),
          SizedBox(height: screenHeight * 0.03),
          const Text(
            'Session Duration (per date)',
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.black),
          ),
          SizedBox(height: screenHeight * 0.01),
          _buildDurationPicker(),
          SizedBox(height: screenHeight * 0.03),
          const Text(
            'Available Time Slots',
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.black),
          ),
          SizedBox(height: screenHeight * 0.01),
          _selectedScheduleType == 'Individual'
              ? _buildIndividualTimeSlots()
              : _buildTimeSlotsGrid(),
          SizedBox(height: screenHeight * 0.03),
          const Text(
            'Add notes about your availability (optional)',
            style: TextStyle(fontSize: 14, color: Colors.grey),
          ),
          SizedBox(height: screenHeight * 0.01),
          TextField(
            controller: _notesController,
            maxLines: 3,
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(color: Colors.grey[300]!),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
              filled: true,
              fillColor: Colors.white,
            ),
          ),
          SizedBox(height: screenHeight * 0.03),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                if (_selectedScheduleType != 'Individual') {
                  if (_autoSelectedDates.isEmpty || _selectedTimeSlots.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Please select at least one date and one time slot.')),
                    );
                    return;
                  }
                } else {
                  if (_individualAvailability.isEmpty ||
                      _individualAvailability.values.any((data) => data.slots.isEmpty)) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Please fill time slots for all selected dates.')),
                    );
                    return;
                  }
                }
                _confirmAvailability();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                padding: const EdgeInsets.symmetric(vertical: 15),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text(
                'Confirm Availability',
                style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          SizedBox(height: screenHeight * 0.02),
        ],
      ),
    );
  }

  Widget _buildScheduleTypeBar() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: _scheduleTypes.map((type) {
          final isSelected = _selectedScheduleType == type;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: GestureDetector(
              onTap: () {
                setState(() {
                  _selectedScheduleType = type;
                  if (type != 'Individual') {
                    _updateAutoSelectedDatesAvailability();
                    _selectedTimeSlots.clear();
                  } else {
                    _individualAvailability.clear();
                  }
                });
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: isSelected ? Colors.blue : Colors.white,
                  border: Border.all(color: Colors.grey[300]!),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  type,
                  style: TextStyle(fontSize: 14, color: isSelected ? Colors.white : Colors.black),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildAvailabilityDateRow() {
    final screenWidth = MediaQuery.of(context).size.width;
    final horizontalPadding = screenWidth * 0.05;
    final availableWidth = screenWidth - (2 * horizontalPadding);
    const spacing = 10.0;
    final cardWidth = (availableWidth - (3 * spacing)) / 4;
    return Scrollbar(
      thumbVisibility: true,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: _availabilityDates.map((date) {
            final dateKey = DateFormat('yyyy-MM-dd').format(date);
            final isLocked = _lockedDates.contains(dateKey);
            bool isSelected;
            if (_selectedScheduleType == 'Individual') {
              isSelected = _individualAvailability.containsKey(date);
            } else {
              isSelected = _autoSelectedDates.contains(date);
            }
            return Padding(
              padding: const EdgeInsets.only(right: spacing),
              child: GestureDetector(
                onTap: isLocked
                    ? () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text("This date is locked (already submitted).")),
                        );
                      }
                    : () {
                        setState(() {
                          _selectedAvailabilityDate = date;
                          _selectedTimeSlots.clear();
                          if (!_dateSpecificDurations.containsKey(date)) {
                            _dateSpecificDurations[date] = _defaultSessionDuration;
                          }
                          _timeSlotsList = _generateTimeSlotsAvailability(_dateSpecificDurations[date]!);
                          if (_selectedScheduleType == 'Individual' && !_individualAvailability.containsKey(date)) {
                            _individualAvailability[date] = (slots: [], duration: _dateSpecificDurations[date]!);
                          }
                        });
                      },
                child: Container(
                  width: cardWidth,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  decoration: BoxDecoration(
                    color: isSelected ? Colors.blue : Colors.white,
                    border: Border.all(color: Colors.grey[300]!),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        DateFormat('EEE').format(date),
                        style: TextStyle(
                          fontSize: 12,
                          color: isSelected ? Colors.white : Colors.black,
                        ),
                      ),
                      Text(
                        DateFormat('dd MMM').format(date),
                        style: TextStyle(
                          fontSize: 14,
                          color: isSelected ? Colors.white : Colors.black,
                        ),
                      ),
                      if (isLocked)
                        Container(
                          margin: const EdgeInsets.only(top: 4),
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: Colors.redAccent,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Text("Locked", style: TextStyle(color: Colors.white, fontSize: 10)),
                        ),
                    ],
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildDurationPicker() {
    return Column(
      children: (_selectedScheduleType == 'Individual'
              ? _individualAvailability.keys.toList()
              : _autoSelectedDates)
          .map((date) {
        final currentDuration = _dateSpecificDurations[date] ?? _defaultSessionDuration;
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 8.0),
          child: Row(
            children: [
              Text(
                "${DateFormat('EEE, dd MMM').format(date)} Duration: ",
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
              ),
              DropdownButton<String>(
                value: currentDuration,
                items: _sessionDurations.map((duration) {
                  return DropdownMenuItem<String>(
                    value: duration,
                    child: Text(duration),
                  );
                }).toList(),
                onChanged: (newValue) {
                  setState(() {
                    _dateSpecificDurations[date] = newValue!;
                    if (_selectedScheduleType == 'Individual') {
                      _individualAvailability[date] =
                          (slots: _individualAvailability[date]?.slots ?? [], duration: newValue);
                    }
                    _timeSlotsList = _generateTimeSlotsAvailability(newValue);
                    _selectedTimeSlots.clear(); // Reset slots based on new duration
                  });
                },
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildTimeSlotsGrid() {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.3,
      child: GridView.builder(
        physics: const BouncingScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: 2.5,
        ),
        itemCount: _timeSlotsList.length,
        itemBuilder: (context, index) {
          final timeSlot = _timeSlotsList[index];
          final isSelected = _selectedTimeSlots.contains(timeSlot);
          return GestureDetector(
            onTap: () {
              setState(() {
                if (isSelected) {
                  _selectedTimeSlots.remove(timeSlot);
                } else {
                  _selectedTimeSlots.add(timeSlot);
                }
              });
            },
            child: Container(
              decoration: BoxDecoration(
                color: isSelected ? Colors.blue : Colors.white,
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Center(
                child: Text(
                  timeSlot,
                  style: TextStyle(fontSize: 12, color: isSelected ? Colors.white : Colors.black),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildIndividualTimeSlots() {
    return Column(
      children: _individualAvailability.entries.map((entry) {
        DateTime date = entry.key;
        var data = entry.value;
        List<String> dateSpecificTimeSlots = _generateTimeSlotsAvailability(data.duration);
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              DateFormat('EEE, dd MMM').format(date),
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.25,
              child: GridView.builder(
                physics: const BouncingScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 2.5,
                ),
                itemCount: dateSpecificTimeSlots.length,
                itemBuilder: (context, index) {
                  final timeSlot = dateSpecificTimeSlots[index];
                  final isSelected = data.slots.contains(timeSlot);
                  return GestureDetector(
                    onTap: () {
                      setState(() {
                        if (isSelected) {
                          data = (slots: List.from(data.slots)..remove(timeSlot), duration: data.duration);
                        } else {
                          data = (slots: List.from(data.slots)..add(timeSlot), duration: data.duration);
                        }
                        _individualAvailability[date] = data;
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: isSelected ? Colors.blue : Colors.white,
                        border: Border.all(color: Colors.grey[300]!),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Center(
                        child: Text(
                          timeSlot,
                          style: TextStyle(fontSize: 12, color: isSelected ? Colors.white : Colors.black),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 20),
          ],
        );
      }).toList(),
    );
  }
}