import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:provider/provider.dart';

// Import your custom app bar
import '../widgets/custom_appbar.dart';
import '../providers/language_provider.dart';
import '../services/translation_service.dart';

class CyberSimplificationScreen extends StatefulWidget {
  const CyberSimplificationScreen({super.key});

  @override
  _CyberSimplificationScreenState createState() => _CyberSimplificationScreenState();
}

class _CyberSimplificationScreenState extends State<CyberSimplificationScreen> {
  final FlutterTts flutterTts = FlutterTts();

  // Local data for the articles (frontend only)
  final List<Map<String, String>> _articles = [
    {
      "title": "Article 19(1)(a)",
      "part": "Part III",
      "simplifiedText": "Grants freedom of speech and expression, including on digital platforms.",
      "exampleScenario":
          "A citizen posts opinions on social media without government censorship, as long as they respect reasonable restrictions.",
      "originalArticle":
          "Freedom of speech and expression (includes digital expression)."
    },
    {
      "title": "Article 19(1)(g)",
      "part": "Part III",
      "simplifiedText":
          "Allows any person to practice a profession or run a business, including online enterprises.",
      "exampleScenario":
          "A web designer sets up a freelance website to offer services globally without undue restrictions.",
      "originalArticle":
          "Right to practice any profession or to carry on any occupation, trade, or business (relevant for online businesses)."
    },
    {
      "title": "Article 19(2)",
      "part": "Part III",
      "simplifiedText":
          "Specifies reasonable limitations on free speech, applicable to digital content as well.",
      "exampleScenario":
          "Online posts containing hate speech or defamation can be lawfully restricted or penalized.",
      "originalArticle":
          "Reasonable restrictions on freedom of speech and expression (relevant for regulating online content)."
    },
    {
      "title": "Article 21",
      "part": "Part III",
      "simplifiedText":
          "Safeguards personal liberty and privacy rights in the digital sphere.",
      "exampleScenario":
          "Individuals can challenge unauthorized surveillance or data collection that infringes on their right to privacy.",
      "originalArticle":
          "Protection of life and personal liberty (includes privacy rights in the digital space)."
    },
    {
      "title": "Article 51A(g)",
      "part": "Part IVA",
      "simplifiedText":
          "Highlights citizens’ duty to protect the environment, extended to digital ecosystems (like safe e-waste disposal).",
      "exampleScenario":
          "Encouraging responsible electronic recycling programs and limiting harmful digital resource usage.",
      "originalArticle":
          "Fundamental Duty to protect and improve the natural environment, including forests, lakes, rivers, and wildlife (can be extended to digital ecosystems)."
    },
    {
      "title": "Article 38",
      "part": "Part IV",
      "simplifiedText":
          "Requires the State to promote the welfare of citizens, including ensuring a safer cyberspace.",
      "exampleScenario":
          "Governments may introduce policies or laws to protect users from online fraud and cyberbullying.",
      "originalArticle":
          "State to secure a social order for the promotion of welfare of the people (can be applied to ensure safe cyberspace)."
    },
    {
      "title": "Article 39(e)",
      "part": "Part IV",
      "simplifiedText":
          "Focuses on protecting vulnerable groups (like children) from exploitation, including online exploitation.",
      "exampleScenario":
          "Regulations preventing child labor or sexual exploitation through digital platforms or social media.",
      "originalArticle":
          "The State shall direct its policy towards securing that the health and strength of workers, men and women, and the tender age of children are not abused (relevant for child protection online)."
    }
  ];

  // Translated screen title and articles.
  String _translatedScreenTitle = "Article Simplifications";
  List<Map<String, String>> _translatedArticles = [];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  /// Update translations for the screen title and all article fields.
  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final selectedLanguage = languageProvider.selectedLanguage;

    try {
      // Translate the screen title.
      _translatedScreenTitle = await TranslationService.translate(
        "Article Simplifications",
        selectedLanguage,
      );

      // Translate each article's fields.
      List<Map<String, String>> newArticles = [];
      for (var article in _articles) {
        final tTitle = await TranslationService.translate(article['title']!, selectedLanguage);
        final tPart = await TranslationService.translate(article['part']!, selectedLanguage);
        final tSimplifiedText =
            await TranslationService.translate(article['simplifiedText']!, selectedLanguage);
        final tExampleScenario =
            await TranslationService.translate(article['exampleScenario']!, selectedLanguage);
        final tOriginalArticle =
            await TranslationService.translate(article['originalArticle']!, selectedLanguage);

        newArticles.add({
          "title": tTitle,
          "part": tPart,
          "simplifiedText": tSimplifiedText,
          "exampleScenario": tExampleScenario,
          "originalArticle": tOriginalArticle,
        });
      }

      if (mounted) {
        setState(() {
          _translatedArticles = newArticles;
        });
      }
    } catch (e) {
      debugPrint("❌ Translation error: $e");
    }
  }

  /// Text-to-speech functionality.
  void _speak(String text) async {
    await flutterTts.speak(text);
  }

  @override
  Widget build(BuildContext context) {
    return CustomAppBar(
      title: _translatedScreenTitle,
      icon: Icons.article,
      body: ListView.builder(
        padding: const EdgeInsets.all(12.0),
        itemCount: _translatedArticles.length,
        itemBuilder: (context, index) {
          final article = _translatedArticles[index];
          return Container(
            margin: const EdgeInsets.symmetric(vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.blue),
              borderRadius: BorderRadius.circular(8),
            ),
            child: ListTile(
              leading: const Icon(Icons.article, color: Colors.blue),
              title: Text(
                article["title"] ?? "",
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              trailing: const Icon(Icons.chevron_right, color: Colors.blue),
              onTap: () {
                _showArticleDialog(article);
              },
            ),
          );
        },
      ),
    );
  }

  /// Displays an AlertDialog with detailed article information.
  void _showArticleDialog(Map<String, String> article) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(article["title"] ?? ""),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildDialogSection("📌 Part", article["part"]),
                _buildDialogSection("📜 Simplified Text", article["simplifiedText"]),
                _buildDialogSection("💡 Example/Scenario", article["exampleScenario"]),
                _buildDialogSection("📖 Original Article", article["originalArticle"]),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: () => _speak(article["simplifiedText"] ?? ""),
                  icon: const Icon(Icons.volume_up),
                  label: const Text("Read Aloud"),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Close", style: TextStyle(color: Colors.blueAccent)),
            )
          ],
        );
      },
    );
  }

  /// Helper widget for formatting dialog sections.
  Widget _buildDialogSection(String title, String? content) {
    if (content == null || content.isEmpty) return const SizedBox();
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.blueAccent,
            ),
          ),
          const SizedBox(height: 5),
          Text(content, style: const TextStyle(fontSize: 14)),
        ],
      ),
    );
  }
}
