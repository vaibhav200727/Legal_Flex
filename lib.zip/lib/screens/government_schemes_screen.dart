import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../data/gov_schemes_data.dart';
import '../services/translation_service.dart';
import '../providers/language_provider.dart';
import '../widgets/custom_appbar.dart';

class SchemeDetailsPage extends StatefulWidget {
  final int schemeIndex; // pass this from the HomeScreen carousel

  const SchemeDetailsPage({super.key, required this.schemeIndex});

  @override
  State<SchemeDetailsPage> createState() => _SchemeDetailsPageState();
}

class _SchemeDetailsPageState extends State<SchemeDetailsPage> {
  String selectedLanguage = "en";

  // Translated labels
  String translatedApplyNow = "Apply Now";
  String translatedEligibility = "Eligibility";
  String translatedDocuments = "Required Documents";
  String translatedAuthority = "Providing Authority";
  String translatedFounded = "Founded Year";

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateTranslations();
  }

  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    selectedLanguage = languageProvider.selectedLanguage;

    try {
      translatedApplyNow = await TranslationService.translate("Apply Now", selectedLanguage);
      translatedEligibility = await TranslationService.translate("Eligibility", selectedLanguage);
      translatedDocuments = await TranslationService.translate("Required Documents", selectedLanguage);
      translatedAuthority = await TranslationService.translate("Providing Authority", selectedLanguage);
      translatedFounded = await TranslationService.translate("Founded Year", selectedLanguage);

      if (mounted) setState(() {});
    } catch (e) {
      debugPrint("❌ Translation Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final double screenWidth = MediaQuery.of(context).size.width;

    // Fetch selected scheme from dataset
    final scheme = lawWelfareSchemes[widget.schemeIndex];

    return CustomAppBar(
      title: scheme['title'],
      icon: Icons.account_balance,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // IMAGE
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network(
                scheme['imageUrl'],
                width: screenWidth,
                height: screenWidth * 0.5,
                fit: BoxFit.cover,
              ),
            ),

            const SizedBox(height: 16),

            // DESCRIPTION
            Text(
              scheme['description'],
              style: TextStyle(
                fontSize: 16,
                color: isDark ? Colors.white70 : Colors.black87,
              ),
            ),

            const SizedBox(height: 24),

            _buildInfoTile(translatedFounded, scheme['foundedYear'], isDark),
            _buildInfoTile(translatedEligibility, scheme['eligibility'], isDark),
            _buildInfoTile(translatedDocuments, scheme['documents'], isDark),
            _buildInfoTile(translatedAuthority, scheme['authority'], isDark),

            const SizedBox(height: 30),

            Center(
              child: ElevatedButton.icon(
                icon: const Icon(Icons.open_in_new),
                label: Text(translatedApplyNow),
                onPressed: () async {
                  final url = Uri.parse(scheme['applicationLink']);
                  if (await canLaunchUrl(url)) {
                    launchUrl(url, mode: LaunchMode.externalApplication);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text("Could not open link")),
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoTile(String label, String value, bool isDark) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: RichText(
        text: TextSpan(
          style: TextStyle(
            fontSize: 15,
            color: isDark ? Colors.white70 : Colors.black87,
          ),
          children: [
            TextSpan(
              text: "$label: ",
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            TextSpan(text: value),
          ],
        ),
      ),
    );
  }
}
