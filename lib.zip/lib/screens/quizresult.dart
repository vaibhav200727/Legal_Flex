import 'package:flutter/material.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:lottie/lottie.dart';

class ScoreCardScreen extends StatelessWidget {
  final int score;
  final int total;

  const ScoreCardScreen({
    super.key,
    required this.score,
    required this.total,
  });

  // Example function to pick a color based on the score.
  // Adjust ranges and colors as desired.
  Color _getProgressColor(int score, int total) {
    double ratio = score / total;
    if (ratio < 0.3) {
      return Colors.orange; // Low score
    } else if (ratio < 0.6) {
      return Colors.yellow; // Medium-low
    } else if (ratio < 0.9) {
      return Colors.blue;   // Medium-high
    } else {
      return Colors.green;  // Excellent
    }
  }

  @override
  Widget build(BuildContext context) {
    final double percentage = (score / total);
    final int incorrect = total - score;

    return Scaffold(
      // White background for a clean look
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
        title: const Text("Score Card"),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // 1. Lottie Animation at the top
            // Replace this URL or path with your own Lottie file.
            // For a local asset, use: Lottie.asset('assets/your_file.json')
            SizedBox(
              height: 180,
              child: Lottie.asset(
                'assets/animations/trophy.json',
                fit: BoxFit.contain,
              ),
            ),
            const SizedBox(height: 20),

            // 2. Custom message
            // You can tweak the text to mimic “You have played a total of XX quizzes”
            Text(
              "You completed the quiz!",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.grey.shade800,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Here is your performance summary:",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey.shade600,
              ),
            ),
            const SizedBox(height: 30),

            // 3. Circular Percent Indicator
            CircularPercentIndicator(
              radius: 100.0,
              lineWidth: 18.0,
              animation: true,
              percent: percentage, // between 0.0 and 1.0
              center: Text(
                "$score / $total",
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20.0,
                ),
              ),
              circularStrokeCap: CircularStrokeCap.round,
              progressColor: _getProgressColor(score, total),
              backgroundColor: Colors.grey.shade200,
            ),
            const SizedBox(height: 30),

            // 4. Display correct and incorrect answers
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildStatCard(
                  label: "Correct",
                  value: "$score",
                  color: Colors.green,
                ),
                _buildStatCard(
                  label: "Incorrect",
                  value: "$incorrect",
                  color: Colors.redAccent,
                ),
              ],
            ),
            const SizedBox(height: 30),

            // 5. Percentage text or any additional summary
            Text(
              "Percentage: ${(percentage * 100).toStringAsFixed(1)}%",
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey.shade700,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 40),

            // 6. Restart quiz button
            ElevatedButton(
              onPressed: () {
                // Navigate back or restart the quiz
                Navigator.pop(context); // or pushReplacement for your quiz screen
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: _getProgressColor(score, total),
                padding: const EdgeInsets.symmetric(
                  vertical: 16,
                  horizontal: 40,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text(
                "Restart Quiz",
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Helper widget to display a small stats card (for correct/incorrect).
  Widget _buildStatCard({
    required String label,
    required String value,
    required Color color,
  }) {
    return Container(
      width: 120,
      padding: const EdgeInsets.symmetric(vertical: 20),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: TextStyle(
              fontSize: 16,
              color: color.withOpacity(0.8),
            ),
          ),
        ],
),
);
}
}