import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class CommentCard extends StatefulWidget {
  final String postId;
  final String commentId;
  final String commenterName;
  final String commenterPhotoUrl;
  final String commentText;
  final String postAuthorName;
  final String repliedTo;
  final String repliedContext;
  final Timestamp timestamp; // For sorting compatibility
  final int likeCount;
  final int dislikeCount;
  final String currentUserId;
  final String parentCommentId;
  final Future<void> Function(String, String, String, String) onToggleReaction;
  final VoidCallback onReply;
  final bool isReply;

  const CommentCard({
    super.key,
    required this.postId,
    required this.commentId,
    required this.commenterName,
    required this.commenterPhotoUrl,
    required this.commentText,
    required this.postAuthorName,
    required this.repliedTo,
    required this.repliedContext,
    required this.timestamp,
    required this.likeCount,
    required this.dislikeCount,
    required this.currentUserId,
    required this.parentCommentId,
    required this.onToggleReaction,
    required this.onReply,
    required this.isReply,
  });

  @override
  State<CommentCard> createState() => _CommentCardState();
}

class _CommentCardState extends State<CommentCard> {
  @override
  Widget build(BuildContext context) {
    final formattedTimestamp = _formatTimestamp(widget.timestamp);

    // Build the reply label.
    final String replyLabel = widget.isReply
        ? "↳ Replied to @${widget.repliedTo}'s ${widget.repliedContext.toLowerCase()}"
        : (widget.repliedTo.isEmpty && widget.repliedContext == "post"
            ? "Commented on @${widget.postAuthorName}'s post"
            : "");

    // Build the reaction stream.
    final Stream<DocumentSnapshot> reactionStream = widget.isReply
        ? FirebaseFirestore.instance
            .collection('forum_posts')
            .doc(widget.postId)
            .collection('comments')
            .doc(widget.parentCommentId)
            .collection('replies')
            .doc(widget.commentId)
            .collection('reactions')
            .doc(widget.currentUserId)
            .snapshots()
        : FirebaseFirestore.instance
            .collection('forum_posts')
            .doc(widget.postId)
            .collection('comments')
            .doc(widget.commentId)
            .collection('reactions')
            .doc(widget.currentUserId)
            .snapshots();

    return StreamBuilder<DocumentSnapshot>(
      stream: widget.isReply
          ? FirebaseFirestore.instance
              .collection('forum_posts')
              .doc(widget.postId)
              .collection('comments')
              .doc(widget.parentCommentId)
              .collection('replies')
              .doc(widget.commentId)
              .snapshots()
          : FirebaseFirestore.instance
              .collection('forum_posts')
              .doc(widget.postId)
              .collection('comments')
              .doc(widget.commentId)
              .snapshots(),
      builder: (context, commentSnapshot) {
        int updatedLikeCount = widget.likeCount;
        int updatedDislikeCount = widget.dislikeCount;
        if (commentSnapshot.hasData && commentSnapshot.data!.exists) {
          final data = commentSnapshot.data!.data() as Map<String, dynamic>;
          updatedLikeCount = data['likes'] ?? widget.likeCount;
          updatedDislikeCount = data['dislikes'] ?? widget.dislikeCount;
        }

        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          padding: const EdgeInsets.all(12),
          // Transparent background (no color, no shadows)
          decoration: const BoxDecoration(
            color: Colors.transparent,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header row: Avatar, Commenter's name, timestamp.
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  widget.commenterPhotoUrl.isNotEmpty
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: Image.network(
                            widget.commenterPhotoUrl,
                            height: 40,
                            width: 40,
                            fit: BoxFit.cover,
                          ),
                        )
                      : Container(
                          height: 40,
                          width: 40,
                          decoration: BoxDecoration(
                            color: Colors.grey.shade400,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Center(
                            child: Text(
                              widget.commenterName.isNotEmpty
                                  ? widget.commenterName[0].toUpperCase()
                                  : "",
                              style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Commenter's name in bold.
                        Text(
                          widget.commenterName,
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 4),
                        if (replyLabel.isNotEmpty)
                          Text(
                            replyLabel,
                            style: const TextStyle(
                                fontSize: 12, color: Colors.grey),
                          ),
                      ],
                    ),
                  ),
                  Text(
                    formattedTimestamp,
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              // Comment text.
              Text(
                widget.commentText,
                style: const TextStyle(fontSize: 14),
              ),
              const SizedBox(height: 8),
              // Reaction row.
              StreamBuilder<DocumentSnapshot>(
                stream: reactionStream,
                builder: (context, snapshot) {
                  bool userLiked = false;
                  bool userDisliked = false;
                  if (snapshot.hasData && snapshot.data!.exists) {
                    final reactionData =
                        snapshot.data!.data() as Map<String, dynamic>;
                    if (reactionData['reaction'] == "like") {
                      userLiked = true;
                    } else if (reactionData['reaction'] == "dislike") {
                      userDisliked = true;
                    }
                  }
                  return Row(
                    children: [
                      IconButton(
                        icon: Icon(
                          Icons.thumb_up_alt_outlined,
                          size: 20,
                          color: userLiked ? Colors.green : Colors.grey[600],
                        ),
                        onPressed: () async {
                          await widget.onToggleReaction(
                              widget.postId,
                              widget.isReply
                                  ? widget.parentCommentId
                                  : widget.commentId,
                              "like",
                              widget.currentUserId);
                        },
                      ),
                      Text(
                        "$updatedLikeCount",
                        style: const TextStyle(fontSize: 12, color: Colors.grey),
                      ),
                      const SizedBox(width: 8),
                      IconButton(
                        icon: Icon(
                          Icons.thumb_down_alt_outlined,
                          size: 20,
                          color: userDisliked ? Colors.red : Colors.grey[600],
                        ),
                        onPressed: () async {
                          await widget.onToggleReaction(
                              widget.postId,
                              widget.isReply
                                  ? widget.parentCommentId
                                  : widget.commentId,
                              "dislike",
                              widget.currentUserId);
                        },
                      ),
                      Text(
                        "$updatedDislikeCount",
                        style: const TextStyle(fontSize: 12, color: Colors.grey),
                      ),
                      const Spacer(),
                      if (!widget.isReply)
                        TextButton.icon(
                          onPressed: widget.onReply,
                          icon: const Icon(Icons.reply, size: 18, color: Colors.blue),
                          label: const Text(
                            "Reply",
                            style: TextStyle(fontSize: 12, color: Colors.blue),
                          ),
                        ),
                    ],
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }

  String _formatTimestamp(Timestamp timestamp) {
    final date = timestamp.toDate();
    final day = date.day.toString().padLeft(2, '0');
    final month = _monthName(date.month);
    final year = date.year.toString().substring(2);
    return "$day $month $year";
  }

  String _monthName(int month) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return months[month - 1];
  }
}
