import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:project/models/post.dart';
import 'package:project/services/post_service.dart';
import 'package:project/screens/threads.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PostCard extends StatefulWidget {
  final Post post;
  const PostCard({super.key, required this.post});

  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  String currentUserId = "";

  @override
  void initState() {
    super.initState();
    _loadCurrentUser();
  }

  Future<void> _loadCurrentUser() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      currentUserId = prefs.getString('uid') ?? "";
    });
  }

  Future<void> _handleLike() async {
    try {
      await PostService().toggleReaction(
        postId: widget.post.id,
        reaction: "like",
      );
    } catch (e) {
      print("Error toggling like: $e");
    }
  }

  Future<void> _handleDislike() async {
    try {
      await PostService().toggleReaction(
        postId: widget.post.id,
        reaction: "dislike",
      );
    } catch (e) {
      print("Error toggling dislike: $e");
    }
  }

  String _formatDate(DateTime timestamp) {
    return "${timestamp.day.toString().padLeft(2, '0')} ${_monthAbbr(timestamp.month)} ${timestamp.year.toString().substring(2)}";
  }

  String _monthAbbr(int month) {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return months[month - 1];
  }

  Widget _buildCategoryBubble(String category) {
    Color bgColor;
    IconData iconData;
    switch (category) {
      case 'Corporate Law':
        bgColor = Colors.blue;
        iconData = Icons.gavel;
        break;
      case 'Family Law':
        bgColor = Colors.pink;
        iconData = Icons.family_restroom;
        break;
      case 'Criminal Law':
        bgColor = Colors.red;
        iconData = Icons.security;
        break;
      case 'Copyright Law':
        bgColor = Colors.purple;
        iconData = Icons.copyright;
        break;
      case 'IP':
        bgColor = Colors.orange;
        iconData = Icons.lightbulb_outline;
        break;
      default:
        bgColor = Colors.grey;
        iconData = Icons.category;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: bgColor.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(iconData, size: 13, color: bgColor),
          const SizedBox(width: 2),
          Text(
            category,
            style: TextStyle(fontSize: 12, color: bgColor),
          ),
        ],
      ),
    );
  }

  Widget _buildPostImage(String path) {
    if (path.startsWith('http')) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Image.network(path, fit: BoxFit.cover),
      );
    } else if (path.isNotEmpty) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Image.file(File(path), fit: BoxFit.cover),
      );
    } else {
      return const SizedBox();
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance
          .collection('forum_posts')
          .doc(widget.post.id)
          .snapshots(),
      builder: (context, snapshot) {
        int currentLikeCount = widget.post.likes;
        int currentDislikeCount = widget.post.dislikes;
        int currentCommentCount = widget.post.comments;
        String currentPhotoUrl = widget.post.photoUrl;

        if (snapshot.hasData && snapshot.data!.exists) {
          final data = snapshot.data!.data() as Map<String, dynamic>;
          currentLikeCount = data['likes'] ?? widget.post.likes;
          currentDislikeCount = data['dislikes'] ?? widget.post.dislikes;
          currentCommentCount = data['comments'] ?? widget.post.comments;
          currentPhotoUrl = data['photoUrl'] ?? widget.post.photoUrl;
        }

        return Column(
          children: [
            InkWell(
              onTap: () {
                if (ModalRoute.of(context)?.settings.name != 'ThreadScreen') {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      settings: const RouteSettings(name: 'ThreadScreen'),
                      builder: (context) => ThreadScreen(post: widget.post),
                    ),
                  );
                }
              },
              child: Container(
                width: screenWidth,
                padding: const EdgeInsets.all(12),
                decoration: const BoxDecoration(
                  color: Colors.transparent,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // User profile picture
                        currentPhotoUrl.isNotEmpty
                            ? CircleAvatar(
                                radius: 25,
                                backgroundImage: NetworkImage(currentPhotoUrl),
                              )
                            : CircleAvatar(
                                radius: 25,
                                backgroundColor: Colors.grey.shade300,
                                child: Text(
                                  widget.post.name.isNotEmpty
                                      ? widget.post.name[0].toUpperCase()
                                      : "",
                                  style: const TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                        const SizedBox(width: 8),
                        // Right side: Name, profession, and category
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RichText(
                                text: TextSpan(
                                  text: widget.post.name,
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black,
                                  ),
                                  children: [
                                    TextSpan(
                                      text: " (${widget.post.profession})",
                                      style: const TextStyle(
                                        fontSize: 14,
                                        color: Colors.grey,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 8),
                              _buildCategoryBubble(widget.post.category),
                            ],
                          ),
                        ),
                        Text(
                          _formatDate(widget.post.timestamp),
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      widget.post.postTitle,
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      widget.post.postBody,
                      style: const TextStyle(fontSize: 14),
                    ),
                    const SizedBox(height: 8),
                    widget.post.imageUrl.isNotEmpty
                        ? _buildPostImage(widget.post.imageUrl)
                        : const SizedBox(),
                    const SizedBox(height: 8),
                    // Reaction Row (Updated for Sleeker Design)
                    SizedBox(
                      width: double.infinity,
                      child: StreamBuilder<DocumentSnapshot>(
                        stream: currentUserId.isEmpty
                            ? Stream.empty()
                            : FirebaseFirestore.instance
                                .collection('forum_posts')
                                .doc(widget.post.id)
                                .collection('reactions')
                                .doc(currentUserId)
                                .snapshots(),
                        builder: (context, reactionSnapshot) {
                          bool userLiked = false;
                          bool userDisliked = false;
                          if (reactionSnapshot.hasData &&
                              reactionSnapshot.data!.exists) {
                            final reactionData = reactionSnapshot.data!.data()
                                as Map<String, dynamic>;
                            if (reactionData['reaction'] == "like") {
                              userLiked = true;
                            } else if (reactionData['reaction'] == "dislike") {
                              userDisliked = true;
                            }
                          }
                          return Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              // Likes and Dislikes in a sleek curved container with vertical divider
                              Container(
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.grey),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 7),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    GestureDetector(
                                      onTap: _handleLike,
                                      child: Icon(
                                        Icons.thumb_up_alt_outlined,
                                        size: 19,
                                        color: userLiked
                                            ? Colors.green
                                            : Colors.grey[600],
                                      ),
                                    ),
                                    const SizedBox(width: 2),
                                    Text(
                                      '$currentLikeCount',
                                      style: const TextStyle(
                                        fontSize: 12,
                                        color: Colors.grey,
                                      ),
                                    ),
                                    Container(
                                      height: 14,
                                      width: 1,
                                      color: Colors.grey,
                                      margin: const EdgeInsets.symmetric(
                                          horizontal: 12), // increased from 4 to 8
                                    ),
                                    GestureDetector(
                                      onTap: _handleDislike,
                                      child: Icon(
                                        Icons.thumb_down_alt_outlined,
                                        size: 19,
                                        color: userDisliked
                                            ? Colors.red
                                            : Colors.grey[600],
                                      ),
                                    ),
                                    const SizedBox(width: 2),
                                    Text(
                                      '$currentDislikeCount',
                                      style: const TextStyle(
                                        fontSize: 12,
                                        color: Colors.grey,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              // Reply bubble
                              InkWell(
                                onTap: () {
                                  if (ModalRoute.of(context)?.settings.name !=
                                      'ThreadScreen') {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        settings: const RouteSettings(
                                            name: 'ThreadScreen'),
                                        builder: (context) =>
                                            ThreadScreen(post: widget.post),
                                      ),
                                    );
                                  }
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 14, vertical: 7),
                                  decoration: BoxDecoration(
                                    color: Colors.blue.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      const Icon(
                                        Icons.comment_outlined,
                                        size: 16,
                                        color: Colors.blue,
                                      ),
                                      const SizedBox(width: 2),
                                      Text(
                                        '$currentCommentCount',
                                        style: const TextStyle(
                                          fontSize: 12,
                                          color: Colors.blue,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
