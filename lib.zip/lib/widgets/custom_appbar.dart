import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:marquee/marquee.dart'; // Added import for marquee
import '../providers/theme_provider.dart';
import '../providers/language_provider.dart';
import '../services/translation_service.dart';

class CustomAppBar extends StatefulWidget implements PreferredSizeWidget {
  final String title;
  final IconData icon;
  final Widget body; // ✅ Pass entire screen body to manage everything

  const CustomAppBar({
    super.key,
    required this.title,
    required this.icon,
    required this.body,
  });

  @override
  State<CustomAppBar> createState() => _CustomAppBarState();

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}

class _CustomAppBarState extends State<CustomAppBar> {
  late String translatedTitle;
  String selectedLanguage = "en";

  @override
  void initState() {
    super.initState();
    // Use the title passed from the other screen as the initial translated title.
    translatedTitle = widget.title;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final languageProvider = Provider.of<LanguageProvider>(context);
    // If the selected language has changed, update the translation.
    if (selectedLanguage != languageProvider.selectedLanguage) {
      _updateTranslations();
    }
  }

  @override
  void didUpdateWidget(covariant CustomAppBar oldWidget) {
    super.didUpdateWidget(oldWidget);
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    // If the selected language has changed, update the translation.
    if (selectedLanguage != languageProvider.selectedLanguage) {
      _updateTranslations();
    }
    // If the title provided by the other screen has changed, update the translation.
    if (oldWidget.title != widget.title) {
      translatedTitle = widget.title;
      _updateTranslations();
    }
  }

  Future<void> _updateTranslations() async {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);
    final currentLanguage = languageProvider.selectedLanguage;

    // Only update if necessary.
    if (selectedLanguage == currentLanguage && translatedTitle == widget.title) return;
    selectedLanguage = currentLanguage;

    try {
      String newTitle = await TranslationService.translate(widget.title, selectedLanguage);
      if (mounted) {
        setState(() {
          translatedTitle = newTitle;
        });
      }
    } catch (e) {
      print("❌ Translation Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider1>(context, listen: true);
    final languageProvider = Provider.of<LanguageProvider>(context, listen: true);
    final isDarkMode = themeProvider.isDarkMode;

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: isDarkMode ? Colors.black : Colors.white,
        elevation: 0,
        title: Row(
          children: [
            Icon(widget.icon, color: Colors.blue),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 30, // Set the height for the marquee container
                    // Marquee widget for the translated title
                    child: Marquee(
                      text: translatedTitle,
                      style: TextStyle(
                        color: isDarkMode ? Colors.white : Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                      scrollAxis: Axis.horizontal,
                      blankSpace: 20.0,
                      velocity: 50.0,
                      pauseAfterRound: Duration(seconds: 1),
                      startPadding: 10.0,
                      accelerationDuration: Duration(seconds: 1),
                      accelerationCurve: Curves.linear,
                      decelerationDuration: Duration(milliseconds: 500),
                      decelerationCurve: Curves.easeOut,
                    ),
                  ),
                  Text(
                    "Language: ${languageProvider.selectedLanguage.toUpperCase()}",
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          // ✅ Language Selection Button
          PopupMenuButton<String>(
            icon: const Icon(Icons.language),
            onSelected: (value) async {
              await languageProvider.setLanguage(value);
              await _updateTranslations();
            },
            itemBuilder: (context) => {
              'English': 'en',
              'Hindi': 'hi',
              'Marathi': 'mr',
              'Gujarati': 'gu',
              'Tamil': 'ta',
              'Telugu': 'te',
              'Bengali': 'bn',
            }
                .entries
                .map((entry) => PopupMenuItem<String>(
                      value: entry.value,
                      child: Text(entry.key),
                    ))
                .toList(),
          ),
          // ✅ Color Blind Mode Button
          PopupMenuButton<String>(
            icon: const Icon(Icons.remove_red_eye),
            onSelected: (value) {
              themeProvider.setColorBlindMode(value);
            },
            itemBuilder: (context) => themeProvider.colorBlindFilters.keys
                .map((String mode) => PopupMenuItem<String>(
                      value: mode,
                      child: Text(mode),
                    ))
                .toList(),
          ),
          // ✅ Dark Mode Toggle
          IconButton(
            icon: Icon(isDarkMode ? Icons.light_mode : Icons.dark_mode),
            onPressed: () {
              themeProvider.toggleDarkMode();
            },
          ),
        ],
      ),
      body: ColorFiltered(
        colorFilter: themeProvider.currentFilter, // ✅ Apply color-blind filter to entire screen
        child: widget.body, // ✅ Show the full screen content
      ),
    );
  }
}
