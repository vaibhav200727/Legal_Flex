import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeProvider1 extends ChangeNotifier {
  bool isDarkMode = false;
  String selectedColorBlindMode = 'None';

  final Map<String, ColorFilter> colorBlindFilters = {
    'None': ColorFilter.mode(Colors.transparent, BlendMode.dst),
    'Protanopia': ColorFilter.matrix([
      0.567, 0.433, 0, 0, 0,
      0.558, 0.442, 0, 0, 0,
      0, 0.242, 0.758, 0, 0,
      0, 0, 0, 1, 0,
    ]),
    'Deuteranopia': ColorFilter.matrix([
      0.625, 0.375, 0, 0, 0,
      0.7, 0.3, 0, 0, 0,
      0, 0.3, 0.7, 0, 0,
      0, 0, 0, 1, 0,
    ]),
    'Tritanopia': ColorFilter.matrix([
      0.95, 0.05, 0, 0, 0,
      0, 0.433, 0.567, 0, 0,
      0, 0.475, 0.525, 0, 0,
      0, 0, 0, 1, 0,
    ]),
    'Achromatopsia': ColorFilter.matrix([
      0.299, 0.587, 0.114, 0, 0,
      0.299, 0.587, 0.114, 0, 0,
      0.299, 0.587, 0.114, 0, 0,
      0, 0, 0, 1, 0,
    ]),
    'Achromatomaly': ColorFilter.matrix([
      0.618, 0.32, 0.062, 0, 0,
      0.163, 0.775, 0.062, 0, 0,
      0.163, 0.32, 0.516, 0, 0,
      0, 0, 0, 1, 0,
    ]),
  };

  ThemeProvider1() {
    _loadPreferences();
  }

  void toggleDarkMode() {
    isDarkMode = !isDarkMode;
    _savePreferences();
    notifyListeners();
  }

  void setColorBlindMode(String mode) {
    selectedColorBlindMode = mode;
    _savePreferences();
    notifyListeners();
  }

  ColorFilter get currentFilter {
    return colorBlindFilters[selectedColorBlindMode] ?? ColorFilter.mode(Colors.transparent, BlendMode.dst);
  }

  Future<void> _savePreferences() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isDarkMode', isDarkMode);
    await prefs.setString('selectedColorBlindMode', selectedColorBlindMode);
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    isDarkMode = prefs.getBool('isDarkMode') ?? false;
    selectedColorBlindMode = prefs.getString('selectedColorBlindMode') ?? 'None';
    notifyListeners();
  }
}
