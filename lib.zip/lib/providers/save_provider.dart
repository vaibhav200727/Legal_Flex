import 'package:flutter/material.dart';

class SaveProvider extends ChangeNotifier {
  final List<String> _savedItems = [];

  List<String> get savedItems => _savedItems;

  void addItem(String item) {
    if (!_savedItems.contains(item)) {
      _savedItems.add(item);
      notifyListeners();
    }
  }

  void removeItem(String item) {
    if (_savedItems.contains(item)) {
      _savedItems.remove(item);
      notifyListeners();
    }
  }
}
