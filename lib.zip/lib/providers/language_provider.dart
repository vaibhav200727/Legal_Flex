import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LanguageProvider with ChangeNotifier {
  String _selectedLanguage = 'en'; // Default language

  String get selectedLanguage => _selectedLanguage;

  LanguageProvider() {
    loadLanguage(); // ✅ Load saved language when provider is created
  }

  Future<void> loadLanguage() async {
    final prefs = await SharedPreferences.getInstance();
    _selectedLanguage = prefs.getString('selected_language') ?? 'en';
    notifyListeners(); // ✅ Notify UI after loading saved language
  }

  Future<void> setLanguage(String langCode) async {
    if (_selectedLanguage != langCode) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('selected_language', langCode);
      _selectedLanguage = langCode;
      notifyListeners(); // ✅ Notify UI after changing language
    }
  }
}
