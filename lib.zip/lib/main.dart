import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:project/screens/civil_screen.dart';
import 'package:project/screens/confetti_screen.dart';
import 'package:project/screens/cyber_screen.dart';
import 'package:project/screens/landing_screen.dart';
import 'package:project/screens/social_screen.dart';
import 'package:project/screens/tax_simp.dart';
import 'package:provider/provider.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

import 'firebase_options.dart';
import 'providers/theme_provider.dart';
import 'providers/language_provider.dart';
import 'providers/save_provider.dart';
import 'services/blockchain_service.dart';
import 'screens/chatbot_screen.dart';
import 'screens/analysis.dart';
import 'screens/ayr_screen.dart';
import 'screens/casetoact.dart';
import 'screens/cyber_simp.dart';
import 'screens/demo_screen.dart';
import 'screens/economic_screen.dart';
import 'screens/login_screen.dart';
import 'screens/legalglossary_screen.dart';

import 'screens/otp_screen.dart';
import 'screens/simp1_screen.dart';
import 'screens/simp2_screen.dart';
import 'screens/simp3_screen.dart';
import 'screens/simp4_screen.dart';
import 'screens/simp5_screen.dart';
import 'screens/simp6_screen.dart';
import 'screens/simp7_screen.dart';
import 'screens/recommendation_screen.dart';
import 'screens/home_screen.dart';

// Make sure to import your additional screens:// NyaySetuScreen
// If LoginPage is not the same as login_screen.dart, adjust accordingly.
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: ".env");
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  
  FirebaseFirestore.instance.settings = const Settings(
    persistenceEnabled: true, // Allows offline caching
    cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED, // Unlimited cache
  );

  
  // ✅ Initialize Blockchain Service
  final BlockchainService blockchainService = BlockchainService();
  await blockchainService.init();

  // Initialize a single instance of LanguageProvider and load saved language.
  final languageProvider = LanguageProvider();
  await languageProvider.loadLanguage();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider1()),
        ChangeNotifierProvider<LanguageProvider>.value(value: languageProvider),
        ChangeNotifierProvider(create: (_) => SaveProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  Widget? _startScreen;

  @override
  void initState() {
    super.initState();
    _determineStartScreen();
  }

  /// Determine the correct start screen without changing any other UI logic.
  Future<void> _determineStartScreen() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    
    bool isFirstLaunch = prefs.getBool('isFirstLaunch') ?? true;
    bool rememberMe = prefs.getBool('rememberMe') ?? false;

    Widget initialScreen;

    if (isFirstLaunch) {
      // First time running the app → Show NyaySetuScreen
      initialScreen = const NyaySetuScreen();
      await prefs.setBool('isFirstLaunch', false); // Mark first launch as complete
    } else if (rememberMe) {
      // User selected "Remember Me" → Go to HomeScreen
      initialScreen = const HomeScreen();
    } else {
      // No "Remember Me" → Show Login Screen
      initialScreen = const LoginPage();
    }

    setState(() {
      _startScreen = initialScreen;
    });
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider1>(context);
    final languageProvider = Provider.of<LanguageProvider>(context);

    // While determining the start screen, display a blank white screen or a loader if desired.
    if (_startScreen == null) {
      return const MaterialApp(
        home: Scaffold(
          backgroundColor: Colors.white,
          body: Center(child: CircularProgressIndicator()),
        ),
      );
    }

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Nyay Setu',
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      themeMode: themeProvider.isDarkMode ? ThemeMode.dark : ThemeMode.light,
      locale: Locale(languageProvider.selectedLanguage), // Dynamically set locale.
      home: _startScreen,
);
}
}