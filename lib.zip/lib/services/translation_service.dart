import 'dart:convert';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;

class TranslationService {
  static final String _apiKey = dotenv.env['GOOGLE_TRANSLATE_API_KEY'] ?? ''; // Replace with your API key
  static const String _baseUrl = 'https://translation.googleapis.com/language/translate/v2';

  static Future<String> translate(String text, String targetLang) async {
    if (targetLang == 'en') return text; // No need to translate if English

    final Uri uri = Uri.parse('$_baseUrl?key=$_apiKey');

    final response = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'q': text, 'target': targetLang}),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['data']['translations'][0]['translatedText'];
    } else {
      throw Exception('Failed to translate text');
    }
  }
}
