import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> saveLawyerProfile({
  required File profileImage,
  required String fullName,
  required String lawDegree,
  required String state,
  required String city,
  required String lawType,
  required int feesPerHour,
  required String uidFromPrefs,
}) async {
  try {
    // Upload profile image to Firebase Storage
    final ref = FirebaseStorage.instance
        .ref()
        .child('lawyer_profiles')
        .child('$uidFromPrefs.jpg');

    await ref.putFile(profileImage);
    final imageUrl = await ref.getDownloadURL();

    // Save lawyer details to Firestore
    final lawyerData = {
      'uid': uidFromPrefs,
      'name': fullName,
      'degree': lawDegree,
      'state': state,
      'city': city,
      'lawyerType': lawType,
      'feesPerHour': feesPerHour,
      'profileImageUrl': imageUrl,
      'isRegistered': true,
      'createdAt': FieldValue.serverTimestamp(),
    };

    await FirebaseFirestore.instance
        .collection('advoconnect_lawyers')
        .doc(uidFromPrefs)
        .set(lawyerData);

    // Update SharedPreferences
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isAdvoConnectRegistered', true);

    print('✅ Lawyer registered successfully.');
  } catch (e) {
    print('❌ Error saving lawyer profile: $e');
    rethrow;
  }
}
