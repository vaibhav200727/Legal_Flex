import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:http/http.dart';
import 'package:web3dart/web3dart.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class BlockchainService {
  late Web3Client _client;
  late Credentials _credentials;
  late DeployedContract _contract;
  late ContractFunction _storeDocument;
  late ContractFunction _verifyDocument;
  late ContractFunction _getDocumentHash; // NEW FUNCTION ADDED

  BlockchainService();

  /// Initialize the Web3 connection and contract
  Future<void> init() async {
    await dotenv.load(); // Load .env file

    final String rpcUrl = dotenv.env['INFURA_URL']!;
    final String privateKey = dotenv.env['PRIVATE_KEY']!;
    final String contractAddress = dotenv.env['CONTRACT_ADDRESS']!;

    _client = Web3Client(rpcUrl, Client());
    _credentials = EthPrivateKey.fromHex(privateKey);

    // Load ABI from the assets
    String abiString = await rootBundle.loadString("assets/json/DocumentVerifier.json");
    final abiJson = jsonDecode(abiString);
    final List<dynamic> abi = abiJson["abi"];

    // Connect to the deployed contract
    _contract = DeployedContract(
      ContractAbi.fromJson(jsonEncode(abi), "DocumentVerifier"),
      EthereumAddress.fromHex(contractAddress),
    );

    _storeDocument = _contract.function("storeDocument");
    _verifyDocument = _contract.function("verifyDocument");
    _getDocumentHash = _contract.function("getDocumentHash"); // NEW FUNCTION
  }

  /// Store a new document hash on the blockchain
  Future<String> storeDocument(String documentName, String documentHash) async {
    final transaction = Transaction.callContract(
      contract: _contract,
      function: _storeDocument,
      parameters: [documentName, documentHash],
    );

    final txHash = await _client.sendTransaction(
      _credentials,
      transaction,
      chainId: 80002, // Polygon Amoy Chain ID
    );

    print("Document stored on-chain: $documentName => Hash: $documentHash (TxHash: $txHash)");
    return txHash; // Returns the transaction hash
  }

  /// Retrieve the stored document hash from the blockchain
Future<String> getStoredHash(String docName) async {
  try {
    final List<dynamic> result = await _client.call(
      contract: _contract,
      function: _getDocumentHash,
      params: [docName],
    );
    if(result.isEmpty) {
      print("Blockchain returned an empty result for docName: '$docName'");
      return "";
    }
    String storedHash = result.first.toString().trim();
    print("Fetched Blockchain Hash for '$docName': '$storedHash'");
    return storedHash;
  } catch (e) {
    print("Error fetching hash for docName: '$docName' - $e");
    return "";
  }
}

  /// Verify if a document's hash matches the stored hash on the blockchain
  Future<bool> verifyDocument(String documentName, String documentHash) async {
    try {
      final storedHash = await getStoredHash(documentName);

      print("Comparing Computed Hash: '$documentHash' with Blockchain Hash: '$storedHash'");

      return documentHash.toLowerCase().trim() == storedHash.toLowerCase().trim();
    } catch (e) {
      print("Blockchain verification error for $documentName: $e");
      return false;
    }
  }
}
