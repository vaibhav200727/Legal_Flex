import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart'; // For formatting time

class ApiService {
  // Replace with your Flask API URL
  final String apiUrl = 'http://3.111.249.3:5000/predict';
  String? storedUid = "";

  // Get prediction from your Flask API
  Future<Map<String, dynamic>> getPrediction({
    required String caseDetails,
    required String keyFeatures,
  }) async {
    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "case_details": caseDetails,
        "key_features": keyFeatures,
      }),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception("Failed to fetch prediction from API: ${response.statusCode}");
    }
  }

  // Load UID from SharedPreferences and store it in storedUid
  Future<void> loadStoredUid() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    storedUid = prefs.getString('uid') ?? "";
    print("Stored UID: $storedUid");
  }

  // Save prediction to Firestore under the format: uid_HH:MM:SS
  Future<void> savePrediction({
    required String caseTitle,
    required String caseDescription,
    required String priority,
    required String filingDate,
    required Map<String, dynamic> prediction,
  }) async {
    // Ensure UID is loaded
    if (storedUid == null || storedUid!.isEmpty) {
      await loadStoredUid(); // Load it here if not already
    }

    if (storedUid == null || storedUid!.isEmpty) {
      throw Exception("UID is not available even after loading.");
    }

    // Get current time formatted as HH:mm:ss
    String formattedTime = DateFormat('HH:mm:ss').format(DateTime.now());
    String documentId = '${storedUid}_$formattedTime';

    await FirebaseFirestore.instance
        .collection("case_to_act_predictions")
        .doc(documentId)
        .set({
      "uid": storedUid,
      "case_title": caseTitle,
      "case_description": caseDescription,
      "priority": priority,
      "filing_date": filingDate,
      "prediction": prediction,
      "timestamp": FieldValue.serverTimestamp(),
    });
  }
}
