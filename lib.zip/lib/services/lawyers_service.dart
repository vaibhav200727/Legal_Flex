import 'package:cloud_firestore/cloud_firestore.dart';

/// Fetches all available lawyers (where isRegistered == true) from Firestore.
Future<List<Map<String, dynamic>>> fetchAvailableLawyers() async {
  QuerySnapshot snapshot = await FirebaseFirestore.instance
      .collection('advoconnect_lawyers')
      .where('isRegistered', isEqualTo: true)
      .get();

  return snapshot.docs
      .map((doc) => doc.data() as Map<String, dynamic>)
      .toList();
}
