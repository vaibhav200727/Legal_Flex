import 'package:cloud_firestore/cloud_firestore.dart';

/// Holds the result of saving availability
class SaveAvailabilityResult {
  final Map<String, String> lockedReasons;
  final Map<String, ({List<String> slots, int duration})> newlySavedSlots;

  SaveAvailabilityResult({
    required this.lockedReasons,
    required this.newlySavedSlots,
  });
}

Future<SaveAvailabilityResult> saveAvailability({
  required String uid,
  required Map<String, ({List<String> slots, int duration})> slotsToSave,
}) async {
  final firestore = FirebaseFirestore.instance;
  final docRef = firestore.collection('advoconnect_availability').doc(uid);

  // Fetch current data
  final existingData = await docRef.get();
  List<String> existingLockedDates = [];
  Map<String, ({List<String> slots, int duration})> currentSlots = {};

  if (existingData.exists) {
    final data = existingData.data()!;

    existingLockedDates = List<String>.from(data['lockedDates'] ?? []);

    if (data['slots'] != null) {
      final slotsData = data['slots'] as Map<String, dynamic>;

      currentSlots = slotsData.map((key, value) {
        final slotInfo = value as Map<String, dynamic>? ?? {
          'slots': <String>[],
          'duration': 60
        };

        // 🔥 Safe type parsing for duration
        final dynamic durationRaw = slotInfo['duration'];
        final int durationParsed = durationRaw is int
            ? durationRaw
            : int.tryParse(durationRaw.toString()) ?? 60;

        return MapEntry(
          key,
          (
            slots: List<String>.from(slotInfo['slots'] ?? []),
            duration: durationParsed,
          ),
        );
      });
    }
  }

  // Prepare final maps
  final updatedLockedDates = Set<String>.from(existingLockedDates);
  final finalSlotsToSave = <String, ({List<String> slots, int duration})>{};
  final lockedReasons = <String, String>{};

  // Iterate through new entries
  for (final entry in slotsToSave.entries) {
    final dateStr = entry.key;
    final data = entry.value;

    // If already locked
    if (updatedLockedDates.contains(dateStr)) {
      lockedReasons[dateStr] = "Already submitted";
      continue;
    }

    // Check if any slot already booked
    final dayStart = DateTime.parse('$dateStr 00:00:00');
    final dayEnd = DateTime.parse('$dateStr 23:59:59');

    final bookedCalls = await firestore
        .collection('advoconnect_calls')
        .where('lawyerId', isEqualTo: uid)
        .where('slot', isGreaterThanOrEqualTo: Timestamp.fromDate(dayStart))
        .where('slot', isLessThanOrEqualTo: Timestamp.fromDate(dayEnd))
        .limit(1)
        .get();

    if (bookedCalls.docs.isNotEmpty) {
      updatedLockedDates.add(dateStr);
      lockedReasons[dateStr] = "Slot already booked";
      continue;
    }

    // If not booked, accept this slot set
    finalSlotsToSave[dateStr] = data;
    updatedLockedDates.add(dateStr);
  }

  // Merge with existing slots
  final mergedSlots = {...currentSlots, ...finalSlotsToSave};

  // Save to Firestore
  await docRef.set({
    'lockedDates': updatedLockedDates.toList(),
    'slots': mergedSlots.map((k, v) => MapEntry(k, {
          'slots': v.slots,
          'duration': v.duration,
        })),
    'lastUpdated': FieldValue.serverTimestamp(),
  }, SetOptions(merge: true));

  return SaveAvailabilityResult(
    lockedReasons: lockedReasons,
    newlySavedSlots: finalSlotsToSave,
  );
}
