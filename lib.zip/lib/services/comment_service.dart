import 'package:cloud_firestore/cloud_firestore.dart';

class CommentService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// Creates a new top-level comment under the given post.
  Future<void> createComment({
  required String postId,
  required String uid,
  required String name,
  required String photoUrl,
  required String commentText,
  required String repliedTo,      // For top-level comments, this should be an empty string.
  required String repliedContext, // "post" for top-level comments.
}) async {
  // Create the comment document.
  await _firestore.collection('forum_posts')
      .doc(postId)
      .collection('comments')
      .add({
    'uid': uid,
    'name': name,
    'photoURL': photoUrl, // Using "photoURL" key consistently.
    'commentText': commentText,
    'repliedTo': repliedTo,
    'repliedContext': repliedContext,
    'timestamp': FieldValue.serverTimestamp(),
    'likes': 0,
    'dislikes': 0,
  });
  
  // Then update the post document to increment the comment count.
  await _firestore.collection('forum_posts').doc(postId).update({
    'comments': FieldValue.increment(1),
  });
}


  /// Creates a reply to an existing comment.
  /// Replies are stored in the subcollection "replies" under the parent comment.
  Future<void> createReply({
    required String postId,
    required String commentId,
    required String uid,
    required String name,
    required String photoUrl,
    required String replyText,
    required String repliedTo,      // The name of the user being replied to.
    required String repliedContext, // "comment" for a reply.
  }) async {
    await _firestore.collection('forum_posts')
        .doc(postId)
        .collection('comments')
        .doc(commentId)
        .collection('replies')
        .add({
      'uid': uid,
      'name': name,
      'photoURL': photoUrl,
      // For replies, we store the reply text in the same field name "commentText".
      'commentText': replyText,
      'repliedTo': repliedTo,
      'repliedContext': repliedContext,
      'timestamp': FieldValue.serverTimestamp(),
      'likes': 0,
      'dislikes': 0,
    });
  }

  /// Toggles a reaction (like or dislike) for a comment.
  /// Uses a Firestore transaction to atomically update reaction counts.
  Future<void> toggleCommentReaction({
    required String postId,
    required String commentId,
    required String reaction, // Should be either "like" or "dislike"
    required String uid,      // Current user's UID.
  }) async {
    DocumentReference commentRef = _firestore
        .collection('forum_posts')
        .doc(postId)
        .collection('comments')
        .doc(commentId);

    DocumentReference reactionRef = commentRef
        .collection('reactions')
        .doc(uid);

    await _firestore.runTransaction((transaction) async {
      DocumentSnapshot commentSnap = await transaction.get(commentRef);
      if (!commentSnap.exists) {
        throw Exception("Comment not found: $commentId");
      }

      // Get current reaction counts.
      Map<String, dynamic> commentData = commentSnap.data() as Map<String, dynamic>;
      int currentLikes = commentData['likes'] ?? 0;
      int currentDislikes = commentData['dislikes'] ?? 0;

      DocumentSnapshot reactionSnap = await transaction.get(reactionRef);

      if (reactionSnap.exists) {
        // User already reacted; check if same reaction.
        Map<String, dynamic> reactionData = reactionSnap.data() as Map<String, dynamic>;
        String oldReaction = reactionData['reaction'] ?? "";
        if (oldReaction == reaction) {
          // Remove reaction.
          if (reaction == "like") currentLikes--;
          if (reaction == "dislike") currentDislikes--;
          transaction.delete(reactionRef);
        } else {
          // Switching reaction.
          if (oldReaction == "like") currentLikes--;
          if (oldReaction == "dislike") currentDislikes--;
          if (reaction == "like") currentLikes++;
          if (reaction == "dislike") currentDislikes++;
          transaction.update(reactionRef, {'reaction': reaction});
        }
      } else {
        // No reaction exists; add new reaction.
        if (reaction == "like") currentLikes++;
        if (reaction == "dislike") currentDislikes++;
        transaction.set(reactionRef, {'reaction': reaction});
      }

      // Update the comment document with new counts.
      transaction.update(commentRef, {
        'likes': currentLikes,
        'dislikes': currentDislikes,
      });
    });
  }

  /// Toggles a reaction (like or dislike) for a reply.
  /// Replies are stored under forum_posts/{postId}/comments/{commentId}/replies/{replyId}/reactions.
  Future<void> toggleReplyReaction({
    required String postId,
    required String commentId,
    required String replyId,
    required String reaction, // Should be "like" or "dislike"
    required String uid,      // Current user's UID.
  }) async {
    DocumentReference replyRef = _firestore
        .collection('forum_posts')
        .doc(postId)
        .collection('comments')
        .doc(commentId)
        .collection('replies')
        .doc(replyId);

    DocumentReference reactionRef = replyRef
        .collection('reactions')
        .doc(uid);

    await _firestore.runTransaction((transaction) async {
      DocumentSnapshot replySnap = await transaction.get(replyRef);
      if (!replySnap.exists) {
        throw Exception("Reply not found: $replyId");
      }

      Map<String, dynamic> replyData = replySnap.data() as Map<String, dynamic>;
      int currentLikes = replyData['likes'] ?? 0;
      int currentDislikes = replyData['dislikes'] ?? 0;

      DocumentSnapshot reactionSnap = await transaction.get(reactionRef);
      if (reactionSnap.exists) {
        Map<String, dynamic> reactionData = reactionSnap.data() as Map<String, dynamic>;
        String oldReaction = reactionData['reaction'] ?? "";
        if (oldReaction == reaction) {
          if (reaction == "like") currentLikes--;
          if (reaction == "dislike") currentDislikes--;
          transaction.delete(reactionRef);
        } else {
          if (oldReaction == "like") currentLikes--;
          if (oldReaction == "dislike") currentDislikes--;
          if (reaction == "like") currentLikes++;
          if (reaction == "dislike") currentDislikes++;
          transaction.update(reactionRef, {'reaction': reaction});
        }
      } else {
        if (reaction == "like") currentLikes++;
        if (reaction == "dislike") currentDislikes++;
        transaction.set(reactionRef, {'reaction': reaction});
      }

      transaction.update(replyRef, {
        'likes': currentLikes,
        'dislikes': currentDislikes,
      });
    });
  }
}
