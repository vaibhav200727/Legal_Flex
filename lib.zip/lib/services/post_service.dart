import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import '../models/post.dart';

class PostService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  /// Uploads an image file to Firebase Storage and returns the download URL.
  Future<String?> _uploadImage(File file, String uid) async {
    try {
      final String fileName = 'post_images/$uid-${DateTime.now().millisecondsSinceEpoch}.jpg';
      final ref = _storage.ref().child(fileName);
      await ref.putFile(file);
      return await ref.getDownloadURL();
    } catch (e) {
      print("Error uploading image: $e");
      return null;
    }
  }

  /// Creates a post in Firestore.
  /// The post document is stored in the `forum_posts` collection with a document ID
  /// in the format `uid_HH:MM:SS`. User data (uid, name, profession) is fetched from SharedPreferences.
  /// If an image is provided, it is uploaded to Firebase Storage, and the download URL is stored.
  Future<void> createPost({
  required String postTitle,
  required String postBody,
  required String category,
  File? imageFile,
}) async {
  final prefs = await SharedPreferences.getInstance();
  final String uid = prefs.getString('uid') ?? "";
  final String name = prefs.getString('name') ?? "";
  final String profession = prefs.getString('profession') ?? "";
  final String photoUrl = prefs.getString('photoURL') ?? ""; // Retrieve the profile photo URL

  if (uid.isEmpty) {
    throw Exception("User ID not found in SharedPreferences.");
  }

  String formattedTime = DateFormat('HH:mm:ss').format(DateTime.now());
  String docId = "${uid}_$formattedTime";

  String? imageUrl;
  if (imageFile != null) {
    imageUrl = await _uploadImage(imageFile, uid);
  }

  await _firestore.collection('forum_posts').doc(docId).set({
    'uid': uid,
    'name': name,
    'profession': profession,
    'photoUrl': photoUrl,  // Save the profile photo URL here
    'postTitle': postTitle,
    'postBody': postBody,
    'category': category,
    'imageUrl': imageUrl ?? "",
    'timestamp': FieldValue.serverTimestamp(),
    'likes': 0,
    'dislikes': 0,
    'comments': 0,
  });
}
  /// Returns a stream of posts based on the selected filter category and sort option.
  Stream<List<Post>> getPosts({String category = "All Categories", String sortOption = "Newest"}) {
    Query<Map<String, dynamic>> query = _firestore.collection("forum_posts");
    if (category != "All Categories") {
      query = query.where("category", isEqualTo: category);
    }
    switch (sortOption) {
      case "Most Liked":
        query = query.orderBy("likes", descending: true);
        break;
      case "Least Liked":
        query = query.orderBy("likes", descending: false);
        break;
      case "Oldest":
        query = query.orderBy("timestamp", descending: false);
        break;
      case "Newest":
      default:
        query = query.orderBy("timestamp", descending: true);
        break;
    }
    // Limit posts for performance.
    query = query.limit(15);
    return query.snapshots().map((snapshot) =>
        snapshot.docs.map((doc) => Post.fromDoc(doc)).toList());
  }

  /// Toggles a reaction (like or dislike) for the specified post.
  /// It uses the current user's UID (retrieved from SharedPreferences) to ensure each user can only react once.
  /// The reaction is stored in a subcollection "reactions" under the post document.
  Future<void> toggleReaction({
  required String postId,
  required String reaction, // "like" or "dislike"
}) async {
  // 1) Get current user’s UID from SharedPreferences
  final prefs = await SharedPreferences.getInstance();
  final uid = prefs.getString('uid') ?? "";
  if (uid.isEmpty) throw Exception("User ID not found in SharedPreferences.");

  final postRef = _firestore.collection('forum_posts').doc(postId);
  final reactionRef = postRef.collection('reactions').doc(uid);

  // 2) Use a Firestore transaction for atomic updates
  await _firestore.runTransaction((transaction) async {
    final postSnap = await transaction.get(postRef);
    if (!postSnap.exists) {
      throw Exception("Post not found: $postId");
    }

    // Cast postSnap.data() to Map<String, dynamic>
    final postData = postSnap.data() as Map<String, dynamic>;
    int currentLikes = postData['likes'] ?? 0;
    int currentDislikes = postData['dislikes'] ?? 0;

    // Check if user already reacted
    final reactionSnap = await transaction.get(reactionRef);
    if (reactionSnap.exists) {
      // Cast reactionSnap.data() to Map<String, dynamic>
      final reactionData = reactionSnap.data();
      String oldReaction = reactionData?['reaction'] ?? "";
      if (oldReaction == reaction) {
        // User tapped the same reaction again => remove it
        if (reaction == "like") {
          currentLikes--;
        } else if (reaction == "dislike") currentDislikes--;
        transaction.delete(reactionRef);
      } else {
        // User switching from like -> dislike or dislike -> like
        if (oldReaction == "like") {
          currentLikes--;
        } else if (oldReaction == "dislike") currentDislikes--;
        if (reaction == "like") {
          currentLikes++;
        } else if (reaction == "dislike") currentDislikes++;
        transaction.update(reactionRef, {'reaction': reaction});
      }
    } else {
      // No previous reaction => add new one
      if (reaction == "like") {
        currentLikes++;
      } else if (reaction == "dislike") currentDislikes++;
      transaction.set(reactionRef, {'reaction': reaction});
    }

    // 3) Update post counters
    transaction.update(postRef, {
      'likes': currentLikes,
      'dislikes': currentDislikes,
    });
  });
}

  Future<String?> getUserReaction(String postId, String uid) async {
  final snap = await FirebaseFirestore.instance
      .collection('forum_posts')
      .doc(postId)
      .collection('reactions')
      .doc(uid)
      .get();

  if (!snap.exists) return null;

  final data = snap.data();
  return data?['reaction'];
}

}
