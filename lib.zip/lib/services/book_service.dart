import 'package:cloud_firestore/cloud_firestore.dart';

class BookService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String collectionName = 'elibrary';
  final String readingProgressCollection = 'readingProgress';

  // Fetch all books from Firestore
  Future<List<Map<String, dynamic>>> fetchAllBooks() async {
    try {
      QuerySnapshot snapshot = await _firestore.collection(collectionName).get();
      print("Fetched ${snapshot.docs.length} documents from $collectionName");
      if (snapshot.docs.isEmpty) {
        print("No documents found in $collectionName collection");
        return [];
      }
      return snapshot.docs.where((doc) {
        var data = doc.data() as Map<String, dynamic>;
        var fileUrl = (data['file_url']?.toString() ?? '').trim();
        if (fileUrl.isEmpty || fileUrl.toLowerCase() == 'null') {
          print("Skipping document ${doc.id} (${data['title']}) due to invalid file_url: '$fileUrl'");
          return false;
        }
        return true;
      }).map((doc) {
        var data = doc.data() as Map<String, dynamic>;
        print("Document data for ${doc.id}: $data");
        var coverUrl = (data['cover_url'] ?? '').trim();
        var fileUrl = (data['file_url']?.toString() ?? '').trim();
        return {
          'id': doc.id,
          'title': data['title'] ?? 'Unknown Title',
          'category': data['category'] ?? 'Miscellaneous',
          'cover_url': coverUrl,
          'file_url': fileUrl,
        };
      }).toList();
    } catch (e) {
      print("Error fetching books: $e");
      return [];
    }
  }

  // Fetch the last 2 books for "Continue Reading" for a specific user
  Future<List<Map<String, dynamic>>> fetchContinueReadingBooks(String uid) async {
    try {
      DocumentSnapshot doc = await _firestore
          .collection(readingProgressCollection)
          .doc(uid)
          .get();
      if (!doc.exists) {
        print("No reading progress found for user $uid");
        return [];
      }
      var data = doc.data() as Map<String, dynamic>;
      List<dynamic> books = data['books'] ?? [];
      print("Fetched ${books.length} continue reading books for user $uid");

      // Sort books by lastReadTimestamp and take the last 2
      books.sort((a, b) {
        DateTime aTimestamp = (a['lastReadTimestamp'] is Timestamp)
            ? (a['lastReadTimestamp'] as Timestamp).toDate()
            : DateTime.parse(a['lastReadTimestamp']?.toString() ?? DateTime.now().toIso8601String());
        DateTime bTimestamp = (b['lastReadTimestamp'] is Timestamp)
            ? (b['lastReadTimestamp'] as Timestamp).toDate()
            : DateTime.parse(b['lastReadTimestamp']?.toString() ?? DateTime.now().toIso8601String());
        return bTimestamp.compareTo(aTimestamp); // Descending order
      });

      return books.take(2).map((book) {
        print("Continue reading book: $book");
        return {
          'id': book['bookId'] ?? '',
          'title': book['title'] ?? 'Unknown Title',
          'file_url': book['file_url'] ?? '',
          'lastPage': book['lastPage'] ?? 1,
          'totalPages': book['totalPages'] ?? 1,
          'lastReadTimestamp': (book['lastReadTimestamp'] is Timestamp)
              ? (book['lastReadTimestamp'] as Timestamp).toDate()
              : DateTime.parse(book['lastReadTimestamp']?.toString() ?? DateTime.now().toIso8601String()),
        };
      }).toList();
    } catch (e) {
      print("Error fetching continue reading books: $e");
      return [];
    }
  }

  // Save or update the reading progress for a specific user
  Future<void> saveReadingProgress({
    required String uid,
    required String bookId,
    required String title,
    required String fileUrl,
    required int lastPage,
    required int totalPages,
  }) async {
    try {
      print("Attempting to save reading progress for user $uid, book $bookId");
      print("Book details: title=$title, fileUrl=$fileUrl, lastPage=$lastPage, totalPages=$totalPages");

      // Validate inputs
      if (uid.isEmpty) {
        throw Exception("UID is empty");
      }
      if (bookId.isEmpty) {
        throw Exception("Book ID is empty");
      }
      if (fileUrl.isEmpty) {
        throw Exception("File URL is empty");
      }

      // Get the current document for this UID
      DocumentReference docRef = _firestore.collection(readingProgressCollection).doc(uid);
      print("Fetching document at ${docRef.path}");
      DocumentSnapshot doc = await docRef.get();
      List<dynamic> books = [];
      if (doc.exists) {
        var data = doc.data() as Map<String, dynamic>;
        books = data['books'] ?? [];
        print("Existing books in Firestore: $books");
      } else {
        print("No existing document found for user $uid, creating new one");
      }

      // Remove any existing entry for this bookId
      books.removeWhere((book) => book['bookId'] == bookId);
      print("Books after removing existing entry for bookId $bookId: $books");

      // Add the new/updated entry using a client-side timestamp
      Map<String, dynamic> newEntry = {
        'bookId': bookId,
        'title': title,
        'file_url': fileUrl,
        'lastPage': lastPage,
        'totalPages': totalPages,
        'lastReadTimestamp': DateTime.now().toIso8601String(), // Use client-side timestamp
      };
      books.add(newEntry);
      print("Books after adding new entry: $books");

      // Sort the books list by lastReadTimestamp in descending order
      books.sort((a, b) {
        DateTime aTimestamp = DateTime.parse(a['lastReadTimestamp']?.toString() ?? DateTime.now().toIso8601String());
        DateTime bTimestamp = DateTime.parse(b['lastReadTimestamp']?.toString() ?? DateTime.now().toIso8601String());
        return bTimestamp.compareTo(aTimestamp);
      });
      print("Books after sorting: $books");

      // Keep only the latest two entries
      if (books.length > 2) {
        books = books.take(2).toList();
        print("Books after keeping only the latest 2 entries: $books");
      }

      // Update the document in Firestore
      print("Updating Firestore document at ${docRef.path} with books: $books");
      await docRef.set({
        'books': books,
      }, SetOptions(merge: true));
      print("Successfully saved reading progress for book $bookId for user $uid: page $lastPage/$totalPages");
    } catch (e) {
      print("Error saving reading progress for book $bookId for user $uid: $e");
      rethrow; // Rethrow the error to ensure it’s not silently ignored
    }
  }

  // Stream for real-time updates of continue reading books
  Stream<List<Map<String, dynamic>>> streamContinueReadingBooks(String uid) {
    return _firestore
        .collection(readingProgressCollection)
        .doc(uid)
        .snapshots()
        .map((doc) {
      if (!doc.exists) {
        print("No reading progress found for user $uid");
        return [];
      }
      var data = doc.data() as Map<String, dynamic>;
      List<dynamic> books = data['books'] ?? [];
      print("Fetched ${books.length} continue reading books for user $uid");

      // Sort books by lastReadTimestamp and take the last 2
      books.sort((a, b) {
        DateTime aTimestamp = (a['lastReadTimestamp'] is Timestamp)
            ? (a['lastReadTimestamp'] as Timestamp).toDate()
            : DateTime.parse(a['lastReadTimestamp']?.toString() ?? DateTime.now().toIso8601String());
        DateTime bTimestamp = (b['lastReadTimestamp'] is Timestamp)
            ? (b['lastReadTimestamp'] as Timestamp).toDate()
            : DateTime.parse(b['lastReadTimestamp']?.toString() ?? DateTime.now().toIso8601String());
        return bTimestamp.compareTo(aTimestamp); // Descending order
      });

      return books.take(2).map((book) {
        print("Continue reading book: $book");
        return {
          'id': book['bookId'] ?? '',
          'title': book['title'] ?? 'Unknown Title',
          'file_url': book['file_url'] ?? '',
          'lastPage': book['lastPage'] ?? 1,
          'totalPages': book['totalPages'] ?? 1,
          'lastReadTimestamp': (book['lastReadTimestamp'] is Timestamp)
              ? (book['lastReadTimestamp'] as Timestamp).toDate()
              : DateTime.parse(book['lastReadTimestamp']?.toString() ?? DateTime.now().toIso8601String()),
        };
      }).toList();
});
}
}
